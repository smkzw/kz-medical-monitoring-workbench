# 医学写作子系统生产重基线任务记录

## 目标

在不缩减既有需求的前提下，从初级及资深医学撰写经理的真实工作顺序重新核对
医学写作子系统：任务准备、最小建项、IB/摘要导入、竞品检索下载与语料准备、
两阶段方案设计、动态章节计划、章节级AI候选/修订、证据与文献、表格/研究流程图/
量表、富文本编辑、DOCX导出和项目恢复。每项必须绑定前端入口、后端权威、独立AI
边界、真实项目证据和发布门，不能以单元测试或模型自报替代真实运行验收。

## 现有权威与恢复边界

- 总恢复记录：
  `records/active_slices/medical_writing_final_release_e2e_20260720/TASK_RECORD.md`
- 当前P0执行计划：
  `runs/execution/mw_release_p0_resume_20260720/manager_plan.md`
- 既有差距基线：
  `records/active_slices/medical_writing_gap_rebaseline_20260717/GAP_MATRIX_CURRENT.md`
- 现有产品源码：`frontend/src/features/medical-writing/`、`services/api/app/`、
  `packages/contracts/workbench_contracts/`。
- 当前无Git工作区；每个共享写入包必须先做闭合快照，产品写入严格串行。
- 正常运行时在项目上层`runtime/`，不得把`implementation/workbench/runtime/`
  当成真实生产数据源。

## 2026-07-22直接观察

1. 摘要异步Worker已落盘且聚焦测试168/168通过，但源码证明分块只计算
   `chunk_total`，实际仍调用整文档`import_and_structure`；chunk表没有写入，
   进度不是真实逐块进度，冷恢复不能从已完成块继续。
2. 前端摘要轮询固定600000 ms；既有真实MY009产品AI耗时约11分钟，因此前端
   会在后台可能完成前先报超时，且没有刷新页面后的任务重连入口。
3. 执行报告声称缺少`DEEPSEEK_API_KEY`，尚未按产品真实配置重新核查，不能作为
   最终阻断结论。
4. 研究流程图/IBDQ DOCX通过OpenXML合法性校验，但200 DPI真实页面显示：9页
   IBDQ被扩为25页，交替出现标题空页和分隔空页；流程图前后亦有孤立过渡页。
5. 原生Codex subAgent额度已由用户确认恢复。本轮并行启用了独立AI/异步架构、
   DOCX分节分页、写作编辑器与用户流程三个只读专项审计；共享产品写入仍严格串行。
6. Qoder既有进程已按用户授权恢复使用`Qwen3.8-Max-Preview`。其全链审计完成后
   按真实证据验收；若覆盖不足或结论偏原则化，再以Kimi Code/k3(high)进行针对性
   第二审，结果兼收并蓄而非机械二选一。
7. 量表附件页直接复现显示：第1页前出现孤立的`14.2`标题页；后续每个附件页先
   产生仅含页标题的页面，再在下一页放原图，原图后又出现空白页。源码根因组合为：
   `_instrument_appendix_page_word_layout`仅为标题预留0.48英寸，图片高度接近正文
   可用高度，标题和图片无法同页；同布局的后续页又调用`output.add_page_break()`，
   当前图已占满页面时，分页符段落本身落在下一页并再跳一页。OpenXML合法不代表
   版式可发布，修复后必须重新经Word实际渲染核对页数、连续性和可读性。
8. 独立AI专项subAgent完成只读审计，Codex复核源码确认两项此前未覆盖的P1：
   `configured_ai_provider_from_env`仅在provider名称恰为`deepseek`时强制直连；若
   全局配置为其他provider且transport为`hermes_cli`，可构造`HermesCliAiProvider`。
   摘要服务直接复用全局`ai_task_runner`，竞品分诊只校验`model_name`，并把缺失的
   `response_model`当作可接受后自行标记为`deepseek-v4-pro`，因此任务级“独立直连
   DeepSeek”边界没有失败关闭。后续须增加任务专用provider factory/policy，并用
   Hermes transport、任意base URL、缺失/错误响应模型的反例测试锁死。
9. 同一审计与源码复核确认：竞品分诊先写`queued`记录，但POST内立即同步遍历全部
   chunk，结束后才返回；并非可恢复后台任务。翻译批次重启只把`running`改为
   `failed_retryable`，未开始的`pending`项没有新BackgroundTask且retry不选择它，
   可永久滞留。两者加入摘要分块之后的异步任务通用化修复队列。
10. 真实产品AI环境并非缺失：仓库外
    `~/.config/cms-medical-workbench/ai-runtime.env`当前可读，且所需DeepSeek密钥、
    provider、transport、base URL、model、deployment profile字段均为已设置状态；
    未读取或记录任何密钥值。当前仅缺“按该部署配置完成真实生成”的运行证据，
    不能再把当前交互shell未导入环境变量写成凭据缺失。
11. DOCX专项subAgent以Word导出PDF、源码和47项聚焦测试交叉复核，确认量表页
    膨胀根因与Codex直接观察一致；同时新增两个结构问题：流程图按block逐次切换
    portrait/landscape分节，必然把标题、上下文和图拆成孤立页面；无显式目录章节时
    `_build_document_index_plan`默认在section index 1插入目录，位置依赖夹具章节顺序。
    修复应先做block layout prepass，将标题/上下文/题注/图作为同一布局组，再只在
    真正方向变化时分节；目录位置必须由前置对象/显式index节点决定。
12. 既有流程图+IBDQ验收夹具未绑定正式style profile和公司首页，因此只能证明
    fallback样式与对象嵌入，不能证明生产模板保真。修复后的验收要分别保留fallback
    单测和绑定正式样式的生产验收；OpenXML零错误之外必须要求Word原生更新域、
    重新分页后无空白页，9张量表原页连续落在9页内且页标题与图片同页。
13. 关于用户所称方案摘要“表格中的表格”，权威D017 OOXML实际使用一个顶层合并
    网格表达视觉嵌套，单元格内没有第二层`w:tbl`。因此目标应是复现该视觉层级、
    分点符和可编辑合并关系，不机械强制literal nested table；最终仍以权威样例的
    Word视觉和编辑行为为准。
14. 已使用仓库外生产环境配置执行
    `scripts/validate_real_ai_provider.py`非受试者合成探针，26.29秒完成，exit 0；
    公开结果记录provider=`deepseek`、model=`deepseek-v4-pro`、
    deployment profile=`local_private_clinical`、Codex/Hermes依赖均为false，2条规则和
    2条精确source span通过schema/来源校验。证据：
    `direct_deepseek_transport_probe.json`。这证明direct transport可用，但不消除
    摘要/竞品任务级路由可被Agent配置越过的问题，也不替代真实业务链实测。
15. 编辑器/用户旅程专项subAgent完成源码与临时匹配运行面审计。当前可见8910来自
    另一`qoderwork`，build ID与目标前端不一致，门禁正确失败关闭但不能作为用户
    常态入口；发布时必须由同一源码构建并启动5174/8911，校验runtime contract和
    build ID，不能复用当前8910或5180进程。
16. 运行准备接口把`independent_ai.ready=false`与总体`ready=true`并存，AI-first
    主路径会进入“写作系统就绪但预填/修订不可用”的假就绪状态。生产DeepSeek环境
    当前实际可用并不能掩盖此合同缺陷；后端ready和前端门禁必须明确要求独立AI，
    或进入可完整执行的显式人工降级模式，不能只禁用按钮。
17. 编辑器存在数据损失风险：创建工作副本尚未编辑即可能进入dirty；刷新、重新
    加载、切换章节/项目没有统一脏稿拦截或本地恢复。后续须将dirty绑定首个真实
    内容事务，增加beforeunload、章节/项目切换确认、会话级草稿和409冲突恢复。
18. AI章节候选仍是约2分钟量级的同步请求，只显示“处理中”，没有任务状态、耗时、
    取消或刷新重连；空白绿地章节还曾因evidence quote校验返回409。应与摘要/竞品
    共用后台任务语义，再用真实DeepSeek证明空白章节3-5候选可生成和采用。
19. 长文档目录对151个节点仅用单层弹层展示，没有折叠树、当前位置路径或状态聚合；
    正文全屏又移除保存状态、版本、AI、证据与引文入口。需要以现有较完整的表格
    全屏为基准重构正文全屏；来源核验、保存、医学审阅、冻结/发布状态必须分层显示。
20. 摘要导入建项仍先要求药物、适应症、分期，违背“先从摘要提取，再由用户确认”
    的既定要求；从零路径继续保留三项最小输入，摘要路径改为文件优先并在冲突确认
    页展示AI提取值。IB继续保持可选，提供暂无/稍后上传/现在上传三态。
21. 临床内容架构subAgent用116项聚焦测试和两个只读探针确认：I期Part当前仅为
    `List[str]`加方案级sequence，采用后又复制到`intrinsic_objectives`和
    `design_pattern`；章节、摘要和流程图分别读取不同的自由文本而非同一结构化
    对象。选择SAD、MAD、食物影响、物质平衡、肝/肾功能不全、DDI、首次患者后，
    可同时出现总体摘要列出全部Part、对应章节`not_applicable`、摘要“待确认”且
    流程图Part为空。需建立Part级人群/队列/剂量/PK-PD/安全/停止/SoA/依赖关系对象。
22. 当前AI-first预填仍以`deterministic_registry_prefill`为主，按分期直接给出
    SAD+MAD、随机双盲安慰剂多中心，并可仅凭III期默认“计划期中分析”；DeepSeek
    只重写少量自由文本，失败时确定性包仍可持久化并被用户采用。后续规则是：
    确定性逻辑只生成事实映射、结构脚手架和明确“待研究/待确认”，不得在产品AI
    未成功且无证据时给出可采用的临床设计结论。
23. `ProtocolModuleResolution`目前能驱动章节/目录，但`affected_artifacts`中的
    evidence/ai_candidates只是声明；AI上下文和语料检索未携带structured design、
    modality/route、干预规则、study schema、治疗切换和模块决议。因此明确排除
    期中分析、采用活性对照或设置转组后，证据和候选仍可能取到冲突语料。需要一个
    单一`ProtocolAssemblyPlan`同时投影摘要、章节、SoA/流程图、证据意图、候选约束
    和导出断言，禁止确认后的结构化事实再退回自由文本正则推断。
24. 药物modality/route及无IB事实对话已有合同字段，但下游规则没有覆盖口服、输注、
    鼻喷、吸入、外用、装置依赖和局部暴露等特异监测；显式`src_planned=false`和
    `dmc_planned=false`在I期仍可能因“Phase I”强制保留委员会章节。语料排序也只
    对适应症/分期做硬匹配，设计、modality、route和语义模块尚未进入权威门。
25. Qoder/Qwen3.8全链报告已完成，但包含与直接证据冲突的结论：把当前仓库外生产
    AI配置写成不存在、把实际landscape流程图称为portrait、把已存在候选卡UI概括
    为静态空表单，并把仅章节层生效的动态模块标为完成。报告保留作线索，不作为
    状态权威。已启动Kimi Code/k3(high)针对性第二审；首次以短名`k3`因本地配置
    使用全名`kimi-code/k3`而失败，随后用已配置全名健康预检成功并建立会话。
26. 外部实现路径复核支持本轮异步任务架构：FastAPI官方将`BackgroundTasks`定位为
    响应后执行机制，并明确重计算/跨进程场景应使用更完整的任务设施；它本身不提供
    持久队列、租约、冷恢复或跨进程只执行一次保证。当前初版受“本地单机、不开新
    Redis/RabbitMQ/Celery依赖”约束，因此选择SQLite持久job/chunk表、原子claim、
    有期租约、启动扫描和幂等恢复；未来内网多节点部署时在保持API任务合同不变的
    前提下替换执行后端。FastAPI文档：
    `https://fastapi.tiangolo.com/tutorial/background-tasks/`；SQLite WAL文档：
    `https://www.sqlite.org/wal.html`。这不是把daemon thread误当持久任务。
27. DOCX外部实现复核同样支持已确定修法：python-docx文档区分section break与普通
    page break，并提供`page_break_before`、`keep_with_next`等段落分页属性；量表页
    不应靠独立`add_page_break()`段落分隔，流程图也不应逐block反复创建新页分节。
    参考：`https://python-docx.readthedocs.io/en/latest/dev/analysis/features/sections.html`
    与`https://python-docx.readthedocs.io/en/latest/user/text.html`。已创建闭合备份
    `records/runtime_backups/20260722_before_docx_layout_repair/source_snapshot.tar.gz`
    （SHA256 `24803f9d5482dd7149f624d73524a64308ae0bf6118efc625bc239ba9c6fc72c`），
    并派发独立subAgent修复量表连续分页、流程图成组分节和目录稳定定位；写入范围
    与摘要worker不重叠，最终仍由Codex经Word真实渲染验收。
28. Qoder报告中“96个前端合约测试即所有按钮/键盘/全屏/错误态完成”等结论被降级
    为组件存在性证据：正则/合同测试不能证明浏览器点击、输入、焦点、dirty保护、
    刷新重连、长耗时任务或最大化编辑可用。后续发布矩阵必须把“源码存在、合同
    测试、API实跑、浏览器实操、Word实渲染”分为五级证据，不再合并成“完成”。
29. StudyDefinition/确认语义专项subAgent完成只读探针，纠正旧Worker 02/03提示：
    Greenfield已经创建并继承完整triple，现有rebind和用户直接选用也并非空壳；真正
    P0是读侧和普通保存缺少triple隔离。临时SQLite注入空绑定正文后，实际可在主编辑
    内容读取、进入`draft_preview`，普通保存又保留旧正文并把当前triple写上，形成
    “洗成当前绑定”；只有`approved_final`拒绝STALE。修复必须同时覆盖read、普通
    save、revision thread、表格/AI apply、draft/final export，且不能只在正式导出拦。
30. Imported source目前没有StudyDefinition triple，进入`binding_required`后又不能
    使用仅支持Greenfield的现有rebind，存在恢复死路。新Worker 02必须增加Imported
    binding sidecar或等价权威对象、revision-thread triple、隔离快照，以及两个明确
    操作：`accept_and_bind`和`revert_to_authoritative_baseline`。旧内容只在折叠的
    历史对比抽屉中可见，不得作为active editor payload；迁移为additive，不批量绑定
    或改写历史快照。
31. 确认语义的实际多余层并非AI候选选用本身，而是章节working-copy ApprovalGate：
    当前同一`medical_manager`可先选用/写入，再“提交当前工作副本版本至医学审批门”
    并形成`MEDICALLY_APPROVED`快照。Worker 03应在Worker 02后重新基于最新文件生成
    合同：候选选择和写入合并为一个原子事务；章节动作改为同一作者“确认本章定稿/
    冻结当前版本”；后续编辑只使当前冻结失效并保留历史。Writing Reference原文/
    译文复核与准入、PV/Safety/监查的真实审核语义保留，不做跨模块文字替换。
32. 该subAgent聚焦套件62项通过，扩展套件97项通过、1项失败；失败是前端合同仍按
    旧源码位置匹配synopsis函数，而实现已迁至
    `MedicalWritingAuthoringJourneySetup.jsx`。这是测试陈旧，不是产品通过；后续
    相关合同改为行为/API/浏览器断言，不能简单更新字符串位置后记绿。
33. 文献/证据链专项subAgent用只读探针证实新的P0：医学写作AI候选可包含裸数字
    引文`[99]`并通过现有schema/语义校验；候选保存和采用只携带proposal text及
    evidence IDs，普通/富文本替换不会创建managed citation mark或绑定项目文献
    `reference_id`。因此虚构引文可进入正文，却不会生成参考文献条目、编号或内部
    超链接。后续必须在候选校验和原子采用两端失败关闭：每个引文标记都绑定当前项目
    文献身份，采用时生成结构化citation mark；无身份引文直接拒绝。
34. 竞品admitted brief只保留中文文本/locator/hash，未保留原始source text、
    artifact/extraction revision和批准译文revision；章节证据scope仅精确覆盖5.2、
    5.3和三个目的节点，其他章节默认获得全部已准入译文。候选采用审计又没有exact
    quote、locator、document hash、translation revision，不能证明章节级来源可追溯。
    该缺口纳入ProtocolAssemblyPlan/evidence-intent统一修复，不再以“已准入”替代
    “适用于当前章节”。
35. 文献身份合并目前按DOI→PMID→URL→题名年份单一路径选择；若同一文献第一次由
    DOI、第二次由不含DOI的PMID元数据导入，可生成两个record。URL和题名/年份没有
    跨identifier事务级回退，非空元数据冲突静默保留首值；畸形metadata JSON还可能
    直接形成HTTP 500。需实现多键身份图、显式冲突复核和受控错误类型。
36. 引用重索引/导出仍存在三个反例：blocked reindex会返回原文档而不是阻断导出；
    bibliography planner会追加所有未引用legacy条目，删除引用后孤儿条目仍保留；
    legacy条目近乎原样输出，只有managed reference走GB/T 7714 formatter。最终
    规则应由当前正文首次出现顺序重建、按明确策略删除孤儿、所有支持文献类型统一
    GB/T 7714-2015，不合规legacy条目阻断或显式复核。
37. 既有RUX/PNH浏览器和RUX/D001/PNH OOXML证据证明过cursor插入、ID持久化、连续
    编号和bookmark可解析，但没有在Microsoft Word完成“打开→更新全部域→点击每个
    引文→保存→关闭→重开”的端到端证据。该动作加入E5发布门，不能用LibreOffice/
    XML测试替代。
38. Kimi Code/k3(high)针对Qoder结论完成第二轮只读复核。其执行stdout证实模型原拟
    生成约25.8KB详报，但runner最终仅保留3373字节摘要，完整逐项表和12条测试合同
    未被持久化；因此本次仅采纳可由Codex独立复现的结论，不能把“Kimi已全面审计”
    作为发布证据。摘要报告保存在
    `runs/execution/medical_writing_production_rebaseline_20260722/kimi_k3_targeted_second_audit.md`，
    原始运行记录保存在同目录`.stdout.log`。
39. Kimi纠正Qoder四项过时判断：摘要当前已是真实逐块worker且前端改为3秒轮询与
    localStorage重连；AI-first预填卡、批量采用、改后采用、证据抽屉和409分支已有
    真实接线；greenfield已有StudyDefinition绑定/rebind/quarantine基础；摘要路径
    已支持空framing上传并先提取。上述仅从“未实现”提升为“源码已实现/待真实运行
    验收”，不能越级记为完成。
40. Kimi新增摘要异步P0线索：其复跑时`_complete_job`没有持久化completed状态与结果
    payload，使全部chunk完成后`get_job_result`仍见pending，相关聚焦测试为红。由于
    Hermes仍在同一文件执行真实分块/冷恢复修复，Codex暂不对在途源码做并发修改；
    worker结束后必须重新核验结果原子提交、全chunk完成门、claim-token所有权、长调用
    心跳/租约、单调进度、取消晚结果隔离和源元数据保真，历史“168项通过”在重跑前
    不再作为当前版本证据。
41. Qoder与Kimi共同指出而且源码/真实运行尚未关闭的门继续保留：任务级DeepSeek
    失败关闭、竞品分诊和章节候选真正异步化、编辑器dirty/刷新/网络错误保护、整体
    readiness不得假绿、DOCX量表/分节/目录/fallback样式，以及所有“已实现”能力的
    独立AI+浏览器+Word E3-E5证据。Kimi认为无需第三轮宽泛审计；Codex采纳“转入
    实施与真实验收”，但保留针对失败链路的定向复核。
42. 任务级独立AI失败关闭补丁完成首轮：医学写作revision和摘要结构化只允许
    direct DeepSeek Pro；章节识别/翻译整合只允许direct Flash或Pro；provider、
    transport、base URL和model均进入策略决策。竞品分诊不再接受伪provider、错误
    base URL或缺失/错误response model。Codex独立复跑
    `tests/test_medical_writing_direct_ai_policy.py`、竞品分诊、原AI policy和gateway
    共104项通过、2个FastAPI弃用警告。
43. 该补丁尚未关闭业务门：`OpenAICompatibleAiProvider`当前只在内部校验响应model，
    没有暴露最后一次已验证`response_model`，所以新的竞品分诊生产wrapper会安全
    失败，不能完成真实分诊。扩展套件另有25项旧fixture使用buddy/泛provider，现被
    正确拒绝；处理规则是把这些fixture迁移为显式`test_only_provider_injection`，
    禁止放宽生产策略。待摘要线程释放`ai_gateway.py`后，串行增加不可伪造的响应身份
    暴露、任务级readiness和真实DeepSeek分诊探针。
44. Codex复现并修复总readiness假绿：`runtime_readiness_report`此前计算了
    `independent_ai.ready`却没有纳入总`ready`，AI缺失或路由非法时仍可能返回200。
    现在独立AI不可用会把`independent_ai`加入`missing_capabilities`并返回503；合法
    direct DeepSeek配置仍返回200。备份为
    `records/runtime_backups/20260722_before_runtime_ai_readiness/source_snapshot.tar.gz`
    （SHA256 `3fd2c0c9f490c9a2ac71a7be72caa89283c1199316184ff85729cc3b6f62286b`），
    runtime readiness、gateway和direct policy共53项通过。该修复是全局配置门，不
    替代摘要/分诊/章节候选的任务级健康探针。
45. `OpenAICompatibleAiProvider`现仅在响应model校验和JSON解析均成功后公开
    `response_model`，并显式公开`transport_name=openai_compatible`；失败或模型
    不匹配时不会残留本次伪身份。gateway、triage、direct policy、readiness共112项
    通过。备份为
    `records/runtime_backups/20260722_before_provider_response_identity/source_snapshot.tar.gz`
    （SHA256 `350ca3db29fb40003dd9bb4c3d353a38bd889daa4a88693683a9ea6e51b3d450`）。
46. 使用仓库外`~/.config/cms-medical-workbench/ai-runtime.env`执行一次非受试者合成
    竞品分诊身份探针，15.11秒完成；配置模型和已验证响应模型均为
    `deepseek-v4-pro`，provider为`deepseek`，单一NCT集合和分类schema校验通过，
    Codex/Hermes运行依赖均为false。脱敏证据：
    `direct_deepseek_competitor_triage_identity_probe.json`。该E3只证明真实transport、
    response identity和单候选schema，不替代真实ClinicalTrials.gov篮子、后台任务、
    多chunk恢复和用户确认E4/E5。
47. 章节AI候选的数字引文现已在生成和采用两端失败关闭：候选中的每个数字引文必须
    携带当前项目`reference_id`绑定，绑定索引按proposal hash持久化到AI运行artifact；
    采用时重新核对项目归属、标记数量和顺序，并生成带`referenceId/referenceIds`的
    富文本citation mark。裸`[99]`、跨项目文献、富文本目标缺失或采用前绑定漂移均
    拒绝且不产生部分写入。备份：
    `records/runtime_backups/20260722_before_ai_candidate_citation_guard/source_snapshot.tar.gz`
    （SHA256 `c33f4e738203b6d9d498ec453c9f3e172f6bc6cdeeafc0168be0b39f9294884d`）；
    Codex复跑引用专项88项通过。完整GB/T重索引、孤儿删除和Word原生跳转仍是后续门。
48. 主编辑器数据安全修复完成E2验收：会话恢复稿按项目/文档/章节/基础版本隔离，
    450ms防抖保存并过滤字节/Base64/路径/密钥类字段；dirty时启用beforeunload，
    章节、项目和子系统切换均进入继续编辑/恢复/明确丢弃处理；版本不一致仅作为冲突
    稿恢复，迟到请求不能覆盖新章节，合法空文档与网络失败分开。正文全屏保留保存、
    AI、证据和文献入口。Codex复跑134项相关前端合同测试及Vite生产构建通过（1882
    modules）；仍保留真实浏览器逐键、断网、刷新、表格输入和1440x900全屏E4门。
49. DOCX分页补丁的64项确定性测试和14页LibreOffice自动QC虽通过，但Codex原图
    视觉验收拒绝：第4页显示`1.1  1.2 研究流程图`，第5页显示
    `1.2  14.2 量表与评估工具`，第14页显示`1.3 14.3 附件后正文`。这说明
    手工标题号与Word原生编号重复且跨分节漂移，自动报告没有覆盖用户可见编号。
    已退回同一DOCX执行上下文修根因并新增导出OOXML与PDF文本回归；当前不得把流程图、
    附件或标题样式记为发布通过。
50. 摘要异步第二轮执行补齐claim-token CAS、chunk heartbeat、严格全块合并、单调进度、
    完整`source_json`冷恢复、稳定job_id和worker shutdown，但Codex源码复核又发现
    会商未覆盖的迟到失败覆盖：旧owner丢失claim后仍会无条件fail整个job，且
    `_fail_job`未排除`completed`。现已改为只有仍持有claim且成功CAS失败chunk的owner
    才能fail job；已完成结果不可回退为failed；最终提交在同一`BEGIN IMMEDIATE`
    事务中复核chunk数量、连续索引和全done。shutdown后heartbeat立即停止，冷恢复测试
    因而不再依赖旧provider 30秒超时制造“假接管”。新增反例让旧provider阻塞、租约
    过期、新服务接管完成、旧provider随后报错，最终仍为review-ready。备份：
    `records/runtime_backups/20260722_before_synopsis_stale_owner_guard/source_snapshot.tar.gz`
    （SHA256 `87cfe315478a2d379dddfc413ce9d677699be299649bb7d0f402edd21dd463c0`）。
    Codex在`PytestUnhandledThreadExceptionWarning`按fatal的条件下连续两轮各54项通过；
    该E2/E3模拟链已关闭并发/生命周期缺口，真实DeepSeek多chunk、刷新和进程重启仍需E3-E4。
51. DOCX标题号经历两次“模型报告通过、原图不通过”：r4第14页只显示`3`，r5报告
    声称已显示`14.3`但Codex用其保存的原始PNG再次看到`3`。根因是隔离Heading2在
    分节后没有可靠父级列表上下文，而LibreOffice对单级列表`lvlText=14.%1`又只绘制
    当前层。现改用跨Word/LibreOffice稳定策略：完整权威章节号写入可见Heading段落文本，
    段落仍是原生Heading 1-4并显式`numId=0`关闭继承编号，保留TOC `\\h`、书签和导航；
    不再依赖渲染器多级列表状态。r6原图已证实`1.2`、`14.2`、`14.3`各只显示一次，
    聚焦分页测试5项通过。该决策优先保证成品一致、标题样式可编辑和目录可跳转；后续
    Microsoft Word更新目录/点击跳转仍需E5。
52. r6重新生成同时发现附件分页仍非通用：两页量表样本第2页只有“原始附件第1/2页”
    标题，第3页才出现原页图片，证明9页样本通过不能外推到其他宽高比。已开启独立
    修复线，要求按1/2/9页及纵向、近方形、横向三类宽高比，用同次LibreOffice PDF的
    标题文本和图片像素页归属验收“一原页一Word页、标题与图同页、无空白分隔页”。
53. StudyDefinition/working-copy后端身份安全已完成并由Codex合并验收：导入文档通过
    不改源DOCX的审计sidecar绑定；缺失/过期/外项目三元组内容成为
    `historical_quarantined`，正常读取只返回权威源基线，普通保存、结构化表格、
    AI候选接受/应用、revision thread、draft preview和final export均失败关闭，禁止
    把旧正文“洗”成当前绑定。新增`accept-and-bind`、`revert-authoritative-baseline`
    和隔离历史API，事务内提交新revision、隔离快照、sidecar、审计和幂等记录，部分
    失败全部回滚。备份：
    `records/runtime_backups/20260722_before_study_binding_backend/source_snapshot.tar.gz`
    （SHA256 `d9f3e815e30491a158df15f3d379109b9dbfc3cbd58d6a2fe2f14272f38e7cf8`）。
    Codex将6个旧buddy fake-provider fixture显式改为`test_only_provider_injection`，
    未放宽生产直连DeepSeek门；绑定、工作副本、表格、AI候选、导出和绿地组合124项
    通过。剩余为前端隔离/恢复交互、浏览器E4和作者确认/版本冻结语义。
54. 下一条临床内容架构线已完成第一性原理决策记录：ICH M11 CeSHarP Step 4技术
    规范以Heading/Data/Value、cardinality、conditional conformance和reuse定义结构；
    TransCelerate CC&R强调write once/reuse和protocol/SAP/CSR/registry下游复用；
    ClinicalTrials.gov要求design、arms、interventions、outcomes跨模块一致。由此确定
    `ProtocolAssemblyPlan`只能是StudyDefinition权威对象的版本化装配与投影计划，
    不能再复制一套临床事实。typed I期Parts、随机/盲法/对照拆分、期中分析/转组/
    SRC/DMC、modality/route、研究药物与非试验用药边界及摘要/章节/SoA/流程图/证据/
    AI候选/DOCX单一投影不变量已记录于`PROTOCOL_ASSEMBLY_PLAN_DECISION.md`；待当前
    working-copy确认语义写入结束后串行实现，避免共享contracts/repository并发冲突。
55. DOCX附件分页r7已由Codex独立复核通过LibreOffice/OOXML级验收：导出器按页面、
    页眉页脚、标题行、图像行和节分隔预算纵向空间，图片保持比例，源PDF继续220DPI；
    页间分页符附着在图像段落，避免生成独立空白分隔段。参数化回归覆盖近方形1页、
    标准纵向2页、横向1页和标准纵向9页；Codex组合复跑分页、附件、流程图、源保真和
    exporter共50项通过。Codex直接查看原始PNG并用PDF文本复核：两页附件标题/图片同
    在第3、4页，九页同在连续第2至10页，后续`14.3`正文在附件后，`1.2/14.2/14.3`
    只完整显示一次，页眉页脚在所有附件页存在；两份DOCX的Microsoft 365 OpenXML
    ErrorCount均为0。备份：
    `records/runtime_backups/20260722_before_appendix_pagination_r7/source_snapshot.tar.gz`
    （SHA256 `96812738c4d2960b0306bde6e9bb13171dd13ef097dcc0b926fa2438942bb32f`）。
    该项从阻断提升为E2+LibreOffice渲染通过；Microsoft Word更新域、保存、关闭后
    重开仍是E5发布门，不能用LibreOffice代替。
56. DOCX布局样本已完成Microsoft Word原生E5闭环，且未触碰用户同时打开的
    `MG-K10-CRSwNP...tracking.docx`：仅对任务副本
    `docx_layout_qc/word_e5/medical_writing_docx_layout_qc_r7_word_roundtrip.docx`
    更新/保存，Word原生导出
    `medical_writing_docx_layout_qc_r7_word_native.pdf`，关闭后再次重开成功，再关闭
    验收副本并保留用户文档。原生PDF为A4共7页；目录页显示1.1/1.2/14.2/14.3及
    正确页码，图目录指向第2页；流程图在第2页可见，两页量表附件分别位于连续第3、
    4页且标题与图同页，第5页恢复14.3正文，全部页面保留页眉页脚。OOXML仍保持
    Heading2原生样式和两个TOC域。该证据只关闭“合成布局样本的Word原生保存/重开/
    渲染”门；真实量表内容、目录/引文实际点击跳转、权威中文模板封面/摘要/表格及多
    适应症整包仍须分别E5，禁止把本项外推为整个DOCX产品链完成。
57. 文献导入多键身份图已由Codex代码复核和组合回归验收：同一项目内以DOI、PMID、
    规范URL和Unicode归一化标题+年份建立关联组件；新记录可桥接原先分离的DOI行与
    PMID行，按最早`created_at`再按`reference_id`保留稳定survivor，事务内删除被吸收
    行、重映射历史幂等结果并记录审计。共享强标识但另一个强标识矛盾时返回可控409且
    即使override也不强并；仅弱身份冲突时必须由医学经理写明理由方可保留独立记录。
    Crossref/PubMed畸形数组/标量结构转为可复核领域错误或警告，不再裸500；项目隔离、
    幂等重放和中途故障整事务回滚均有负测。Codex复跑
    `test_medical_writing_literature.py`、citation export及source-preserving export共49项
    通过。后置快照：
    `records/runtime_backups/20260722_after_literature_identity_graph/source_snapshot.tar.gz`
    （SHA256 `5bdc5dd617d2a39c7f2ad1098a6678ab07f94a120c38466d65ecb0bbe55e420d`）。
    当前只关闭身份导入E2门；真实Crossref/PubMed网络、GB/T重索引和Word原生引文跳转
    仍未关闭，不能据此把文献全链标为完成。
58. 导入源DOCX后的文献区段扫描与重索引已关闭原误判根因并由Codex用两个真实项目
    独立复核：扫描器解析`styles.xml`、样式继承及`outlineLvl`，只从“参考文献”标题
    扫描至下一个同级或更高级标题；表格化参考文献可识别，附录量表和普通编号表不再
    混入。RUX由旧40组/15处引文收敛到真实19组/19处引文，表16/17误收清零，18处
    EndNote ADDIN完整保留；当前仍因孤儿文献17和首次出现顺序要求18→17、19→18、
    17→19，三处插件可见结果必须重绑定而返回`citation_manager_rebind_required`，这是
    正确的安全阻断。D001由旧51组/14处收敛到13组/13处，当前映射恒等、孤儿13作为
    notice、内存转换二次幂等。Codex直接复核两份源文件SHA前后不变（RUX
    `8783a740...de5b62`；D001 `36244313...2dd98`），重跑scanner、真实项目、源保真、
    legacy、citation export、literature和AI候选引用共99项通过。后置快照：
    `records/runtime_backups/20260722_after_source_reference_reindex_boundary/source_snapshot.tar.gz`
    （SHA256 `6d25dc47f8ee89e2a84c7d7816701cd182ceeb375f04a4a6ca796ea9bf721ae7`）。
    未验证Word桌面版配合EndNote/Zotero/Mendeley刷新、保存和重开；RUX物理重索引按
    设计未执行，必须先处置孤儿17并由插件重绑定，不能绕过阻断。
59. 医学写作“用户已选择却仍待医学批准”的后端根因已改为作者确认/当前版本冻结
    语义，并由Codex独立验收：保存正文、表格修改或选择AI候选均视为医学作者决定，
    不再创建写作ApprovalGate；章节可显式冻结当前revision，事务内生成不可变快照、
    审计和哈希链，解除冻结不增加内容revision，后续正文/表格/AI应用、StudyDefinition
    变化及显式绑定恢复只使当前冻结失效并保留历史。新增freeze/unfreeze/history、
    final freeze readiness和隔离历史恢复API；旧写作审批动作返回410且从审批中心过滤，
    但Reference、医学监查、PV/Safety及其他真实审核链未改变。Codex用当前源码复跑
    医学写作组合101项、非写作审批/PV/监查/SQLite 48项均通过；
    `medical_writing_document_exporter.py` SHA256仍为
    `8cf29ceac8e607356183b440ef0bd9f6e282aeecf849b205607a5897b9868645`。
    后置快照：
    `records/runtime_backups/20260722_after_author_freeze_backend/source_snapshot.tar.gz`
    （SHA256 `448753d4f234e3c8b94396f0a59cbcfdd81128da950aac6955f0f540f849d041`）。
    当前只关闭后端E2；前端冻结/解冻/历史/隔离恢复、候选选择+写入原子性和真实浏览器
    E4仍在本轮继续，不能把本项外推为用户工作流已完成。
60. 当前版本Qoder/qwen3.8全链审计已完成并带
    `QODER_CURRENT_AUDIT_COMPLETE`标记，报告位于
    `runs/conference/mw_current_full_audit_20260722/qoder_qwen38_current_audit.md`。
    审计执行594项测试并提出5项P0、6项P1；Codex不直接采纳模型结论，已复现并
    接受：竞品分诊同步、章节AI候选同步、确定性预填可生成可采用临床结论、I期Part
    仍是字符串列表、AssemblyPlan尚未被真实消费者调用、manifest残留旧批准语义、
    修订测试fixture过期、翻译pending重启风险和blocked重索引未阻断导出。认证缺失
    对本地单机不是当前发布门，但未来内网多用户部署必须关闭。Kimi旧审计进程因会话
    中断仅留下不完整临时输出，不作为证据；代码收口后重新审计当前版本，避免复核旧源码。
61. AI修订回归基线已在不放宽生产策略的前提下修复：旧buddy fake-provider仅通过
    `test_only_provider_injection`进入测试，非直连DeepSeek负向用例仍返回409且不创建
    AI运行；作者采纳状态断言迁移为`author_selected`。Codex追加把测试桩中的“医学
    批准”改为“医学作者确认”，并独立复跑修订API、AI策略、候选引文和应用隔离共
    54项、20个subtests通过。生产直连DeepSeek失败关闭未改变。
62. 医学写作作者确认前端已接入freeze/unfreeze/history/final-readiness、隔离稿
    accept-and-bind/恢复权威基线和候选写入失败显式重试；写作页不再调用
    `approval-gate`。旧Python合同9项已按行为迁移，而不是恢复已退休审批；完整前端
    合同96项、冻结迁移Node QC和Vite生产构建由Codex独立通过。该项当前为E2，真实
    浏览器Enter/表格/全屏/刷新/冲突/冻结失效和候选半完成恢复仍须E4；后端候选选择
    与正文写入仍是两次HTTP请求，真正原子端点尚未完成。
63. `ProtocolAssemblyPlan`持久底座、三态适用性、作者确认、历史、审计、CAS、幂等、
    项目隔离和七类消费投影API已实现；SQLite逻辑dump/load带内容哈希、恢复后
    `integrity_check`及原子替换。manifest及contracts默认写作语义同步改为“候选/待
    作者确认”。Codex独立复跑计划、冻结、StudyDefinition绑定、工作副本、revision、
    manifest、SQLite及前端合同180项、2个subtests通过。必须保持边界：源码检索只
    证明投影服务/API存在；摘要、正文章节、SoA、流程图、证据检索、AI候选和DOCX
    生成器尚未调用该服务，因此Qoder P0-5仍未关闭，下一轮必须完成真实消费者接入与
    跨投影反例，不能把“有projection endpoint”写成“产物已同源”。
64. AssemblyPlan消费者接入执行模块的Worker 01已完成同会话恢复并由Codex独立验收：
    新增typed `MedicalWritingPhase1Part`，逐Part承载人群、队列/剂量、PK/PD、安全性、
    停止规则、SoA和转段依赖；旧字符串列表只读迁移为未解析typed对象，写入权威改为
    typed结构。确定性预填的I期Part、随机、盲法、对照、分配、中心、适应性、期中分析、
    臂/队列和设计原型均降为低置信骨架并显式要求作者确认，不能自动成为临床事实；
    精确设计事实在无证据/无产品AI时不生成。新增共享fail-closed plan consumption helper，
    对缺失、未确认、过期、存在阻断性unknown driver及错误投影全部拒绝消费。Codex复跑
    专项/计划/预填115项及48个subtests通过；模板、编辑器合同、研究流程、DOCX导出、
    StudyDefinition绑定、文献和动态章节相邻回归250项及3个subtests通过。当前只关闭
    typed Parts与安全预填基础，尚未关闭摘要、章节、SoA、流程图、证据、AI候选和DOCX
    的真实调用；Worker 02/03已移除共同`main.py`写权限，将并行实现后由执行经理串行
    接线，避免共享composition root并发覆盖。
65. AssemblyPlan真实消费者接入已由Hermes Worker 02/03并行实现、Grok执行经理串行
    集成并经Codex独立验收：生产composition root在helper建立后统一注入方案模板、
    greenfield、revision/证据/语料/AI、研究流程表和managed DOCX；研究流程图的提议、
    影响预览、提交及插图均消费`study_schema_flowchart`，研究流程表只对真实
    `schedule_of_activities`创建/修改路径消费`soa`且不误伤其他表格。摘要、章节/TOC、
    SoA、图、证据、AI候选和DOCX固定同一plan id/revision/hash；缺失、未确认、过期、
    跨项目或存在阻断性unknown driver均失败关闭，不适用模块不进入适用产物。执行经理
    首次整合遗留3个greenfield旧基线失败后，Codex复现并纠正其错误归因：修复校验函数
    在已有resolved sections时使用空project id重算的缺陷，旧写作ApprovalGate用例迁移
    为作者冻结，managed导出测试建立已确认plan。聚焦组合126项、3个subtests通过。
66. Codex随后使用桌面工作区内置PDF依赖完整运行全部`test_medical_writing*.py`，首次
    暴露15个跨时期回归：3个managed DOCX API缺plan fixture，多组fake provider未显式
    `test_only_provider_injection`，真实项目流程残留写作`medically_approved`/ApprovalGate，
    Word标题测试仍查找无编号文本。执行经理只迁移测试fixture/断言，未放宽生产DeepSeek
    路由、plan门、作者冻结或DOCX编号策略；Codex独立复跑最终为814项、104个subtests
    全绿。当前AssemblyPlan消费者后端门关闭为E2，真实浏览器plan确认/变更失效及真实
    I/III期产物E4、Word E5仍是发布门，不能把单元/集成回归外推为已上线。

67. 医学写作统一持久任务执行模块已启动，执行经理先完成文件所有权、依赖顺序和
    回滚边界：保留已验证的摘要任务实现，不在本轮高风险重写；新增单一
    `DurableMedicalWritingJob` SQLite核心，竞品分诊、章节AI候选和参考资料翻译只作为
    job type适配器，`main.py`由最终集成人员单独持有。Worker 01首轮55项通过后，Codex
    源码审阅发现租约过期owner仍可在无人接管前续租/完成、retry可抢占running任务、
    cancel_check不核对claim及shutdown时限累加等未测缺口；同会话修复后追加24项。
    Codex再补短租约心跳必须小于租约、sweeper间隔合法性和包含sweeper在内的单一
    shutdown deadline，最终独立复跑durable core与原摘要回归108项通过。核心现具备
    稳定job id、项目隔离、claim/lease/heartbeat、CAS完成/失败/取消、单调进度、
    冷恢复、租约到期扫描、合作式shutdown和未来Celery适配边界；任何执行模型不得
    替代产品DeepSeek/GLM-OCR/Hy-MT2。前置备份：
    `records/runtime_backups/20260722_before_mw_durable_jobs/source_snapshot.tar.gz`
    （SHA256 `d5aa7a6683cf457e59f894b7e6b7db8b5db06de72a4ce9e10eba5f6a20d0129b`）。
    当前已放行竞品分诊、章节候选/原子采纳、翻译批次三路并行适配；尚未完成
    `main.py`统一API、前端进度恢复、真实产品AI E3和浏览器E4，禁止表述为已上线。

68. 用户于统一持久任务三路适配执行中明确要求无损暂停。Codex已终止仍运行的Worker 02
    follow-up和Worker 04 runner，未启动Worker 05。Worker 03已生成报告但其所谓原子采纳
    实际为两个顺序CAS事务，中间失败会留下author-selected半状态，不能接受；Worker 02
    首轮132项当前组合通过但Codex发现完整chunk持久化、旧owner业务写、Verified provider
    二次包装、跨项目provider污染及PARTIAL_FAILED重试等P0，定向修复在暂停时已有部分代码
    落盘；Worker 04已有翻译适配源码和新测试落盘但未生成报告。全部会话ID、文件状态、
    未验收问题和精确恢复顺序已写入同目录`SOFT_PAUSE_RESUME.md`。暂停不等于完成或阻断，
    恢复后必须从当前文件和原会话续跑，不得重做、覆盖或把成员报告当发布证据。

69. 2026-07-23 00:02已按用户指令恢复统一持久任务执行，并重新读取全局/项目
    `AGENTS.md`、Goal和本恢复锚点。Worker 03的真正单事务原子采纳已由原Hermes会话
    修复：`commit_medical_writing_atomic_accept_and_apply`在同一`BEGIN IMMEDIATE`
    内提交候选作者选择、working copy、快照、审计和幂等记录；Codex独立复跑章节候选、
    API、应用及共享durable组合124项、3个subtests通过，已接受进入整合回归。Worker 02
    v2组合146项通过，但Codex源码终审发现`_heartbeat_progress`异常仍被当作所有权成功；
    已向原会话`20260722_174538_f486f6`发
    `worker_02_followup_integrity_03.md`，要求心跳异常fail-closed且不产生业务写入。
    Worker 04 v2组合127项通过，但其报告与源码不一致：document plan、pipeline stage、
    translation chunk、chapter integration、composite run及translation revision仍可在最后
    一次所有权检查前落盘；已向原会话`20260722_174538_7d7e93`发
    `worker_04_followup_integrity_03.md`，要求逐写边界所有权守卫和确定性故障测试。
    两条runner当前并行，文件边界不冲突；W5、浏览器、真实产品AI及发布仍未启动，
    禁止把聚焦测试通过外推为统一异步迁移完成或系统上线。

70. 2026-07-23 00:39统一持久任务适配已完成第二轮独立验收：Worker 02 v3把
    heartbeat异常改为fail-closed并补齐写入前所有权反例，Codex聚焦复跑153项通过；
    Worker 04 v4补齐批次状态、复用、排除、完成等末端写边界的cancel/claim守卫，
    Codex聚焦复跑198项、16个subtests通过；W1-W4八个组合测试文件最终250项、
    3个subtests通过。Grok执行经理第二轮独立复跑164项后以
    `MANAGER_SECOND_PASS_BLOCKED`阻断W5，确认章节AI在长AI调用后、业务提交前未重新
    证明owner，取消或租约丢失仍可能写入revision thread。Codex结合只读接线审阅和
    源码复核进一步确认：单个绑定service的executor无法兼容项目级demo/real动态路由，
    单事务采纳明确拒绝前端已支持的table-cell，且存在
    `thread.section_id != thread.section_id`恒假校验。四项已合并为
    `worker_03_followup_integration_02.md`，通过preflight后续接原Hermes会话
    `20260722_174538_9e3882`执行；runner进程会话15364当前在运行。W5仍未启动，必须
    等W3确定性故障测试、Codex组合回归及经理当前源码复核全部通过后再接线。

71. 后续成员完成标记经Codex源码与测试逐项对照后两次被拒绝，未把“成员自报通过”
    当作验收。W3 v2以临时替换共享`service.repo`的`_CapturingRepo`拆分AI生成/提交，
    在共享production service并发时会跨任务捕获或提前落盘；其旧owner测试仅覆盖开始前
    cancel，table-cell原子路径虽实现但零专项测试，service resolver测试也只调用私有
    `_resolve`而未执行job。已派同会话v3移除共享可变repo、抽取同一无副本的纯prepare/
    commit路径，并补齐AI返回后cancel/heartbeat/lease/takeover、并发跨项目及table-cell
    成功/漂移/富文本/幂等/故障回滚实测，runner会话47974。W1正常关机释放实现也被拒绝：
    `max(1, attempt_count-1)`使首次释放后再次claim从1升到2，仍消耗重试次数，且过期
    lease可由旧token修改；已派同会话v2要求恢复claim前计数、live-lease CAS及shutdown/
    complete竞态测试，runner会话91324。W5与经理第三轮的前置标记已同步更新，两个旧
    completion marker均不得用于放行。

72. W1 v3现已关闭正常关机最终竞态：claim在complete/fail CAS完成前保持可见，
    shutdown的release与finalize由SQLite CAS唯一胜出；针对complete、retryable fail、
    shutdown短超时及新owner覆盖的barrier反例通过。Codex独立复跑durable core+摘要
    144项通过，接受`WORKER_01_GRACEFUL_RELEASE_V3_COMPLETE`。W3 Hermes v3再次因证据
    不实被拒：所谓AI后cancel在入口即取消、并发/路由用例均以无AI runner失败、rewrite
    未覆盖、table成功未断言cell内容。Kimi k3/high fallback健康预检返回
    `no usable session was established`且未修改文件；按无进展breaker转交原Grok执行经理
    同会话有界修复。经理引入真实Echo provider/AiTaskRunner、成功双项目并发、initial+
    rewrite所有权、thread-local嵌套/深拷贝、table目标文本/富文本/漂移/多故障回滚，并修复
    原子采纳成功后的幂等重放。Codex独立W1-W4八文件组合回归315项、9个弃用警告通过。
    当前原经理会话正在执行只读第三轮当前源码复核（runner 52963）；W5仍受
    `MANAGER_THIRD_PASS_READY_FOR_W5`门控。

73. 第三轮Grok经理当前源码复核完成并给出`MANAGER_THIRD_PASS_READY_FOR_W5`：
    复跑durable core、triage、revision、translation六模块252项通过，无P0/P1。其同时
    发现W1在expired-running接管后正常关机会无条件递减attempt的P2，Codex将其提升为
    接线前完整性问题而非放任：W1新增私有`claim_incremented_attempt`列及旧库additive
    migration，仅对由retry_wait本次增加的attempt回滚，queued/expired-running来源保持
    计数，并在全部清权状态清零。Codex独立复跑W1+摘要152项通过，接受
    `WORKER_01_GRACEFUL_RELEASE_V4_COMPLETE`。W5 prompt已更新为要求V4、W2 v3、
    W3经理修复、W4 v4和第三轮READY五个门，preflight通过后已启动Hermes/aishuo/
    cms-model runner 59588；其唯一写面为`main.py`、窄前端接线及对应测试，不能修改
    已验收业务算法，也不能宣称E3/E4/E5或上线。

74. W5首轮在工具边界结束，只落盘了部分后端接线和局部修订API测试，未形成完成标记；
    前端、跨类型集成测试和Vite构建均未开始。Codex读取当前源码并独立复跑
    `test_medical_writing_revision_api.py`，确认3项失败并非都可机械迁移断言：初次候选
    已持久异步但`request_rewrite`仍走同步`apply_action`，会与未完成的初次job竞态；
    原子采纳sync端点把未await的`Request.body()`交给`json.loads`，实际请求不可用；
    翻译create/retry仍保留`BackgroundTasks.run_pending/run_failed`长任务回退，违反统一
    durable边界。另确认前端尚未使用统一job API，旧accept后再apply两请求链仍存在。
    已把后端真实缺陷、三条前端路径、刷新恢复/取消/重试/双击去重/终态结果、段落与
    table-cell单请求采纳及确定性验收合并为
    `prompts/execution/mw_durable_jobs_20260722/worker_05_followup_complete_01.md`，preflight
    通过后续接原Hermes会话`20260723_014134_a08d3d`，runner会话64643。当前不得以
    W5首轮报告中的“测试适配问题”覆盖上述源码事实，也不得宣称统一异步迁移完成。

75. W5同会话第二次执行修复了rewrite durable路由、atomic accept-and-apply请求读取和
    翻译BackgroundTasks长调用回退，并新增共享前端job hook、章节页面局部轮询及集成
    测试；Vite构建通过，但执行者未发完成标记。Codex独立验收拒绝收口：14项修订API
    仍有3项失败；新hook未被任何组件import，App仍有两段200次手写轮询且失败/取消后
    仍取latest thread；竞品分诊和翻译未接统一job控制面，翻译start响应也无job_id；
    新前端测试多为字符串存在断言并错误把“翻译维持batch轮询”当通过。Codex进一步
    定位修订失败根因：测试用例跨case复用module级durable store导致确定性job id复用
    前序完成产物；approved-evidence用例在异步executor解析service前已退出临时patch。
    已形成`worker_05_followup_complete_02.md`，要求每测试隔离store/worker与resolver、
    patch覆盖执行期，三条前端真实接入、统一失败/刷新/取消/重试/去重与增强测试；续接
    原Hermes会话，runner会话89204。当前W5仍未通过，E3/E4/E5与上线均未开始。

76. W5第三次同会话执行已产出`WORKER_05_JOB_INTEGRATION_COMPLETE`，Codex独立完成
    修订API 14项、窄前端合同137项、Vite生产构建及W1-W5八文件组合300项回归，组合
    用时58.95秒、13条弃用警告，无测试失败。但完成标记未直接被接受：当前源码仍显示
    `App.jsx`的初次章节候选和`request_rewrite`只调用无持久化能力的固定次数内存轮询，
    没有保存revision job locator、刷新续跑及统一取消/重试入口；rewrite action路由也未
    明确返回HTTP 202。竞品分诊与翻译虽保存locator，但在网络超时后仍可能清除定位；
    翻译取消立即删除定位且retry未接统一job结果，shared hook的terminal callback只收到
    status而非已调和result。现已向原Grok执行经理会话
    `23209f5d-d713-4c40-ae71-f4f1f6e98b27`提交只读当前源码复核
    `manager_w5_current_review.md`（runner会话6456），要求审计实际202、reload/cancel/
    retry/result、跨项目、陈旧候选复用键、并发竞态和假绿测试。W5只有在上述P0/P1经
    定向修补和Codex行为级复测后才可进入独立产品AI E3；当前仍禁止声明统一异步前端
    已完成、真实AI链已通过或系统上线。

77. Grok执行经理W5当前源码复核已以`MANAGER_W5_CURRENT_REVIEW_BLOCKED`拒绝完成标记，
    复跑54项虽通过但确认三项P0：固定轮询超时/仍running被当完成；以revision thread
    列表最后一项而非`/result.artifact.thread_id`绑定结果导致并发错章；revision作业不保存
    locator且刷新无法恢复。另有rewrite实际HTTP 200、上下文变化仍复用completed候选、
    atomic响应DTO与前端预期不符、生产旧accept+apply半状态路径、triage/translation提前
    清locator及字符串假绿测试等P1。Codex已把全部缺口合并为
    `worker_05_followup_production_acceptance_03.md`，明确要求真实共享state machine、严格
    terminal/result调和、刷新/取消/统一重试、精确thread关联、真实生产只走单事务采纳、
    服务端权威WC/StudyDefinition/AssemblyPlan/corpus/evidence上下文指纹及行为测试；prompt
    preflight通过，已续接Hermes原会话`20260723_014134_a08d3d`，runner会话51031。
    当前不得发送进度询问；等待执行结束后由Codex审阅源码并复跑行为测试。

78. Codex并行只读SubAgent对章节候选去重键做了独立专项审计，确认P1不止是WC/plan
    漂移：当前initial键只含document/section/anchor文本/指令/intent/evidence brief ID，
    rewrite键只含thread/suggestion/指令/comment；均遗漏Evidence Brief当前状态与译文版本、
    Source Registry、prompt/policy/provider/model及demo/real service namespace。completed
    replay还会绕过`approved_current`校验；rewrite直接取当前thread的最后一条suggestion，
    可把后续轮次误包装成旧job结果。建议并入本轮验收：服务端canonical context descriptor
    +完整SHA256和`v2`键；executor在AI前及commit前重新派生并fail-closed；artifact精确记录
    generated suggestion IDs；采用时重验plan/corpus/evidence；合法intent/evidence/comment变化
    创建新job而非409。该审计只读、未修改文件，SubAgent已关闭；Hermes当前runner不被
    中途打断，结束后Codex按这些额外边界审阅，缺项再做同会话一次合并补充。

79. 另一只读SubAgent已完成W5后真实独立产品AI E3执行地图并关闭，不修改源码、不调用
    凭证或生产AI。建议12条隔离lane：RA/AD/PSO三个非肿瘤适应症，各自I期和III期、
    从零/摘要导入双入口；设计分别覆盖口服小分子SAD+MAD+首次患者、复杂MTX背景治疗，
    外用局部耐受SAD+MAD、期中分析+转组+OLE，注射生物制品SAD/MAD+免疫原性及阳性
    对照多重性。每lane必须使用独立`WORKBENCH_RUNTIME_DIR`、API/Vite/CDP端口和浏览器
    profile，常态runtime仅做前后hash清单且禁止清空。产品DeepSeek/CT.gov后端/
    GLM-OCR/Hy-MT2/Flash/Crossref-PubMed/DOCX引擎必须各自真实执行，测试模型不得替代。
    当前旧harness仅4条从零、共享runtime、手填NCT、抽样章节且未覆盖采纳/引用/Word；
    `final_release_12lane_contract_probe.mjs`仍是旧同步摘要接口。W5通过后先升级12-lane
    控制器、逐lane证据目录、模型身份采集、真实分诊/采纳/文献/Word链，再启动E3。
    可复用本地RA、AD、D001、I期模板、UC Ib、PNH III资料，但完整12条“未被旧测试
    污染”的摘要输入仍需从现有项目资料中继续检索或以真实从零路径形成，而不能把测试
    者模型生成内容伪装成原始摘要。

80. 2026-07-22本轮重新读取全局`/Users/smkzw/.codex/AGENTS.md`、项目`AGENTS.md`、
    Goal、恢复锚点和当前源码后，Codex拒绝接受Hermes第三次返工的
    `WORKER_05_PRODUCTION_ACCEPTANCE_REMEDIATION_COMPLETE`：`App.jsx`仍只写不读
    revision/rewrite locator，刷新不能续跑；共享hook/state machine未被生产代码使用且
    `/result`获取失败时仍提前清locator；服务端context fingerprint以广泛异常吞噬把
    权威缺失降为空串、误用不存在的`plan.sha256`而遗漏实际`state_sha256`和投影hash，
    且只进入request hash，导致合法上下文变化命中相同business key后返回409；executor
    未在AI前后及commit前重验，completed replay仍按候选列表首尾猜测，生产旧
    `needs-write-retry`半状态路径仍可达，已有测试多为未被生产import的纯模块或字符串
    假绿。已形成合并定向合同
    `worker_05_followup_true_recovery_context_04.md`，要求canonical v2 descriptor+完整
    SHA256、权威fail-closed、business key换代、执行前后漂移拒写、精确artifact lineage、
    真实刷新/取消/重试/调和及行为测试；preflight通过后续接原Hermes会话
    `20260723_014134_a08d3d`，runner会话8967。不得中途发送模型状态询问；执行完成后
    必须由Codex检查当前源码、复跑决定性反例并再交执行经理当前源码复核，W5当前仍未
    接受，E3/E4/E5及上线尚未放行。

81. Hermes第四轮返工无fallback结束并诚实返回阻断而非完成标记：修复了business key
    纳入旧fingerprint、revision locator局部读取、部分取消/重试和真实写作旧路径门控，
    自报聚焦62项、W1-W5 419项、Node 44项及Vite build通过；但明确承认权威descriptor
    仍异常吞噬、executor无AI前后重验、artifact只存thread id、测试仍非行为级且state
    machine仍未被生产import。Codex当前源码与两路只读SubAgent复核进一步确认：产品
    provider/model身份被错误地从`AiTaskRunner`空属性读取而非AI policy resolution；
    App/triage/translation仍有分裂状态机、result失败提前清locator、retry新job id丢失、
    stale completion和exact artifact缺口。按无进展breaker不再把同一合同重复交给Hermes，
    已形成`manager_w5_bounded_remediation_05.md`，授权原Grok执行经理会话
    `23209f5d-d713-4c40-ae71-f4f1f6e98b27`在有界文件范围直接修复canonical v2 context、
    AI前后漂移拒写、精确lineage/adoption重验、统一生产state machine及决定性测试；
    preflight通过，runner会话65330以`bypassPermissions`运行。该经理结束后仍须Codex
    当前源码审阅和独立测试；不得把其报告当发布证据。

82. Grok执行经理第五轮虽返回`MANAGER_W5_BOUNDED_REMEDIATION_COMPLETE`并自报聚焦
    109项、W1-W5组合328项、Node 44项及Vite build通过，Codex独立复跑该109+44项均
    通过，但源码验收仍拒绝W5：取消路径把`cancelled`强行视为已调和并提前清locator；
    revision恢复effect捕获章节却只依赖项目，异步初次/重写/重试也缺少await后的项目-
    章节generation guard，旧结果可污染新屏；v2恢复和重写仍以stored/current thread id
    兜底，违背精确artifact lineage；初次与重写locator顺序轮询且共享单一state，前者可
    阻塞后者；共享hook仍以`/result` HTTP成功代替业务产物核对并先清locator。后端亦遗漏
    `MedicalWritingSharedCorpusCatalog`的layer/version/asset hash，Source Registry仅记录
    布尔值/路径，新增测试未逐项覆盖WC、StudyDefinition、plan/projection、company/shared
    corpus、evidence、source、comment/rewrite parent及policy变化。已将上述可复现失败合并
    为`manager_w5_followup_acceptance_06.md`，preflight通过后续接同一Grok执行经理session
    `23209f5d-d713-4c40-ae71-f4f1f6e98b27`，runner统一exec session `15450`，权限为
    `bypassPermissions`。本轮只做这些具体验收失败的有界返修，并要求生产import的行为测试；
    不发送状态催促。结束后Codex仍须逐项读源码、跑反例和完整矩阵，未通过不得进入E3。

83. 执行经理验收返修06正常结束并自报`MANAGER_W5_FOLLOWUP_ACCEPTANCE_COMPLETE`，落盘
    取消后保留locator、项目/章节generation guard、v2精确thread/suggestion核对、初次/重写
    双operation state map并发恢复、业务ack后清locator、共享语料catalog身份及52项生产
    controller Node测试；Codex尚未据此放行。当前源码复核又发现一个会阻断主流程的P0：
    `_source_registry_descriptor()`没有复用`_run_revision_ai`的`source_mode`分支，把所有
    `require_registered_sources=True`真实项目都强制要求静态`protocol_source_paths`，导致
    从零创建的greenfield项目在产品AI前被误拦；原始方案项目也未使用Composite document
    service已有的`original_protocol_path()`，动态导入项目受限于main.py三个硬编码ID。
    同时内容校验身份读取不存在的`status/overall_status`，遗漏真实validation id/revision、
    technical/content/use status、file/context hash及checks；原测试仅在not-consumed状态改path，
    属于假证明。已形成窄合同`manager_w5_followup_source_identity_07.md`，续接相同Grok
    session `23209f5d-d713-4c40-ae71-f4f1f6e98b27`，统一exec session `28595`，只允许修改
    `medical_writing.py`及直接测试，要求greenfield/动态导入/真实entry-span-validation行为
    反例。当前仍不派发Qoder、不进入E3。

84. 两路只读SubAgent已关闭并形成后续边界：Qoder当前可见Terminal TTY `/dev/ttys000`、
    QoderVIP会话`cf900105-12e1-4f1c-aa44-6bf4457c8015`、模型`qmodel_preview`谱系可用，
    但必须等07报告和Codex复测后再AppleScript一次性派发；会审prompt已补入06全部反例和
    最新报告硬门禁。E3盘点确认现有12-lane静态QC虽58/58，历史产物仍是RA两目录dry-run，
    child/pipeline使用旧同步接口、硬编码AI身份、只处理少量章节/首个候选，不能计作真实
    产品验收。后续需重写config/parent/pipeline/child：每lane独立runtime/API/Vite/CDP/
    browser profile，oracle与product input分离，采集产品服务端AI/检索/下载/解析/候选/
    引用/DOCX回执，并新增Microsoft Word原生验收。RA/AD/PSO本地资料已初步映射，但
    PsO-I与能独立证明“期中分析+转组”的III期真实输入仍需补齐或调整适应症，不能以期别
    不匹配文件替代。

85. Source Identity 07虽修复greenfield分支、动态`original_protocol_path()`及真实validation
    字段，Codex继续源码推演发现首次原始方案任务仍会自漂移：job提交时Registry为空，
    `_run_revision_ai`执行中才登记当前段落，AI后descriptor由空变非空；且把整份方案全部
    spans纳入会让无关段落登记使旧候选失效。08同会话返修现已完成：在业务键前幂等登记
    本次唯一selection，descriptor只绑定其entry/source/locator/preview/validation，AI和
    rewrite再核对expected entry/source，无关段落不纳入；greenfield保持registry-free。
    Codex使用`/usr/bin/python3`独立跑W1-W5十模块（含registered sources）共347项全部通过，
    13条既知弃用/SWIG警告；生产Node controller 52项通过；Vite构建1884 modules通过，
    仅chunk>500kB提示。`/opt/homebrew/bin/python3.12`因缺`pymupdf`只在collection阶段失败，
    属运行环境依赖而非产品测试失败，已改用项目可用Python 3.9完成决定性回归。

86. E3真实资料补齐只读SubAgent已关闭：推荐把第三适应症从资料错期的PsO替换为UC，形成
    RA+AD+UC。UC Ib真实方案摘要`MY009212A-UC-Ib-方案摘要-LXN.2024.01.27.docx`可用于
    synopsis-import；SLE NCT03724916完整Ib protocol可作注射生物制品/免疫原性额外oracle；
    RA NCT04539964是严格III期、正式期中分析、Week12单向交叉和长期开放标签的完整protocol，
    但为器械研究，只可作结构压力oracle；药物备选AD NCT05732454为Phase2/3含期中分析和
    OLE，不得冒充纯III期。UC III NCT02819635为IIb/III诱导-维持、再随机、救援和OLE完整
    protocol；仍缺standalone III期synopsis，不能用protocol或CSR/SAP冒充摘要。

87. W5独立Qoder会审已按全局/项目AGENTS规则建立会审包并通过prompt preflight。沿用
    `~/Downloads/QoderVIP`现有可见`qodercli`，Terminal TTY `/dev/ttys000`，会话
    `cf900105-12e1-4f1c-aa44-6bf4457c8015`，模型事件确认`qmodel_preview`；通过Terminal
    AppleScript向现有交互会话投递唯一完整合同，不新建或无头启动Qoder。transcript已确认
    收件、模型、turn及首个Read工具调用。报告目标为
    `runs/conference/mw_w5_post_remediation_qoder_20260723/qoder_qwen38_current_audit.md`，要求
    `QODER_W5_CURRENT_AUDIT_READY/BLOCKED`；运行期间不发送状态消息，仅待turn.finished、
    报告marker和稳定hash。

88. E3旧12-lane harness现状已提升为正式执行模块任务
    `mw_e3_live_12lane_harness_20260723`：确认旧config仍是RA/AD/PsO且多条synopsis-import
    实际使用错期或错类型文件并以override放行，旧child/pipeline仍包含同步/抽样/硬编码AI
    身份风险，不能计作真实产品验收。新合同固定RA+AD+UC x I/III x from-zero/synopsis-import，
    禁止用II期冒充I/III、protocol/CSR/SAP冒充synopsis；每lane独立runtime/API/Vite/CDP/
    browser profile，真实AI/OCR/翻译/检索/引用/DOCX仅由产品服务执行。已启动Grok执行经理
    首轮只读规划，统一exec session `95384`，完成前不启动worker、不调用产品AI；Qoder W5
    READY和Codex harness验收前也不放行真实12-lane。

89. W5独立Qoder会审已结束且经Codex审阅接受：报告hash
    `33c32a5fbe955326ecae6a624b6c9c3786b843a570b858d05c1f626b2c0f5c8d`，turn正常
    `finished`，无fallback。Qoder从当前源码逐项核对13个验收边界，独立跑四组Python共
    347项、Node 52项（合计399）及Vite 1884 modules构建，全部通过，无P0/P1；这与Codex
    先前347+52及构建回归一致。W5 durable job集成门正式关闭，但只代表持久任务、精确
    来源、上下文指纹、取消/重试/刷新恢复与四类前端控制器可进入E3；不代表产品AI、浏览器、
    DOCX或上线已通过。P2五分钟单次轮询上限将留到真实长任务/浏览器验收观察，locator保留
    机制已确保不会因超时丢任务。

90. E3六单元真实输入只读检索已完成并关闭SubAgent：RA I期NCT03156023（pp3-6 Synopsis，
    SHA `83c134...f85`）、RA III期SELECT-COMPARE NCT02629159（pp9-19，SHA
    `48b615...ef0b`）、AD I期NCT04668066（pp12-18，SHA `3bbb...a4a`）、AD III期
    TRuE-AD1 NCT03745638（pp12-19，SHA `035f...c91`）、UC Ib MY009真实独立摘要（可直接
    导入，SHA `7a038...267`）、UC III期UNIFI NCT02407236（pp25-39，SHA `f5d4...923`）。
    除UC Ib外五份均是完整protocol内明确的Synopsis页段，当前只能标记
    `blocked_pending_exact_extract`，不能整份protocol冒充摘要；后续须由独立fixture步骤
    精确抽取并保留原文件hash、页段和抽取hash。UNIFI还真实覆盖期中无效性分析、Week8
    治疗切换、维持期再随机和LTE加量，是比RESET-RA器械试验更合适的药物结构oracle。

91. E3 Worker 01来源权威性同会话修订已返回并通过50项oracle QC：六单元权威协议/
    摘要路径、SHA与物理页段已锁定；五份protocol内摘要页正确标记为
    `blocked_pending_exact_extract`，UC Ib独立摘要为唯一直接可导入源；UNIFI保持真实III期
    药物试验身份；`synopsis_import_receipt.json`已加入证据合同。但Codex终审拒绝直接放行
    设计压力映射：TRuE-AD1和UNIFI被错误标成阳性药对照，并虚构dupilumab/etrasimod对照。
    已向原Hermes/aishuo/cms-model session `20260723_054136_f75878`发出唯一同会话定向补修，
    只允许修正Worker 01四文件与行为测试；不得用宽松`>=`断言吸收错配。

92. 精确摘要夹具Worker 05已与上述补修并行启动：只允许使用已安装且先核实BSD-3-Clause
    许可的`pypdf`，按RA I pp3-6、RA III pp9-19、AD I pp12-18、AD III pp12-19、UC III
    pp25-39复制完整PDF页，禁止OCR、翻译、重排、医学改写和网络调用；必须复核源SHA、页数、
    非空文本、首尾证据hash及确定性输出hash，并提供`--verify-only`。产物只能标记
    `versioned_exact_synopsis_extract_for_e3`，在Codex验收并由Worker 01后续映射前不得成为产品
    输入。两路runner统一shell session `1773`，仅按进程退出/完成marker观察，不发送状态询问。

93. E3来源层已完成两轮真实纠错并冻结。Worker 01设计语义对齐把阳性药对照严格限定为
    SELECT-COMPARE/adalimumab，TRuE-AD1恢复vehicle-control，UNIFI恢复placebo induction/
    maintenance+Week8 switch+re-randomization，61项oracle QC通过。随后发现初始只读检索报告
    的三条canonical路径并不存在；独立来源获取Worker 06从ClinicalTrials.gov正式地址取得
    RA III与AD III并匹配既定hash，本地复制RA I/AD I；UNIFI错误请求`Prot_000`产生不同hash，
    未被接受。Codex从既有`protocol_source_inventory.jsonl`定位到本地真实UNIFI Amendment 2
    原文，路径`朗来项目资料/竞品分析/UC/.../【III期 UNIFI】Protocol.pdf`、151页、hash
    `f5d4...c923`均与既定权威一致；已原子复制为显式
    `UNIFI_Protocol_Amendment2_local_archive.pdf`，并修正“CDN被替换”这一未经证明的旧推断。

94. Worker 05使用pypdf BSD-3-Clause对五份协议摘要页做无损整页复制，RA I/RA III/AD I/
    AD III/UC III分别为4/11/7/8/15页，输出hash为`4e4139...272a`、`6be86a...f6de`、
    `d76244...83af`、`30a207...0755`、`4f0f98...f8b1`；四份先生成夹具在补UNIFI前后
    byte-stable。Codex用另一Python/pypdf环境运行`--verify-only`，五份均打开、页数、非空文本、
    源/输出hash和证据hash通过；manifest为`content_modified:false`，明确不是sponsor-issued
    standalone synopsis。

95. Worker 01长会话首次fixture mapping输出截断且未落盘，按同会话恢复/no-progress规则仅发
    一次窄补写；最终67项oracle QC通过。12 lane全部runnable：UC Ib保持真实独立DOCX，另五
    lane只把验收后的摘要页PDF作为product input；完整protocol仅保留provenance/oracle层。
    `RUNNABLE_COVERAGE_GAPS=[]`，UC authority使用显式local archive路径。当前已并行启动W2
    （parent/async/runtime/process isolation）与W3（durable product workflow/receipts/all-chapter/
    atomic adoption）统一shell runner session `36169`；二者不调用产品AI且写集互斥。W4必须
    等二者结束后再派发。

96. 用户于W2/W3运行中手动要求无损暂停；为避免半写，未强制终止两路且未启动W4/产品AI/
    浏览器。W3先自然结束，marker `WORKER_03_E3_DRIVER_COMPLETE`，session
    `20260723_064138_bfed0f`；W2后自然结束，marker `WORKER_02_E3_ISOLATION_COMPLETE`，
    session `20260723_064138_5f26cc`。所有E3 runner当前均已退出，无后台模型/runner需要恢复。

97. W2落盘parent异步spawn、runtime isolation、recursive content SHA、process ownership及
    isolation QC；W3落盘durable client、server-derived receipts、child/pipeline/contract probe
    与mock behavior tests。Codex暂停前独立复跑：Worker 01 oracle 67/67、W2 isolation 12/12、
    W3 behavior 26/26，合计105项通过；parent/child/pipeline/probe/durable/receipt/isolation/
    stable-hash/process-ownership全部`node --check`通过。关键文件hash已记录于本轮终端证据，
    其中parent `dd0d0b...d5eca`、child `8d79b0...ce821`、pipeline `864bbe...717e`、durable
    client `33ebf3...3aad`、receipts `ebda6b...d391`。未发现task范围`.tmp/.part/.DS_Store`。

98. 暂停边界必须保持：上述105项是确定性实现基线，不等于Codex已完成W2/W3源码逐项验收，
    也没有跑parent two-lane dry canary、真实产品AI、CT.gov产品链、OCR/Hy-MT2/Flash、浏览器、
    DOCX或Word。W4仍是PENDING，尚未派发；Grok执行经理第二轮、Qoder/Reasonix/CodeBuddy最终
    多视角复核及上线均未开始。恢复后第一步必须读W2/W3当前源码与报告，重点复现cleanup所有权、
    PID start identity、stable root范围、locator crash/retry/result reconcile、atomic accept-and-apply、
    all-chapter/exclusion、dry-mode不得假通过和receipt来源真实性；发现问题只做同会话定向返修。

99. 2026-07-23 从用户手动暂停锚点恢复。已重新读取全局`/Users/smkzw/.codex/AGENTS.md`、
    项目`AGENTS.md`、`PAUSE_CHECKPOINT.md`、本记录与`SOFT_PAUSE_RESUME.md`，并确认没有
    E3 runner残留。恢复动作严格从W2/W3源码验收开始，没有重复派发初始任务、没有调用产品AI。

100. Codex与只读SubAgent已复现W2阻断问题：真实DurableMwClient写出的locator schema与
     parent `checkResume`不兼容；parent新建runtime/project后再读旧locator，冷恢复会重跑；
     `QC_MAX_CONCURRENCY=NaN`或dry-run未知lane可零执行假绿；PID `startIdentity`只是登记时间，
     发信号前不核对OS进程启动身份；child/Chrome进程树与Chrome profile未纳入父级所有权；
     端口查空后立即释放且健康检查接受任意`<500`响应；stable hash跳过dotfiles及遍历错误。
     Codex反例还证明修改`.hidden`后`hasChanges=false`，null provider/model的AI receipt可通过。

101. Codex复现W3阻断问题：child先调用`submitCandidateDurable`再调用`startAndPoll`，同一候选
     逻辑会POST两次；候选、synopsis及accept/apply幂等键使用`Date.now()`且synopsis内外可能
     不是同一个key；locator非原子写且损坏后静默清空；failed/cancelled会走新start而非显式retry；
     ServiceReceipt只验证字段存在不验证非空/固定身份/哈希/结果绑定；部分章节可静默excluded后
     继续通过；accept-and-apply未验证双状态同一事务结果；rewrite未走durable poll/receipt；
     contract probe把`full_mode_deferred`记为pass。

102. 已形成并通过guard preflight的两份合并返修合同：
     `prompts/execution/mw_e3_live_12lane_harness_20260723/worker_02_followup_acceptance_02.md`
     与`worker_03_followup_acceptance_02.md`。均复用原Hermes/aishuo/cms-model会话，不新开上下文：
     W2 session `20260723_064138_5f26cc`、统一exec session `85220`；W3 session
     `20260723_064138_bfed0f`、统一exec session `61527`。输出分别落到同名`runs/execution`
     报告，hard wait 7200秒、max-turns 128。按全局规则不发送进度询问，只观察进程退出与完整
     marker；完成后Codex必须审diff并运行反例，成员完成标记不自动构成接受。

103. 第二只读SubAgent对W3做了当前FastAPI OpenAPI对照，新增三个P0：pipeline仍调用多组
     已不存在的旧路由（`/commit`、`/search`、`/prepare`、`/translate`、`/documents`和旧
     working-copy路径）；通用durable client轮询到completed后没有强制读取`/result`，且正式
     artifact的`suggestion_ids`数组形态不被提取器识别；synopsis正式成功态`review_ready`
     不在状态机内，rewrite又只把202受理当完成。其余确认问题包括：contract probe把任意4xx
     当合同存在；mock `/result`被通用status regex吞掉；T26布尔断言恒真；`minChapters`未消费。
     当前W3返修已在运行，不发送并发模型消息；结束后Codex必须以真实OpenAPI精确method/schema、
     completed→result调用序列、`review_ready`和rewrite全生命周期作为附加验收，未关闭则使用
     原session一次合并定向follow-up。

104. Codex对W2 `acceptance_02`报告执行源码级终审后拒绝放行，确认报告声称“10项已修复”
     与真实编排链不一致：parent以`pid:0`登记Chrome占位而登记函数明确拒绝零PID，真实lane会
     在服务启动阶段抛错；child PID仍在进程退出后才登记；nonce检查对任意HTTP 200无条件
     放行；API/Vite在held socket尚未释放时spawn，存在与自身保留端口竞争；allocation manifest
     仍是普通`writeFile`而非原子提交；临时目录清理权限仍以宽泛路径字符串判断。现有12+10项
     helper测试全部通过，反而证明测试未覆盖parent真实编排。已新建并通过guard preflight的
     `worker_02_followup_acceptance_03.md`，复用原W2 session
     `20260723_064138_5f26cc`，统一exec session `98337`，要求补真实parent smoke、进程存活期
     登记、外来200拒绝、端口碰撞、严格resume/manifest及失败保留runtime。W3
     `acceptance_02`仍在原session `20260723_064138_bfed0f`有效执行窗口内，未发送状态消息。

105. W3 `acceptance_02`自然完成并自报49项behavior+67项oracle通过，但Codex以当前FastAPI
     `/openapi.json`和`services/api/app/main.py`逐项对照后拒绝放行：可执行pipeline仍调用
     `/authoring-journey/commit|search|prepare|translate|documents`及旧working-copy路径，而当前
     合同是`stages/{stage}/commit`、`competitor-search`、references preparation/translation
     batches、`greenfield-document`和`working-copies/{section_id}`；durable client的
     `_pollJob`在completed时仍返回status DTO而不取`/result`；synopsis真实成功状态
     `review_ready`仍未识别；candidate locator在candidateSets仅存内存时即被清除；receipt的
     `JSON.stringify`数组replacer会丢失嵌套响应字段；章节无映射仍被自动排除。合同probe仍以
     普通4xx证明路由存在。已形成并通过guard preflight的
     `worker_03_followup_acceptance_03.md`，复用session
     `20260723_064138_bfed0f`、统一exec session `61678`，要求逐路由对齐当前OpenAPI、真实
     completed→result、`review_ready`、原子双状态/重放、持久reconciliation、递归canonical
     receipt hash、设计驱动章节矩阵及隔离runtime的无产品AI真实API集成测试。另启动只读
     SubAgent `019f8f0b-337c-7730-8537-54af8bc79481`做非重复的传播/边缘case审计。

106. 只读SubAgent完成W3真实contracts传播审计并关闭，新增可复现阻断：当前
     `MedicalWritingRevisionRequest`要求`user_instruction/requested_by`且禁止pipeline自造的
     `prompt/source_locator/note_text/actor/idempotency_key`；真实candidate artifact直接返回
     `suggestion_ids[]`；原子采纳响应把working copy放在嵌套`working_copy`；rewrite合同禁止
     `idempotency_key`；medical review、admission、greenfield create、working-copy save和
     competitor search共7类payload均会被当前Pydantic拒绝。checkpoint恢复会把既有
     completed stages覆盖成仅`project_creation`；preparation还遗漏
     `completed_with_review_required`和`completed_with_manual_upload_required`终态，真实
     artifact在`items[].artifact_id`而非`batch.artifacts`。收据collector未核对lane且要求
     生产status合同明确不公开的input/output hash。以上属于`acceptance_03`完成后的必验反例；
     当前W3正在同一session执行，不插入第二条并发模型消息，结束后一次性比对，缺失时才合并
     回投。

107. Codex对W2 `acceptance_03`执行了真实父流程而非helper模拟：使用隔离的双stable root、
     独立runtime/output和单一`RA_I_SCRATCH` lane运行
     `final_release_12lane_parent.mjs --dry-run`。结果确定性失败为
     `service-startup-failed:timeout waiting for http://127.0.0.1:59724/ (pid=78566)`；
     readiness错误地要求Vite根页面返回JSON，并把`npm`父PID当作监听PID，而真实监听者是其
     node/Vite子进程PID 78603。父脚本退出报告后shell、parent、npm、Vite整组仍存活，证明
     当前parent smoke没有实际调用parent且process-tree cleanup失效。Codex只终止本次测试
     创建的PGID 78555，并将报告及ownership证据复制到
     `records/active_slices/medical_writing_e3_12lane_harness_20260723/evidence/w2_real_parent_failure/`
     （SHA256分别为`d5df7048...dac94`和`1b8267d9...1c1`）。已形成并通过guard preflight的
     `worker_02_followup_acceptance_04.md`，复用W2原session
     `20260723_064138_5f26cc`、统一exec session `34464`；返修必须覆盖service-specific
     readiness、listener descendant归属、真实parent smoke、全进程树清理、严格manifest/
     resume/locator fail-closed、allocator-issued删除权限及成功/失败两条真实父流程证据。

108. W2/W3返修等待期间启动的只读W4验收层审计发现W1来源权威谱系存在空循环假绿，
     Codex已本地复现：五个PDF摘要输入的authority class已升级为
     `versioned_exact_synopsis_extract`，但`buildProtocolAuthority()`只识别旧
     `authoritative_protocol_synopsis_pages`，导致六个synopsis lane当前
     `protocol_authority`均为null；oracle QC又对null直接`continue`，因此67项通过不能证明
     authority存在。W4自身还存在同步test承载async callback、源码字符串存在性断言和旧四
     适应症配置渗透等问题，当前禁止派发。已形成并通过guard preflight的W1窄返修
     `worker_01_oracle_authority_acceptance_01.md`，复用原W1 session
     `20260723_054136_f75878`、统一exec session `77854`，要求五个PDF extract逐层绑定
     protocol→extraction manifest→extract→lane，精确cardinality、文件hash/page count和
     负例，不改变UC Ib独立DOCX产品输入。并行技术核对采用Node与Vite官方文档：Vite根入口
     本来就是HTML，`--strictPort`只保证占用时退出；Node detached子进程在POSIX形成新进程组，
     管道stdio必须被消费或重定向。该证据支持W2按服务类型判定readiness并按进程组清理，
     而不是要求Vite JSON或只跟踪npm wrapper PID。

109. W3 `acceptance_03`自然完成并自报50 behavior+5 OpenAPI+67 oracle通过，但Codex再次
     以真实源码/服务合同拒绝放行。当前执行链仍把preparation真实
     `completed_with_review_required/completed_with_manual_upload_required`终态漏掉，并从
     不存在的`preparationBatch.artifacts[]`读取artifact而非`items[].artifact_id`；恢复时
     checkpoint既未回填本地stage/artifact状态，又在首个save把历史覆盖成仅
     `project_creation`；每个stage完成也不立即持久化。即时completed和retry仍可能返回status/
     内嵌result而不强制读取权威`/result`；atomic adoption真实响应的working copy是嵌套对象，
     child却按扁平字段校验；失败的reconciliation随后仍被`clearLocator()`强制改成reconciled；
     缺章节映射仍被自动写成excluded；rewrite retry不核对结果即标完成；required-stage检查把
     started/failed/skipped trace的stage名也当完成。现有OpenAPI测试只证明路径存在，不证明
     pipeline payload通过Pydantic。已草拟`worker_03_followup_acceptance_04.md`，要求精确
     payload合同、阶段级checkpoint、八类crash/resume、嵌套原子采纳、真实terminal/artifact、
     receipt适用性及原子evidence commit；因该返修与正在运行的W1 authority修复共享config，
     当前未派发，必须等W1自然结束后通过preflight并复用W3原session一次性回投。

110. W1 authority窄返修自然完成，Codex独立导入manifest并复跑`node --check`与oracle QC后
     接受：6个摘要泳道中精确5个PDF extract lane具有非空protocol authority，UC Ib独立DOCX
     保持null；五条记录均绑定NCT、协议路径/hash、摘要页范围、extract路径/hash与manifest
     locator，且`is_product_input=false`。产品输入仍是5个extract PDF+1个独立DOCX，没有把
     完整protocol注入产品。oracle QC由67增至80项且0失败，新增6个负例，空循环假绿已关闭。
     W1最终报告为`worker_01_oracle_authority_acceptance_01.md`，marker
     `WORKER_01_ORACLE_AUTHORITY_ACCEPTANCE_01_COMPLETE`。后续W3/W4必须冻结并复跑该80项
     基线，不能再以旧67项作为W1接受证据。

111. W1共享配置写入结束后，W3 `worker_03_followup_acceptance_04.md`通过guard preflight并
     复用原session `20260723_064138_bfed0f`派发，统一exec session `55708`。本轮是合并后的
     唯一返修消息，覆盖真实preparation/translation终态与`items[].artifact_id`、阶段级原子
     checkpoint、立即completed/retry强制`/result`、嵌套working_copy原子采纳、失败
     reconciliation不得升级、设计驱动章节适用性、rewrite真实结果、receipt适用性、4xx/schema
     poll错误、真实Pydantic payload合同及八类crash/resume反例。禁止产品AI/CT.gov/OCR/
     translation/browser/Word。按全局规则不发送进度询问，完成后Codex必须复跑真实合同和恢复
     反例，不能以成员marker自动接受。

112. 为防W3后续对共享`config.mjs`产生无意回归，已把Codex接受时的W1三文件只读快照备份到
     `records/active_slices/medical_writing_e3_12lane_harness_20260723/evidence/
     w1_authority_accepted_20260723/`。SHA256：config
     `672dceef...d50f0c`、oracle manifest `d76e2d58...b43cf`、oracle QC
     `0fc97896...c2024`。该快照只用于diff/恢复证据，生产执行仍使用当前源码；W3结束后必须
     重跑80项并核对authority相关差异，不能因共享配置改变而静默退回空循环。

113. W3 `acceptance_04`自然完成并自报151项通过，但Codex逐函数复核后仍拒绝放行。决定性
     缺陷包括：`startAndPoll`即时完成及轮询完成仍允许body/status代替权威`/result`，
     `retry()`返回status而非result；`markStageComplete()`未await且吞掉checkpoint写入错误；
     resume只恢复ID而不恢复后续所需studies/items/sections；所谓Pydantic校验只检查
     `undefined`，崩溃恢复多为源码字符串或手工布尔模拟；global `durableClient`被main内
     `const`遮蔽；evidence普通`writeFile`不具备原子/持久提交；status/result hash相互替代；
     preparation source仍残留旧`artifacts[]`；嵌套adoption字段缺失时仍可通过；candidate失败
     后仍完成且export从未完成；allocation attempt/project lineage未被checkpoint强制验证。
     因此151是测试数量，不是可恢复生产编排的有效证据。

114. 已恢复并补全`worker_03_followup_acceptance_05.md`，首次guard preflight因未明确要求读取
     `/Users/smkzw/.hermes/SOUL.md`而正确失败；补充全局AGENTS、SOUL及项目AGENTS的明确路径后
     preflight通过。任务继续复用Hermes/aishuo/cms-model原session
     `20260723_064138_bfed0f`，统一exec session `33942`，runner输出
     `worker_03_followup_acceptance_05.md`，hard wait 7200秒、max-turns 128。本轮只接受调用
     真实harness导出函数的结果闸门、Pydantic合同、checkpoint/resume、原子evidence和崩溃测试；
     禁止产品AI、CT.gov、OCR、翻译、浏览器和Word。按全局策略不发送进度询问，只有进程退出、
     完整marker和Codex反例复跑才构成下一步证据。

115. W2 `acceptance_04`自然完成但Codex仍拒绝放行。报告自称“成功真实父流程”的实际证据是
     child超时、`exitCode:null`、非绿色且runtime保留；PS-01只要求父进程退出和报告存在，
     不要求`report.passed=true`，PS-02至PS-08主要仍为源码字符串断言。源码还确认：
     `report.passed=false`不会令父进程非零退出；`checkResume().rejected`被`runLane()`忽略；
     公开`_issueAllocationToken()`允许任意调用者铸造删除权限且未绑定lane/path/root；恢复
     manifest只要`runtimeDir`存在即可把外部目录注册为可删除；locator普通写入且缺少强制
     project/attempt lineage；存活PID检查不会断言失败。因此19+15+10项仍是自测绿而非真实
     W2接受证据。已形成并通过guard preflight的`worker_02_followup_acceptance_05.md`，复用
     session `20260723_064138_5f26cc`、统一exec session `57126`，要求真实绿色父流程、真实
     readiness失败、退出码/报告一致、不可伪造且绑定根路径的清理权限、严格manifest/locator
     与零进程/监听泄漏。不得再以源码字符串或超时非绿流程替代行为验收。

116. W3 `acceptance_05`自然完成；Codex独立复跑其全部命令，确认oracle 80、behavior 50、
     Pydantic 24、payload/crash 16、OpenAPI 5，共175/0，但仍拒绝放行，因为测试语义是假绿：
     Pydantic负例把自己的`assert False`一并catch，extra-field并未提交extra，14个payload由
     Python手工重写而非JS pipeline实际输出，accept-and-apply只做字典类型检查；half-adoption
     测试明确写“不能测试full child”，checkpoint/markStage/clearLocator仍含源码字符串断言。
     实现层仍有：existing-completed `/result`为空时静默返回；checkpoint缺失lineage可通过且
     allocation始终默认为0、child未读取父级attempt；checkpoint加载失败后继续执行；resume
     GET失败降级为ID-only对象；无最终evidence manifest/hash inventory；full path仍接受旧
     `artifacts[]`；receipt同步角色规则前后矛盾且status hash未独立复核；采纳未比较响应hash、
     未核对选中/未选中suggestion状态、未幂等重放；candidate stage不要求与expectedIncluded
     精确集合相等。已形成并通过preflight的`worker_03_followup_acceptance_06.md`，复用session
     `20260723_064138_bfed0f`、统一exec session `7367`，要求共享真实payload builder、真实
     parser/Pydantic负例、八个真实崩溃点、完整恢复、原子evidence manifest、严格receipt、
     sibling/replay和精确章节覆盖。禁止产品AI及外部运行。

117. W2 `acceptance_05`自然完成，Codex独立复跑其24/15/9项均为0失败，但再次拒绝接受：
     PS-01注释明确允许`report.passed=false`且断言只核对exit/report一致；PS-02没有制造readiness
     失败，实际是servicesReady后child超时；所谓私有`_createAllocation/_registerAllocatedDir`
     在模块末尾公开export，任意importer仍可铸造清理权限；IS-20至IS-24仍是源码字符串断言；
     恢复时每次重生attemptId，导致旧locator与新attempt必然mismatch；拒绝locator分支在统一
     finally前return，held ports依赖强制进程退出；PID检查不覆盖孤儿listener；PS-08内部和
     runner重复累计，8个test显示为9 passed。已形成并通过preflight的
     `worker_02_followup_acceptance_06.md`，复用session `20260723_064138_5f26cc`、统一exec
     session `13136`。本轮要求精确绿色父流程、确定性readiness失败、child timeout、真正恢复、
     immutable positive allocation lineage、无公开路径注册、统一清理、端口/descendant检查及
     一次一计数；禁止源码字符串作为行为证据。

118. 用户新增硬路由要求：不晚于2026-07-24 06:00（Asia/Shanghai），本项目所有执行/会商
     机制中原`Hermes/aishuo/cms-model`角色全部改为现有
     `Qoder/qwen3.8-max-preview`。已核实QoderVIP由
     `/Users/smkzw/Downloads/QoderVIP/start.command`启动，现有`qodercli`进程PID 8003位于
     QoderVIP会话谱系，没有新建替代进程。该覆盖已写入
     `/Users/smkzw/Documents/AI Cache/Codex x Hermes/AGENTS.md`的
     `Active Qoder CMS-Model Replacement Override`：所有新派发、返修、续跑、会商、审阅及测试
     立即切换Qoder；本指令前已派发的W2 acceptance_06（exec 13136）与W3 acceptance_06
     （exec 7367）仅允许自然完成当前完整pass以避免损失，完成后不得再向Hermes发follow-up。

119. 用户随后给出更精确且优先级更高的时间窗修正：北京时间2026-07-24 01:00前不得使用
     `Qoder/qwen3.8-max-preview`；01:00起，所有原本需要
     `Hermes/aishuo/cms-model`的新派发、续跑、返修、执行、会商、审阅和测试切换为现有
     QoderVIP会话的`qwen3.8-max-preview`。收到修正时为2026-07-23 22:44 CST，本轮尚未向
     Qoder派发W2/W3返修，因此无Qoder任务需要撤销。当前W2 acceptance_06继续使用
     Hermes并自然完成，符合01:00前窗口；跨越切换点的已在途完整pass不因路由切换中断，
     但01:00后不再向其Hermes session发送follow-up。项目`AGENTS.md`已同步改为精确双时间窗。

120. Codex完成W3 acceptance_06源码级复核并否决其“199/0”放行结论。直接证据包括：
     `final_release_12lane_behavior_acceptance_06.mjs`至少3个async测试误用不等待Promise的同步
     `test()`；D3、D7、D10、D11及章节缺失场景以手工字符串/文件/布尔值模拟结果而未调用child
     共用执行路径；D1只断言任意Error而非精确`UnresolvedResultError`；Pydantic仍校验Python
     手工重建对象而非pipeline实际JS payload；八崩溃点、证据manifest独立重算、同key adoption
     replay、非选中siblings不变等仍无有效行为证据。已形成并通过preflight的
     `worker_03_followup_acceptance_07.md`，于2026-07-23 01:00切换点前复用原
     Hermes session `20260723_064138_bfed0f`派发，统一exec session `58024`。本轮只发一个
     自包含合同，不发送状态询问；要求共用可执行helper、真实故障注入、JS builder到Python
     parser验证、异步红哨兵和一对一计数。结果仍须Codex源码与运行验收。

121. W2 acceptance_06报告称13/0、14/0、7/0；Codex独立重跑同样为绿，但源码复核否决放行：
     `process_ownership.mjs`仍公开export `_initAllocation/_allocatorCreateDir/
     _allocatorResumeDir`，所谓marker只是可由任意importer伪造的已知JSON；`allocateLane()`恢复时
     仍生成新的per-process `attemptId`，而`runLane()`以该新ID校验旧locator；PS-05虽然命名为
     “resume success”，实际只执行第一次parent并检查manifest/marker，没有第二次运行；PS-02
     注释称使用确定性fault injection，实际只改`VITE_API_PROXY_TARGET`，失败依赖环境而非指定
     readiness分支。另有evidenceDir可缺省、Chrome profile未完整绑定及resume成功后清理策略问题。
     已形成并通过preflight的`worker_02_followup_acceptance_07.md`，于01:00切换点前复用原
     Hermes session `20260723_064138_5f26cc`派发，统一exec session `63466`。仅修上述根因并
     要求真实两次parent恢复、marker/manifest伪造攻击、确定性readiness失败、精确导出面和零泄漏。

122. W4派发前置核查发现W1配置哈希已因W3对同步/持久服务receipt角色的调整发生漂移：
     当前`final_release_12lane_config.mjs`为
     `53e8663d375788155c2c769b7240f4a4df6d1f26571f850cdc7e07790a4bfaf7`，不再等于冻结值
     `672d...`；oracle manifest与oracle QC哈希未变，Codex重跑仍为精确80 passed/0 failed。
     因W3 acceptance_07仍在修改中，当前不提前重冻W1；待W3最终验收后必须再次重跑80项、
     记录最终配置哈希并更新W1权威快照，之后才可解除W4的
     `W4_ACCEPTED_SOURCE_HASH_DRIFT`停止门。

123. W3 acceptance_07自然完成并报告261/0，但Codex按import graph再次否决。新
     `behavior_helpers.mjs`只被acceptance_07和payload emitter导入，真实`child.mjs`/
     `pipeline.mjs`未调用source/export/candidate/adoption/evidence verifier；所谓
     `PAYLOAD_BUILDERS`仍是测试helper的平行对象而非pipeline POST实际builder；八个“crash”
     case实际是八种不同单元测试，不是project/search/preparation/translation/candidate/
     pre-adopt/post-adopt/post-evidence八个编排断点；adoption未实际同key重放；evidence
     transaction未成为child唯一提交及locator清理路径；export verifier信任调用方布尔值；
     旧acceptance_06、behavior source-string与payload simulation仍被纳入总数。已形成并
     通过preflight的`worker_03_followup_acceptance_08.md`，于01:00前复用Hermes session
     `20260723_064138_bfed0f`派发，统一exec session `77732`。本轮要求真实import/call接线、
     pipeline唯一payload builder、精确八断点恢复、真实HTTP同key replay、evidence提交后
     locator清理、独立hash计算和排除全部旧假证据套件。

124. W2 acceptance_07报告13/0、14/0、7/0且Codex独立重跑一致，但源码复核再次否决其
     “Symbol不可伪造”结论：`process_ownership.mjs`同时公开export真实`_ALLOC` Symbol与
     `_getAllocatorChannel`，任何ESM importer均可调用
     `_getAllocatorChannel(_ALLOC).addOwnedDir(lane, arbitraryExistingPath)`后再调用公开
     `cleanupLaneEphemeralDirs(lane)`删除任意预存目录；现有测试只用错误Symbol攻击，且反而
     要求`_ALLOC`必须导出，属于确定性假阴性。已形成并通过preflight的
     `worker_02_followup_acceptance_08.md`，在2026-07-24 01:00切换点前复用原Hermes session
     `20260723_064138_5f26cc`派发，统一exec session `7304`。合同要求真正的闭包权限边界、
     不公开注册/采纳/清理能力、遍历全部公开API的预存目录攻击红哨兵，同时保持真实两次parent
     恢复、确定性readiness失败、timeout、malformed locator与零泄漏证据。W3 acceptance_08
     仍在原Hermes session `20260723_064138_bfed0f`、统一exec session `77732`独立执行；
     两者均在01:00前发出，可自然完成一次，但切换点后不得再向Hermes发送follow-up。

125. W3 acceptance_08自然完成但未修改源码；原Hermes session累计已有616条消息，模型明确
     报告上下文不足，确认child仍未导入共用verifier、pipeline仍未拥有唯一payload builder、
     八断点恢复/真实同key adoption replay/唯一evidence transaction/Pydantic fail-closed等均
     未完成。Codex据此否决该轮，不把“COMPLETE”marker误当验收。由于当时仍在01:00前窗口，
     已将全部残余压缩为新鲜、无历史污染的实现合同
     `worker_03_fresh_completion_09.md`并通过preflight，按规则新开
     `Hermes/aishuo/cms-model`完整pass，统一exec session `70509`。该合同先要求child/pipeline
     真实接线，再以唯一acceptance_09行为套件证明八个精确编排断点、真实HTTP幂等采纳、
     独立export hash、evidence原子提交及实际Pydantic endpoint拒绝矩阵；不再续接已耗尽旧会话。

126. 用户于2026-07-24再次修正cms-model替换时间：北京时间2026-07-25 01:00前，所有原本
     路由到`Hermes/aishuo/cms-model`的新任务、续跑、返修、会商与测试继续使用Hermes；
     2026-07-25 01:00起才切换为现有QoderVIP `qodercli`的
     `qwen3.8-max-preview`。该后发指令覆盖此前2026-07-24 01:00边界。Codex于
     2026-07-24 15:02 CST重新完整读取全局及项目`AGENTS.md`，并仅修正项目覆盖规则与恢复锚点
     的日期，不改冻结通用路由规则；当前不会提前调用Qoder。

127. 用户随后重置当前任务边界：先停止所有外部执行/会商，只允许Codex及Codex
     subAgent，并明确不再搜索、检查或修复医学工作台总系统/子系统的安全漏洞、后门等，
     因本项目定位为本地使用；当前重遍历只看功能开发、真实医学写作易用性、独立产品AI
     能力和医学/科学性。Codex据此终止W2/W3工程安全审计作为发布主线，不再追逐旧安全
     harness。当前三路Codex subAgent分别只读核对前端用户旅程、后端独立AI链和医学科学性/
     DOCX，均明确禁止安全审计；主线程同步推进，不等待其结果。

128. 用户最新补充：本轮三个Codex subAgent必须完整完成；完成后重新读取全局
     `/Users/smkzw/.codex/AGENTS.md`并按当时最新规则恢复执行/会商机制，继续既定医学写作
     目标。期间不得高频询问或催促成员；执行状态通过完整结果一次性收敛。该指令覆盖第127项
     “长期停用外部机制”，但不撤销“不做工程安全漏洞审计”的产品范围限制。

129. 重新遍历建项第一步后确认真实功能断点：`MedicalWritingMinimumProductFactPacket`
     已建模IB可选和无IB事实对话，前端也显示“可选：研究者手册”，但没有上传、解析、替换、
     暂不提供、内容核对或将IB原文提供给独立AI的链路；fact-intake此前只把`ib_source_ids`
     字符串交给DeepSeek，并没有向provider提供对应原文，模型实际上不能从IB提取事实。

130. 已完成IB/最小事实首个闭环实现：
     - `SourceRegistryService.register_medical_writing_document`支持PDF/DOCX研究者手册，
       保存原文件、稳定entry/span/locator、解析器版本和原文片段；
     - 仅进行技术可读性、文件角色、当前适应症的轻量内容核对；IB可能覆盖多适应症时只提示，
       不误判为不可用，医学经理可逐项确认并填写不少于10字符的沿用理由；
     - `MedicalWritingMinimumProductFactPacket`新增IB核对状态、提示码和沿用理由，进入framing
       草稿；无IB时可选择“暂不提供IB”并继续公开调研和最小事实对话；
     - fact-intake新增source resolver，把已登记IB的有界原文、source_id和locator直接交给
       独立DeepSeek；任何`source_extracted`候选必须引用实际提供的source_id，虚构来源在
       服务端失败关闭；
     - 前端第一步新增上传/替换、解析进度、轻量提示确认、暂不提供及“提取关键事实”入口。

131. 验证：Python编译通过；新增真实DOCX内存IB登记测试、原文进入独立AI envelope测试和
     虚构source_id反例；`test_source_intake.py + test_medical_writing_fact_intake.py +
     test_medical_writing_authoring_journey.py + test_user_project_authoring_bootstrap.py +
     test_frontend_medical_writing_contract.py`合计159 passed；Vite生产构建成功。测试加载应用时
     发现合同类`RevisionAcceptAndApplyRequest`已存在于`models.py`但未从合同包导出，直接造成
     FastAPI import失败，已补齐`__init__.py`导入与`__all__`，属于功能启动阻断修复。

132. 本轮三路Codex subAgent已于2026-07-24 15:48 CST前全部完整结束并关闭：前端旅程审阅、
     后端独立AI链审阅、医学科学性/DOCX审阅。三路共同P0为：摘要导入必须真正文件优先；
     竞品证据必须在最终PICOS前可见；typed I期Part必须成为摘要、正文、SoA与流程图的单一
     权威；当前研究设计不能被既往研究资料污染；真实E3、桌面浏览器E4和Word E5仍是发布门。
     全局`/Users/smkzw/.codex/AGENTS.md`与项目覆盖`AGENTS.md`均已重新完整读取；按用户最新
     指令恢复执行/会商，但继续严格排除安全漏洞、后门和攻击面审计。

133. 常驻医学写作实例现为前端`http://127.0.0.1:5174/`、后端
     `http://127.0.0.1:8911/`；release verifier通过，runtime schema 16、31项能力、客户端
     合同门均通过，独立AI实际身份为`deepseek/deepseek-v4-pro`、
     `openai_compatible`且`codex_runtime_dependency=false`。本轮后端修改后已两次受控重启，
     端口继续常驻，不把旧8910/5180状态作为当前产品判断。

134. 已用真实项目完成IB E3首轮：创建
     `proj_user_f5c768c5bc9f`（MY004567片/类风湿关节炎/II期），上传真实4.0版DOCX研究者
     手册，登记为240个可追溯source span；文件角色和适应症均matched。独立
     `deepseek-v4-pro`运行`mwfactrun_218d76b642c78bf0`成功引用真实span，但暴露五类医学
     语义错误：把既往40/80 mg测试剂量写成RP2D、把既往QD推成当前给药频率、把IB标题和
     版本写入方案标题/版本、把既往II期设计/人群写入当前研究设计/人群、把最低SAD剂量
     “可视为”FIH起始剂量。结论：来源ID正确不等于医学语义可采用。

135. 已将IB事实检索从“登记顺序前24段”改为“封面身份锚点+结合本轮问题的给药、安全、
     PK/PD、非临床、既往临床主题相关段”，仍受24段/60000字符和稳定顺序约束。提示词升级
     为`medical_writing_fact_intake_v0_3_ib_semantic_boundary`；服务端新增确定性隔离门：
     IB来源不得覆盖当前方案元数据、分期、目的、设计、人群或区域；RP2D/FIH起始剂量/
     给药方案等高影响来源事实必须含明确原文术语，含“很可能/可视为/推测”等措辞时隔离。
     有效产品类型、机制、PK/PD和安全事实继续保留。新增测试覆盖IB版本/既往设计污染、
     测试剂量冒充RP2D和明确RP2D原文可保留；聚焦44项全部通过。

136. 已初始化`mw_ib_semantic_gate_20260724`医学语义会商，真实E3错误、源码、边界和验收
     标准均写入`context/mw_ib_semantic_gate_20260724_conference_context.md`。现有QoderVIP
     `qodercli`通过AppleScript接收独立审阅合同，Hermes/OpenCode Go
     `deepseek-v4-flash`参与者通过guard preflight后后台执行；不发送进度询问，主线程继续
     产品实现，成员报告只作证据，Codex保留最终医学和生产验收权。

137. 真实MY004 IB第三轮独立AI已完成：
     `mwfactrun_e22e1221e7be10f5`，provider/model严格为
     `deepseek/deepseek-v4-pro`，提示版本为
     `medical_writing_fact_intake_v0_3_ib_semantic_boundary`。本轮只返回小分子IRAK4
     抑制剂、口服片剂、作用机制、PK/PD和安全性等产品事实；不再返回方案标题/版本、
     当前设计/人群、RP2D、FIH起始剂量或当前给药频率，也不再提出无关设计问题。
     高影响数值继续保持unknown并阻断对应条款；输出已切换为监管中文。首轮遗留的不安全
     开放候选由服务端隐藏，最新同字段候选按轮次替代。该结果证明语义隔离门对真实独立AI
     生效，但“既往研究事实”的专门结构化容器仍需结合会商意见评估，不能重新污染当前设计。

138. 已重构“导入方案摘要”建项为真正文件优先：
     - 新增独立预建项入口`/api/medical-writing/project-intake/synopsis`及状态/结果接口；
       文件先进入可恢复异步解析，不在项目列表生成占位项目；
     - 新增`MedicalWritingSynopsisProjectCreateRequest`和一次确认接口；用户确认后服务端
       幂等创建正式项目、绑定原始摘要、写入提取候选，并把已完整的framing/PICOS直接
       提升为正式研究事实，只有真正缺失的字段保留为后续草稿；
     - 新建项目弹窗的摘要模式不再要求先填写药物、适应症和分期；改为文件选择、真实进度、
       AI预填、关键研究框架/PICOS修订和一次确认，明确用户选择即最终医学决定，不再出现
       第二次“待医学批准”；
     - 相关Python编译、126项前后端/摘要/建项回归及Vite生产构建通过。桌面1728×1117
       浏览器已打开真实弹窗，未见溢出或布局遮挡；真实D017摘要E3正在以新入口运行。

139. 当前常驻后端已受控重启并加载上述新API，runtime schema 16，backend build
     `api-e915735f2602cc3f`，5174前端继续运行。启动约需30秒完成既有持久任务恢复，不能
     把启动等待误判为端口故障。真实D017文件已由新预建项入口解析出96个source span，
     intake=`mwintake_81be1b50a0e05c1c3256a6d7`，
     job=`mwjob_960f9e430bc0e2b24743ee00`；当前处于独立AI synthesis，完成后必须继续
     确认项目创建、正式事实状态和浏览器重连，不得只以单元测试关闭该项。

140. 真实D017首轮独立AI结构化在严格来源忠实性门被正确阻断：
     `picos.exploratory_endpoints[1]`把PopPK目的原文压缩改写。根因不是前端或DeepSeek
     连通性，而是服务端`materialize_anchored_synopsis_fields`仅在列表项数量不足时恢复；
     数量相同但某项被改写或证据映射缺失时会直接跳过。现已改为对每个锚点字段逐项恢复
     原始顺序、完整原文和准确source/locator绑定，严格validator保持不变；新增“等数量第二项
     改写”“原文正确但field evidence缺失”“多字段changed状态污染”三个subAgent回归，
     源忠实性与runner组合49项通过。另修复失败作业恢复后`attempt_count`不递增的审计错误并
     增加回归。后端已加载来源恢复修复，并只恢复同一D017失败块；截至2026-07-24 16:40 CST，
     真实`deepseek-v4-pro`调用心跳持续更新，未重复派发，完成后继续一次确认建项与浏览器E4。

141. 完成“设计驱动的动态方案框架”功能与科学性专项审阅，严格未开展安全、后门或漏洞审计，
     且未修改并行中的`ai_task_runner.py`、`medical_writing_synopsis_import.py`、
     `medical_writing_authoring_prefill.py`、`medical_writing_authoring_journey.py`。读取
     StructuredStudyDesign、ProtocolAssemblyPlan、公司方案模板、SoA、流程图、DOCX导出、
     StudyDefinition一致性服务及八组相关测试；专项回归为158 passed/8 warnings。
     但真实函数反例证明现有跨投影测试只检查plan gate可消费，不检查实际成品：III期摘要可
     泄漏I期Parts；完整typed SAD/MAD在自由文本为空时无法生成流程图Part；仅设置结构化
     转组/交叉/OLE标志无法驱动流程图；SoA仍为固定空模板；未填人群/剂量的unresolved Part
     仍允许确定性投影；样本量再估计和适应性设计有module但无design driver。另确认交叉设计
     当前被错误归为“转组治疗”，复杂设计只有布尔值，信息不足以科学生成摘要、正文、SoA和
     流程图。完整定位、证据、最小修复顺序和实际输出级补测矩阵已写入
     `reviews/medical_writing_dynamic_design_projection_review_20260724.md`。下一安全动作是先
     建立唯一结构化设计投影器和复杂设计typed对象，再补I期Parts、条件章节、SoA、流程图与
     DOCX五个实际消费者的端到端回归，不能以现有158项绿测关闭该发布门。

142. 完成真实CMS-D017文件优先建项闭环修订。独立`deepseek-v4-pro`第二次预填运行后，
     已确认摘要标题、总体设计、design archetype、随机、开放标签、低/高剂量组比较、平行组
     和多中心均被锁定为唯一`user_confirmed`来源候选，错误的“双盲/安慰剂”泛化候选不再
     出现；AI仅对确实缺失的ClinicalTrials.gov英文检索词提出
     `Paroxysmal Nocturnal Hemoglobinuria`。真实采纳使journey revision 5→6，写回当前
     framing草稿而非陈旧正式对象，并立即把检索条件由中文改为英文。前端完成条件同时对齐
     后端合同：靶点/作用机制是IB/证据富化项，不再错误标为必填。相关前后端、摘要导入和
     预填组合178项通过，Vite 1885 modules生产构建通过。

143. 真实点击语义继续发现框架提交会把同一次摘要确认形成的PICOS草稿清空，违背“用户以
     修改确认为主、不得重新填写”。已修订`commit_stage`：上游框架变化仍使已提交PICOS、
     语料和成品结论失效并保留`invalidated_dependents`，但任何尚未提交的PICOS草稿作为
     用户/来源工作必须保留。新增服务回归并通过178项。受控重启后release verifier通过：
     frontend `web-8566c4214d9b797c`、backend `api-81aae34ce9e80145`、schema 16、
     31项能力、direct `deepseek-v4-pro` ready且无Codex运行依赖。使用同一真实D017提取结果
     新建`proj_user_0c2edf8d099d`验证：研究框架一次确认后直接完成，PICOS草稿仍存在且只缺
     `estimand_strategy`，英文检索词和结构化设计均正式持久化。

144. 已按全局/项目`AGENTS.md`恢复执行机制并初始化
     `mw_design_projection_unification_20260724`。执行上下文写明只做功能和医学科学性，
     明确禁止安全/后门审计；第一轮执行经理只读拆解唯一规范化投影、复杂设计typed对象和
     五类实际消费者的依赖顺序、非重叠文件所有权、迁移与验收矩阵，不得先写生产代码。
     Grok Build执行经理runner session为`25462`，已通过prompt preflight并在120分钟硬等待
     内运行；不发送状态询问。自2026-07-24 01:00起，后续原
     `Hermes/aishuo/cms-model`执行者按项目覆盖规则改用现有QoderVIP
     `qodercli`/`qwen3.8-max-preview`，不得新建替代Qoder进程；Codex保留最终医学、源码、
     浏览器、DOCX和发布验收权。

145. D017真实浏览器E4已继续至语料准备：在第二步选择“估计目标策略不适用”，填写
     “本研究为探索性剂量比较，现阶段不单独设置正式估计目标框架，统计章节按探索性分析
     目标描述”，勾选医学经理确认后保存；API revision 7显示理由和确认状态均已持久化，
     刷新、重新选择项目并展开高级微调后仍完整存在。随后点击“完成第二步”，revision 8
     进入`corpus`，主要终点和总体设计的`field_states`均保持`confirmed`。真实
     ClinicalTrials.gov检索返回67项研究、48份公开Protocol/SAP，并锁定快照
     `wref_search_42d02b8b17a6f5bfafe6`；宽检索同时包含移植等明显不相关研究，证明后续
     独立AI分诊是必需环节。浏览器点击“启动AI分诊”暴露两个真实功能阻断：前端请求遗漏
     后端必需的`idempotency_key`而HTTP 422；补齐后，耐久任务返回值为Python dataclass，
     HTTP层却错误调用`model_dump`而500。已增加稳定幂等键、耐久结果统一序列化及两项
     回归；前端合同与序列化99项通过，Vite 1885 modules构建通过。需在Qoder Slice A自然
     完成后统一重启前后端，再从同一快照重试真实`deepseek-v4-pro`分诊，不得用Codex或
     执行模型替代产品AI。

146. 设计投影执行经理首轮已完成并由Codex接受：A切片先建立只读
     `NormalizedDesignProjection`、单一归一化入口、typed Phase I Parts权威和未决事实
     精确阻断；B切片再建立转组/交叉/OLE/样本量再估计/适应性设计typed对象；C切片最后
     统一摘要、正文、SoA、流程图和DOCX五类消费者，并按9种设计场景做实际输出矩阵。
     现有QoderVIP会话已确认模型`Qwen3.8-Max-Preview`，通过AppleScript执行`/new`后一次性
     接收A切片合同；完成报告为
     `reviews/qoder_worker01_design_projection_slice_a_20260724.md`，完成标记为
     `runs/execution/mw_design_projection_unification_20260724/qoder_worker01.done`。
     主线程不发送进度追问，只在标记出现后审源码、反例和测试，再决定是否冻结A并派B。

147. D017真实产品AI分诊耐久作业`mwjob_1b09c3bb619d4c21eed97bf5`已完成，
     run=`ct_run_63882297ef5cac61eb09`，严格为`deepseek/deepseek-v4-pro`，
     5/5分块、67/67候选成功，无Codex/执行模型代替；v1结果为direct 13、indirect 38、
     excluded 16。医学复核未接受该篮子：保留51项过宽，部分移植研究误作间接参照，
     同类药物仅因途径不同的排除/保留不一致，长期延展研究被当直接竞品，且出现
     `likely oral/likely same pathway`等无显式来源推断。已将项目产品类型/途径/剂型、
     靶点、目的、人群、干预、对照、主要终点补入AI输入，将提示升级为
     `competitor_triage_deepseek_v4_v2_medical_relevance`，固化不得猜机制/途径、
     非药物模态默认排除、延展研究通常间接、临床相关性与文档可用性分离、中文理由等规则。
     竞品分诊与耐久回归94项通过；完整v1复核及v2验收条件写入
     `reviews/d017_competitor_triage_v1_medical_qc_20260724.md`。官方CT.gov API已实测可返回
     InterventionName/Type、Allocation、InterventionModel、Masking、EnrollmentCount和
     BriefSummary；待Qoder冻结models后扩充候选结构并用同一快照重跑v2。

## 串行产品写入顺序

1. 摘要异步结果原子提交、真实分块、持久恢复、租约所有权/心跳、真实进度、稳定
   任务标识、前端重连和真实产品AI。
2. StudyDefinition指纹绑定、legacy/unbound工作副本隔离、编辑器/导出同源。
3. 医学写作用户采纳即确认，移除错误的额外“待医学批准”，保留版本冻结语义。
4. DOCX分节/分页、流程图可读性和量表连续嵌入修复。
5. 全链差距矩阵中其余P0/P1问题。

## 发布验收原则

- 至少3个非肿瘤适应症、从零与摘要导入两条路径、I期和III期规定设计组合。
- 产品内独立AI完成检索、下载、解析、候选和改写；执行模型只扮演用户和审阅者。
- 每个可见按钮、状态、恢复路径、错误路径、DOCX成品和引用跳转均有真实运行证据。
- 最终多视角复核中，原`Hermes/aishuo/cms-model`角色自2026-07-24 01:00起由现有
  `Qoder/qwen3.8-max-preview`替代，并与其余按当前全局规则保留的
  Reasonix/deepseek-v4-pro、CodeBuddy/Hy3等角色互补；Codex独立验收后才可上线。

## 2026-07-24 本轮续作与执行机制恢复

- 用户已明确：本轮Codex subAgent彻底完成后恢复执行/会商机制；继续按前期目标推进并持续
  读写记录。工程安全、后门、漏洞排查仍明确排除，只做功能开发、真实医学写作工作流、
  独立AI、医学科学性、浏览器和DOCX/Word验收。
- 已重新读取全局`~/.codex/AGENTS.md`、本文件与`SOFT_PAUSE_RESUME.md`。当前时间已超过
  2026-07-24 01:00 Asia/Shanghai，因此需要原`Hermes/aishuo/cms-model`的角色按项目覆盖
  规则路由至既有QoderVIP `qodercli` / `qwen3.8-max-preview`，不得新建替代Qoder进程。
- 既有Qoder Slice A仍在现有会话执行，PID仅作为观察证据；未发现完成marker，不发送
  “进度/继续”消息，不重复派发。完成后Codex必须先审报告、源码和反例，再决定是否冻结A
  并派发B。
- D017独立AI v1业务run `ct_run_63882297ef5cac61eb09`实际已完成，但医学QC判定不合格，
  不得确认。源码已升级到`competitor_triage_deepseek_v4_v2_medical_relevance`，运行服务
  尚未重启，后续必须在同一不可变快照上重新执行v2并比较医学相关性。
- 真实E4又确认一个完整产品缺口：启动HTTP失败后后台run仍可能成功，但前端没有定位器就
  无法恢复；同时成功AI分诊的逐候选分类、理由、匹配维度和证据缺口没有可审核界面。
  已派Codex subAgent `019f9391-5faf-7c81-acd3-9d57f9c64915`在与Qoder不相交的
  `main.py`、`WritingReferencePanel.jsx`和聚焦测试范围内实现“latest恢复 + 逐项审核 +
  一次确认即生效”的完整闭环。不得把v1结果当作已批准数据。
- 分诊v2医学质量门已由Codex subAgent完成只读复核，规范保存于
  `reviews/d017_competitor_triage_v2_quality_gate_spec_20260724.md`。已接受的核心决策是：
  临床竞争关系、Protocol/SAP文档价值、用户决策状态必须正交；OLE、非药物模态、不同
  机制/途径和I/II/III期采用差异化规则；硬性来源/集合/显式字段/跨分块一致性由确定性代码
  执行，临床位置与章节迁移价值由独立AI判断，最终篮子由用户一次确认。v1结果仍未批准。
- AI分诊恢复/审核闭环的首版前端、latest API和140项聚焦回归已返回，但Codex初审未接受
  其确认事务：当前实现先由service按AI分类原子确认和投影，再在HTTP层逐项补写用户的
  direct/indirect覆盖；若补写失败会形成确认状态与最终分类不一致。后续必须把用户最终分类
  纳入`CompetitorTriageBasketConfirmationRequest`和service单事务，再删除HTTP层补写。
  同时应允许用户确认“全部排除、无合适公开竞品”，以免无竞品场景被错误阻断；这需要同步
  放宽corpus triage空篮子合同并保留明确理由。
- Qoder Slice A首轮marker已出现但未通过Codex冻结门：新合同未从包入口导出导致pytest
  收集失败；阶段识别未通过其自写的I/II与FIH反例；legacy fallback未进入真正normalizer；
  sources映射类型错误；非I期残留Part一致性分支不可达；一个未决Part错误阻断未选择Part。
  已通过同一Qoder会话发送一次合并定向返修合同
  `qoder_worker_01_slice_a_remediation_01.md`，不得在返修完成前启动Slice B。
- Qoder返修marker于18:25出现，但仍未通过：唯一入口被误命名为
  `enforce_structured_authority`，`normalize_study_design`不存在，聚焦测试继续在collection
  阶段失败；重复常量仍在，I/II识别逻辑仍错误，报告仍错误声称环境阻塞而未运行测试。触发
  no-progress breaker，不再让同一路由继续修改Slice A。已改派Codex subAgent
  `019f93a9-492f-7782-9190-ad49d3a44a8d`接管同一精确范围，真实pytest通过并生成
  `codex_worker01.done`前不得冻结A或启动B。
- 用户更新Goal：面向“慵懒但专业”的初级/资深医学撰写经理，所有需要写、填、选的内容都
  必须由产品独立AI先给默认推荐版或3–5个候选，用户主要做修改、选择和确认；不得把空白
  表单当作从零开始。此要求新增为后续建项、框架、PICOS、章节、表格、流程图、引用和AI
  改写全流程的共同验收项。
- 动态设计投影Slice A已由Codex subAgent接管修复并经Codex主线程正式冻结。决定性证据：
  `normalize_study_design`唯一公开入口和生产API导入通过；核心projection/structured/
  Phase I 61项通过；assembly/consistency 28项通过（仅既存FastAPI on_event警告）；
  I期、I/II期、FIH与II/III/IV直接反例符合预期。接受报告为
  `reviews/codex_subagent_design_projection_slice_a_remediation_20260724.md`，
  marker为`codex_worker01.done`。Qoder原报告保留为失败证据，不作为接受依据。
- 已向同一Codex subAgent串行派发Slice B：新增并迁移治疗转组、交叉、OLE、样本量再估计、
  适应性设计typed对象，扩展唯一normalized projection、module/driver和一致性阻断；不得
  修改摘要、正文、SoA、流程图、DOCX消费者。只有真实测试和`codex_worker02.done`通过后
  才可进入Slice C。
- 用户最新AI-first要求的只读全链Gap审阅已完成，报告为
  `reviews/medical_writing_ai_first_lazy_writer_gap_audit_20260724.md`。当前结论：系统已具
  最小三项建项、摘要AI提取、部分prefill、竞品AI分诊、富文本3–4候选、确定性表格模板和
  流程图基础，但仍处于“部分AI预填 + 大量人工补空 + 局部AI改写”状态。已锁定13项P0、
  12项P1；动态设计主线稳定后按统一候选包契约依次落地PICOS完整候选、章节首稿3–5候选、
  SoA/核心表格整表预填、量表/文献主动推荐、无IB首轮事实包。开发Agent不得替代产品独立AI。
- 动态设计投影Slice B已由Codex主线程正式验收。独立复跑结果为：复杂设计typed合同、
  Slice A投影/结构化合同和Worker 01共`90 passed`；Worker 02跨投影计划消费、装配计划和
  研究一致性共`48 passed`，合计`138 passed`，仅有既存FastAPI `on_event`弃用警告。
  已冻结治疗转组、交叉设计、开放标签延展、样本量再估计和适应性设计五类typed对象及其
  legacy迁移、投影阻塞范围、装配驱动与一致性约束。该证据尚不证明摘要、正文、SoA、
  研究流程图和DOCX的真实输出一致。
- 下一步Slice C必须让上述五类消费者只读取
  `StudyDefinition -> NormalizedDesignProjection`，并以9类复杂设计逐一验证五个实际
  输出面；仅断言plan object不构成验收。竞品分诊确认事务修复与Slice C并行，但共享模型
  冻结后才允许改动：最终人工分类必须在service同一事务内写入并参与幂等哈希，HTTP层不得
  先确认后逐条覆写；允许“全部排除”且必须记录充分理由，并继续支持手工上传或通用语料库。
- AI-first下一阶段实施合同已落盘：
  `context/plans/medical_writing_ai_first_candidate_packages_20260724.md`。决策为复用并扩展
  既有`AuthoringPrefillPackage`，不新增平行事实状态机；先增加模块/设计包级结构化候选与
  原子组合采纳，再覆盖完整PICOS，随后接入章节、SoA/核心表格、流程图、量表和文献。
  独立AI只提出候选，未确认的精确剂量、阈值、终点、样本量、时间窗、AESI和洗脱期不得进入
  正式研究事实。
- 当前prefill/authoring journey确定性基线已独立复跑：`106 passed`，仅既存FastAPI
  `on_event`弃用警告。该绿灯只证明现有窄契约稳定；源码仍明确只允许AI覆盖少量framing/
  PICOS字段，并将剂量、主要终点、AESI、样本量和洗脱规则作为无证据空缺，因此不能作为
  “AI先写、用户只改/选/确认”的产品验收。
- 进一步源码核对确认：虽然AI解析器具备“精确事实必须引用已登记source id”的隔离逻辑，
  但当前`_AI_ELIGIBLE_FIELDS`根本不包含剂量、主要终点、AESI、样本量和洗脱字段，生成器
  又无条件把这些路径计入blocked；因此即使竞品Protocol/IB/方案摘要已提供真实证据，现有
  生产提示和allowlist也无法把证据支持的候选送给用户。这是下一轮P0实现必须直接修复的
  合同缺口，而不是前端文案问题。
- 竞品分诊最终分类原子确认返修已由Codex独立验收，不以subAgent自报结论放行。源码核对
  确认`final_classifications`与“无合适竞品理由”进入正式请求、确认记录、确认哈希和
  幂等身份；confirmation、全部最终decision、run状态和幂等记录在同一
  `BEGIN IMMEDIATE`事务提交，HTTP层已删除后置逐条覆写。全排除需至少10个实质字符理由，
  并可继续手工上传或通用语料库路径。
- 独立回归：竞品分诊/service/API/前端合同`176 passed`；corpus readiness与authoring
  journey`29 passed`，仅既存FastAPI `on_event`弃用警告。接受报告：
  `reviews/codex_subagent_competitor_triage_atomic_confirmation_20260724.md`；marker：
  `runs/execution/mw_competitor_triage_atomic_confirmation_20260724/codex_worker.done`。
  仍保留跨两个SQLite数据库的显式`projection_pending/failed`可重试边界，但不再需要二次
  医学批准，且投影只消费同一份已原子确认的最终分类。
- 动态设计投影Slice C已完成并由Codex主线程验收。五个真实消费者统一为：
  `StudyDefinition -> confirmed current ProtocolAssemblyPlan ->
  normalize_study_design(include_sources=True) -> NormalizedDesignProjection ->
  摘要/章节/SoA/流程图/DOCX`。9类复杂设计实际输出矩阵`11 passed`；冻结Slice A/B组合
  `138 passed`；章节/流程图/表格/DOCX相邻组合在修正一个过时测试期望后`70 passed`；
  export API/greenfield runtime/真实项目流`31 passed`。仅有既存FastAPI `on_event`警告。
- 主线程发现并处理的验收差异：旧章节回归仍期望已确认`framing.design_pattern`自由文本
  进入设计依据正文，这与Slice C“typed设计为唯一权威”冲突。未修改生产实现，而是将该
  过时断言改为反例：即使legacy字段标为confirmed也不得进入正文或source_fact_ids；随后
  相邻70项全部通过。
- Slice C接受报告：
  `reviews/codex_subagent_design_projection_slice_c_20260724.md`；marker：
  `runs/execution/mw_design_projection_unification_20260724/codex_worker03.done`。
  后续除非真实浏览器/DOCX暴露可复现缺陷，不再重开Slice A/B/C。
- 按用户要求，在本轮Codex subAgent全部完成并关闭后恢复执行/会商机制。已重新读取全局
  `~/.codex/AGENTS.md`并初始化高风险复杂任务
  `mw_ai_first_candidate_packages_20260724`；上下文为
  `context/mw_ai_first_candidate_packages_20260724_context.md`，首轮执行经理合同为
  `prompts/execution/mw_ai_first_candidate_packages_20260724/manager_plan.md`，prompt
  preflight已通过，无警告/错误。
- 现有QoderVIP `qodercli`进程PID 8003、TTY `ttys001`、Terminal window 580已复核；
  可见界面明确显示`Qwen3.8-Max-Preview`。因上一任务与本任务无关，已通过AppleScript
  `/new`清空上下文，再粘贴并提交只读执行经理合同。该首轮仅允许写
  `runs/execution/mw_ai_first_candidate_packages_20260724/manager_plan.md`，不改生产
  源码/测试/数据库；不发送进度询问，按报告文件和任务完成状态观察。
- 2026-07-24 19:36 CST重新锚定运行态：本地常驻前端`http://127.0.0.1:5174/`与后端
  `http://127.0.0.1:8911/`均通过`deploy/medical_writing_local/manage.zsh status`，
  当前前端build为`web-6b79ff2d388f9871`、后端build为`api-3256d3c7d5220ef2`，
  runtime schema 16、31项能力合同均满足。产品独立AI明确为
  `deepseek/deepseek-v4-pro`，`codex_runtime_dependency=false`。
- 本轮重启脚本首次返回非零并非业务服务失败：冷启动期间内置 verifier 在15秒窗口内
  超时，随后`status`全量通过，`/api/runtime-readiness`在2.236秒返回HTTP 200，前端
  runtime-build亦返回200。该现象记录为“冷启动校验窗口需后续优化”的部署体验问题，
  不能据此宣称前后端阻断，也不能跳过真实浏览器业务验收。
- 本轮已确认所有Codex subAgent均完成并关闭，后续按用户最新指令恢复执行/会商机制；
  外部成员只通过完成报告、marker和实际产物验收，不发送“进度/继续”类提示。当前
  `mw_ai_first_candidate_packages_20260724`的Qoder执行经理报告尚未生成，保持后台运行，
  Codex主线程继续D017真实浏览器、独立AI v2分诊及产品功能验证。
- Qoder执行经理首轮报告已于19:37自然完成：
  `runs/execution/mw_ai_first_candidate_packages_20260724/manager_plan.md`。Codex未放行其
  直接实施，主要差异为：计划发明平行数据库/生产故障注入端点和不存在文件路径；W2/W5
  写集重叠；把精确剂量等无证据事实也当默认候选；未登记source id仍拟保留；重新引入
  “需医学批准”；以90%/95%而非全绿作为回归门；并包含`ITTS`、`MMPR`等不准确术语。
- 已形成单次合并返修合同
  `prompts/execution/mw_ai_first_candidate_packages_20260724/manager_plan_remediation_01.md`，
  guard preflight无警告/错误；经现有QoderVIP可见Terminal同会话发送。返修要求复用
  `AuthoringPrefillPackage`、现有runtime store和durable job；精确事实必须有可定位已登记
  原文证据，无证据时仅生成待决定卡；用户选用即确认；删除生产故障端点/TTL/安全工作；
  校正真实路径、统计语义、全绿回归门和用户既定多适应症双路径矩阵。后续不发进度询问，
  仅在返修报告完成后验收。
- D017真实桌面浏览器已从项目总看板进入医学写作语料准备页，既有ClinicalTrials.gov
  快照`wref_search_42d02b8b17a6f5bfafe6`的67项候选、48份公开Protocol/SAP完整恢复。
  页面正确判定v1因当前框架变化而不可沿用，并只开放“按当前信息重新分诊”。已通过真实
  产品按钮启动v2，后端202返回durable job
  `mwjob_ba8bda7a2609be2a2f5a4a2e`；浏览器显示“AI分诊中”及取消入口，轮询正常。
  本次执行严格由工作台独立`deepseek/deepseek-v4-pro`完成，Codex/Qoder均未替代。
- 已在v2运行中使用真实桌面浏览器执行Cmd+R刷新。刷新后项目
  `MW-II-445224B8`、同一检索快照和“AI分诊中/仍在后台进行”状态均自动恢复，未再次发送
  POST、未新建第二个job，也未丢失取消入口；durable job刷新恢复路径通过当前实测。
- 源码与实时快照核对又发现v2科学性上限：现有
  `WritingReferenceTrialCandidate`及`CTGOV_DISCOVERY_FIELDS`只保存标题、疾病、分期、
  研究类型、申办方、状态和公开文件；`_build_chunk_input()`没有给AI提供官方已公开的
  干预名称/类型、随机化、盲法、干预模型、入组例数和brief summary。因此v2可用于同快照
  验证提示是否减少猜测，但不足以作为最终医学分诊质量门。
- 已派不与AI-first主线重叠的Codex subAgent
  `019f93f2-5f14-7b02-a50e-de26c1e174b9`，仅在候选合同、
  `writing_reference.py`、`medical_writing_competitor_triage.py`及聚焦测试内增加上述
  ClinicalTrials.gov显式字段、hash和AI输入；明确不得修改旧快照/数据库/前端或确认D017
  run。完成后需新建不可变搜索快照并进行v3，不能原地篡改v2比较基线。
- D017独立AI v2已完整结束：durable job=`mwjob_ba8bda7a2609be2a2f5a4a2e`，
  run=`ct_run_e2d6569264df47f7ef0b`，5/5分块、67/67候选均成功，推荐保留52、排除15；
  provider/model严格为`deepseek/deepseek-v4-pro`，`confirmation_id`为空。
- v2技术路径通过但医学质量门失败，正式报告为
  `reviews/d017_competitor_triage_v2_medical_qc_20260724.md`。主要阻断不是中文表达，
  而是旧快照没有把ClinicalTrials.gov已公开的干预、Brief Summary、随机/盲法/模型和
  入组数提供给AI，输出仍出现“给药途径可能为口服”“很可能纳入初治人群”以及未输入的
  模态/靶点/设计事实。v2不得确认、不得进入下载/翻译/语料篮子。
- 相比v1，造血干细胞移植已稳定排除，OLE/长期安全性研究已降为间接参照；但保留篮子从
  51/67扩大到52/67，4项direct结论也部分依赖未进入run输入的事实，故不能据“技术跑通”
  宣称可用。下一门槛是验收subAgent字段扩展后重启、新建不可变快照并执行v3；旧v2快照和
  run保留为回归基线，严禁原地改写。
- v2完成后再次通过真实桌面浏览器Cmd+R验收：页面从“AI分诊中”恢复为“AI分诊已完成”，
  展示全部67项逐项结果、AI中文理由、匹配维度、证据缺口和每项最终分类下拉框；底部提供
  一次性“确认并锁定全部67项”。未点击确认。该实测证明完成态恢复与人工逐项覆盖控件
  存在，但同时暴露两个后续前端质量点：候选列表仍显示原始“待医学分类”而下方结果区显示
  AI建议，层级语义需更清楚；匹配维度中`modality`、`target_mechanism`仍直接显示英文
  枚举名，需改为中国医学撰写用户可读标签。以上不改变v2医学QC拒绝结论。
- ClinicalTrials.gov候选字段subAgent已完成并关闭，报告为
  `reviews/codex_subagent_ctgov_candidate_enrichment_20260724.md`，marker为
  `runs/execution/mw_ctgov_candidate_enrichment_20260724/codex_worker.done`。Codex主线程
  独立复跑候选补全、writing reference、repository、竞品分诊和durable job组合：
  `169 passed, 22 subtests passed`，并对5个修改Python文件执行`py_compile`通过。
- Codex接受报告为
  `reviews/codex_acceptance_ctgov_candidate_enrichment_20260724.md`。新增Brief Summary、
  干预名称/类型、随机、干预模型、盲法和入组数均进入未来新快照、hash和产品AI输入；
  旧快照缺字段仍可加载。该接受仅允许重启后新建快照和v3，不改变D017 v2拒绝状态。
- 用户于2026-07-24 20:11 CST更新执行路由：北京时间2026-07-25 01:00前不得使用
  `Qoder/qwen3.8-max-preview`；该时段内原本需要`Hermes/aishuo/cms-model`的任务继续走
  Hermes，01:00后新任务才切换现有QoderVIP会话。最新用户指令覆盖项目层旧的
  2026-07-24 01:00切换边界。
- Qoder返修合同此前因AppleScript只粘贴未提交而未执行；发现后补发一次回车，随后在用户
  新时段指令到达时立即Ctrl+C停止，未发现其对生产源码写入。只读报告
  `runs/execution/mw_ai_first_candidate_packages_20260724/manager_plan_remediation_01.md`
  已生成但未被Codex放行：仍包含不存在的批量请求合同却禁止改models、前端回归允许95%
  而非全绿、固定示例项目事实、测试文件无明确写集等矛盾。该报告仅作为证据；01:00前后续
  计划修订按当前Hermes/Grok执行路由重新完成。
- 用户于2026-07-24 20:11 CST再次更新路由边界：北京时间2026-07-25 01:00前不使用
  `Qoder/qwen3.8-max-preview`，原本解析到`Hermes/aishuo/cms-model`的角色继续使用Hermes；
  2026-07-25 01:00起，仅新任务、续作或返修才切换到既有QoderVIP会话。已同步修订项目
  `AGENTS.md`中的三个日期，未启动、打断或替换任何执行轮次。
- 干净D017从零项目`proj_user_3ecb0bc287c0`的真实桌面页面已从加载态恢复为17项预填
  建议；未使用“一键采用”，只采用具有项目适应症正文依据的英文ClinicalTrials.gov疾病
  检索词`Paroxysmal Nocturnal Hemoglobinuria`。用户选择后即成为项目事实，没有二次
  “待医学批准”；工作台自动生成检索计划revision 3和不可变快照
  `wref_search_35f39994abfb89587948`，返回67项研究及48份公开Protocol/SAP。
- 新快照字段补全已在真实API验证：67/67有Brief Summary、干预名称/类型和入组数，
  66/67有allocation、intervention model及masking。样例NCT02534909准确返回LFG316/
  LNP023、single-group、open-label和10例，证明新字段不是仅合同存在而是已写入生产快照。
- 检索完成后产品DeepSeek自动更新预填，但把中国方案标题推荐为
  `Phase 2 Study of CMS-D017 in PNH`，把目标人群推荐为
  `Adult PNH patients meeting criteria`，两者均无直接项目证据；真实桌面截图和DOM一致。
  源码根因已定位为bulk提示未要求除检索词外的监管中文，且`_merge_ai_candidates`无条件
  将AI候选置于确定性候选之前。以上候选未采用。
- D017 v3竞品分诊已用工作台正式202接口启动：job
  `mwjob_6aaaa7b8cb639b6a5510c164`，run
  `ct_run_8a817ed1af34e1902fbb`，snapshot
  `wref_search_35f39994abfb89587948`。运行时provider/model为
  `deepseek/deepseek-v4-pro`，Codex及执行模型不替代；结果完成后必须做逐项医学QC，未通过
  不确认。
- 截止前允许的两路执行已并行派发且preflight零警告/错误：
  1. Grok Build/grok-4.5只读执行经理报告
     `manager_plan_grok_02.md`，负责形成不重叠、可实施、零失败的AI-first第一切片计划；
  2. Hermes/aishuo/cms-model窄执行成员只允许修改
     `medical_writing_authoring_prefill_ai.py`及新质量反例测试，修正监管中文、无证据新增事实
     和AI无条件抢占推荐位。两轮均不得用自身模型替代产品DeepSeek，也不得进行安全审计；
     按进程退出和完成标记观察，不发送状态催促。
- 当前真实UI还有一项P0路径缺口：建项第一步完成检索后只显示研究/文件数量，
  `WritingReferencePanel`及“启动AI分诊”只在第三步语料准备渲染，用户无法就地处理刚发现的
  竞品。v3为科学性验证通过同一正式202 API启动，不作为UI通过证据。后续应在第一步增加
  独立竞品处理入口/抽屉；保持候选研究、解析、审核为单独工作区，不常驻写作编辑器，也不
  以先补完大量框架/PICOS作为前置条件。
- 真实点击“方案标题/查看5个候选”进一步证明问题不止语言：产品AI第二候选
  `Phase 2 RCT of CMS-D017 in PNH`的理由明确写“hypothesized from phase II”，而当前
  项目未确认随机/对照；确定性第四候选也把“随机对照”写入标题。标题候选不应替代独立的
  随机、盲法、对照等设计维度选择；在这些设计未确认前，标题候选只能组合药物、适应症、
  分期和明确研究目的。该问题分别归入AI候选质量门和确定性prefill设计事实泄漏修复。
- 逐页切换“总体设计”和“PICOS”完成当前真实E4反例：
  - 仅凭II期，页面把随机、双盲、安慰剂、平行两组、多中心、DMC全部标为“AI推荐”，
    总体模式甚至为`RDBPC parallel-group multicenter`；“确定性预填不构成结论”的小字
    不能抵消主推荐按钮的误导。
  - PICOS仅有3个自由文本框，且独立AI推荐分别为英文人群、`per protocol dosing`和
    `Placebo or standard of care`占位句；没有完整入排、洗脱、背景/允许/限制/禁止治疗、
    终点包、AESI、估计目标、分析集、样本量假设等结构化候选。
  - 因此当前不是“AI撰写器”：设计应先由竞品/IB/摘要/用户目标形成有来源的独立维度候选；
    无证据时推荐项应是可解释待决定卡，而不是按分期硬编码一个常见设计。完整PICOS包仍是
    第一实施切片的发布阻断项。
- 源码确认顶部“采用低风险建议（2）”把`framing.document_title`与方案号/版本并列纳入
  批量范围；当前推荐标题含无证据英文/随机设计，若点击会在无逐项审核时写为项目事实。
  因此当前未点击。修复前标题不得视为批量低风险字段；后续应由服务端候选责任/证据角色
  决定是否可批量，而不是前端静态字段名集合。
- D017 v3已完成并正式医学QC拒绝，报告为
  `reviews/d017_competitor_triage_v3_medical_qc_20260724.md`，原始run、快照和确定性扫描均
  在`runs/evidence/d017_competitor_triage_v3_20260724/`。技术证据为5/5分块、67/67完整、
  产品AI身份`deepseek/deepseek-v4-pro`；分布为52项间接参照、15项排除、0项直接竞品，
  未确认。
- v3改进是未知CMS-D017模态/靶点/途径时不再硬判直接竞品，v2四个重点反例大幅收敛；
  阻断仍包括：iptacopan被补写“B因子抑制剂”、MY008211A tablets被补写“口服”、
  ADX-038被补写“剂量递增”，以及4个明确`protocol_sap`文件被误判为
  `has_public_protocol=false/has_public_sap=true`。后者证明文档布尔值必须服务端确定性
  派生；前者证明route/target/modality等维度必须逐字段证据绑定并在缺失时服务端强制
  `unknown`，不能只依赖提示词。
- 当前最小三事实不足以判断CMS-D017直接竞品，系统应在无IB对话中尽量补齐产品类型、
  靶点/机制、途径/剂型；仍未知时应明确只形成疾病方案参考篮子，并对52项间接参照按
  Protocol/SAP、分期、设计与可转移模块排序，不得等价进入深度下载/翻译。
- Grok执行经理v2报告
  `runs/execution/mw_ai_first_candidate_packages_20260724/manager_plan_grok_02.md`已完成，
  标记`GROK_MANAGER_AI_FIRST_PLAN_V2_COMPLETE`。Codex接受其W1合同→W2完整PICOS与质量门
  →W3组合原子采纳→W4推荐优先前端的严格串行主顺序，并增加两个必须差异：candidate_scope
  一次性保留table/chapter枚举供后续使用；批量采用资格进入候选合同，由服务端明确，
  不再依赖前端静态字段名。
- W1合同成员已按当前允许的Hermes/aishuo/cms-model路由派发，唯一写集为
  `models.py`、包`__init__.py`和新合同测试；与正在执行的prefill AI监管中文窄修复不重叠。
  W1只建立向后兼容的组合候选、推荐角色、证据缺口、采纳模式及组合请求模型，不允许声明
  service/API/前端或原子事务已完成。
- W1候选包合同已完成并由Codex独立验收：新增`field/module/design_package/table/chapter`
  scope、组合目标路径、推荐/备选/待决定角色、临床取舍、证据缺口、AI run及服务端采纳模式，
  `pending_decision`在合同层禁止批量采用；另建立组合采纳请求合同但未实现事务/API。
  独立运行新30项合同测试及既有prefill/journey回归共84项，零失败，py_compile通过。
  因此W1只按“合同完成”接受，W2完整PICOS生成、W3原子组合采纳、W4前端均仍未完成。
- 在不触碰正在修改的prefill文件前提下，新增竞品分诊v4窄执行合同：
  `worker_competitor_triage_v4_source_truth_01.md`。写集限于分诊service及新反例测试，要求
  Protocol/SAP布尔值完全由快照确定性派生、项目或候选缺失的route/target/modality强制
  unknown、无来源reason由显式输入重建、项目关键直接竞争事实未知时不得保留
  direct_competitor。本轮不含第一步UI、无IB对话、数据库扩展或真实run确认。
- 监管中文/证据窄修复首轮虽由执行成员报告126项测试零失败，但Codex源码复核拒绝接受：
  实现为迁就旧测试，把整句英文和无依据设计事实仅降级后仍作为可手动选择候选保留，并在
  用户可见局限中保留`AI proposed`；`Phase II Study`等短英文也可通过；任意
  `evidence_refs`还能绕过随机/盲法/途径/机制门。已形成同会话返修合同，要求错误候选
  完全失败关闭、旧开发标签删除、不相关来源不能放行，并仅修订两个固化错误行为的旧断言。
- 竞品分诊v4首轮93项测试零失败但Codex源码复核暂不接受：直接竞品降级函数未验证候选
  适应症和药理学干预类型，可能把不同适应症或DEVICE/PROCEDURE/移植等模型误判从direct
  降为indirect并污染保留篮子；理由重建还会无条件写“同适应症药物研究参考”。已发起同会话
  返修，要求只有“适应症一致+明确药物/生物制品干预”才能降为间接参照，其余失败关闭为
  excluded并保持理由一致。
- W2按互斥写集拆为W2a/W2b：W2a先只改确定性prefill生成器，清除按分期猜随机、盲法、
  安慰剂、DMC、成人和I期SAD+MAD默认值的根因，并在同一`AuthoringPrefillPackage`中建立
  population/intervention/outcomes/statistics四个完整PICOS组合待决定包；W2b待监管中文
  返修接受后再接产品DeepSeek实质候选。W2a不开放精确事实无保护采纳，不实现组合事务/API，
  与当前prefill_ai及triage返修写集不重叠。
- 监管中文第二轮已硬删除不合格候选、删除`AI proposed`并使无关来源不能绕过，独立132项
  测试零失败；Codex仍未最终接受，因为语言门把value/preview/rationale拼接后检测，英文
  标题可被中文rationale中的汉字遮挡。已发起同会话第三轮精确返修，要求三个用户可见字段
  分别过语言门，并覆盖英文value+中文理由等真实组合反例。
- 用户于2026-07-24再次更新路由时间边界：北京时间2026-07-25 01:00前不使用
  `Qoder/qwen3.8-max-preview`；01:00后，仅将原本解析到
  `Hermes/aishuo/cms-model`的新任务、续作或返修切换到既有QoderVIP会话。当前两路已在
  新指令前按允许路由启动的Hermes执行不做无意义中断；本轮未调用Qoder。
- 监管中文/证据门第三轮已由Codex完成源码级验收：`structured_value`、`preview`、
  `rationale`三个用户可见字段分别检测，英文值不能再被中文理由掩盖；D017真实反例
  `Phase 2 Study of CMS-D017 in PNH`加中文理由被硬拒绝，CMS-D017、PNH、PK/PD、
  SAD/MAD等必要缩写仍可通过。执行报告的137项组合测试曾全绿；Codex复跑时W2a正在并发
  修改确定性prefill，出现两条预期被替换的旧“II期默认随机/采用随机即确认总体设计”断言
  失败，语言门自身测试并未失败。待W2a完整结束后以全量新基线复跑，不把并发中间态记为
  监管中文回归。
- 竞品分诊v4第二轮通过105项测试，但Codex源码验收再次拒绝：实现把缺失显式
  `intervention_type`的`INTERVENTIONAL`研究默认视为药理学干预，与既定“干预类型缺失
  失败关闭”边界相悖，会污染间接参照篮子。已在同一Hermes会话发起第三轮单点返修：仅
  显式`DRUG`、`BIOLOGICAL`或`COMBINATION_PRODUCT`可作为同适应症药物参照；缺失、
  器械、操作、放疗及其他非药理学类型均不得依靠研究类型补推。
- W2a已完成主体实现并由Codex独立复跑prefill、合同、AI质量门共178项测试和48组子测试
  全绿，`py_compile`通过。已清除按分期硬猜随机、盲法、安慰剂、DMC、成人和I期默认
  SAD+MAD的根因；新增population/intervention/outcomes/statistics四个完整PICOS组合
  待决定包。Codex暂未最终接受，因为I期8类Part虽出现在说明文字，结构化备选被候选上限
  `[:5]`截断。已同会话返修，要求首个待决定候选提供8项机器可读
  `available_part_types`目录，同时保持`parts=[]`，供后续前端完整多选。
- W2a第二轮已补齐I期结构化Part目录：首个待决定候选明确提供SAD、MAD、首次患者、
  食物影响、物质平衡、肝损伤、肾损伤、DDI共8项`available_part_types`，同时保持
  `parts=[]`和未决定sequence，目录不等于默认选择。Codex独立复跑179项测试、48组子测试
  零失败并通过三个相关Python文件编译，W2a按“确定性PICOS待决定包完成”正式接受。
- W2b只读技术审阅已落盘
  `reviews/codex_subagent_w2b_evidence_catalog_design_20260724.md`。结论是不能继续用裸
  `registered_source_ids`冒充语义证据；必须由服务端建立不可变source catalog，要求产品
  DeepSeek返回claim到catalog entry的逐项绑定，再由服务端以source、locator和quote hash
  重绑原文。已派W2b-1窄执行，仅新增向后兼容合同、纯证据目录builder和测试；第一版只读
  项目最小事实、已确认摘要span及当前CT.gov快照显式字段，不改AI调用、journey/API或前端。
- 竞品分诊v4第三轮修正了“缺失干预类型按INTERVENTIONAL补推药物研究”和字面
  `unknown`误判为已知，但执行成员又越界加入“技术类型/途径/机制任一项已知就信任模型
  direct”的回归。Codex拒绝接受并发起第四轮：只有三项均明确时才允许保留direct；任何一项
  缺失都按同适应症显式药理学研究降为indirect，否则excluded，并补三类部分已知反例。
- 2026-07-24 21:18 CST按最新用户要求重新完整读取全局与项目`AGENTS.md`，确认新的路由
  边界为北京时间2026-07-25 01:00：此前不使用`Qoder/qwen3.8-max-preview`，原本解析到
  `Hermes/aishuo/cms-model`的任务继续走Hermes；切换点后仅新任务、续作或返修切换既有
  QoderVIP会话。本轮两个在途Hermes执行按原会话自然完成，不发送状态催促。
- 竞品分诊v4第四轮源码已暂时呈现正确的三事实全满足条件：
  `tech_known and route_known and target_known`才保留direct；三个“仅一项已知”新反例
  已落盘。Codex独立复跑新旧分诊测试得到108通过、1失败；唯一失败是旧测试仍期待在项目
  三项关键事实和候选显式干预类型均缺失时保留direct，与新失败关闭边界冲突。不得放宽
  生产逻辑迁就旧断言；待执行轮结束后仅修正该过时测试并再次全绿验收。
- W2b-1证据目录主体合同、纯构建器和测试已开始落盘但尚未接受。Codex第一次独立复跑得到
  59通过、6失败，失败均来自新增测试使用了过时的`MedicalWritingSynopsisSource`
  构造参数。源码复核还发现两个必须返修的语义点：`quote_sha256`必须与服务端实际原文
  重新计算值完全一致并验证为十六进制；项目最小事实条目的
  `supported_target_paths`必须按单字段收窄，不能让“适应症”条目证明“试验药物”等其他
  项目事实。当前实现和报告均未验收。
- W2b-2生产链路确认存在P0断点：`main.py`的正式预填生成POST只构造产品
  `DeepSeekPrefillAdapter`，没有按`journey.search_plan.latest_snapshot_id`从
  `WritingReferenceRepository`读取不可变快照并传给`generate_prefill`。因此前一步已检索
  到的竞品显式字段不会进入当前独立DeepSeek预填请求。W2b-2必须同时实现最新快照注入、
  服务端证据目录、逐主张绑定与回绑校验，不能只改提示词或模型返回schema。
- 已启动只读Codex subAgent
  `019f9449-46c9-73a1-9e3b-c6e58967e73e`，仅审阅W3组合候选原子采纳的现有事务、revision、
  幂等和派生重建边界，输出
  `reviews/codex_subagent_w3_composite_adopt_design_20260724.md`；不得修改源码，也不与
  W2b在途写集重叠。W3仍须等待W2b证据语义冻结后实施。
- 竞品分诊v4第04轮执行成员为迁就过时旧测试一度新增“从项目药名/剂型和候选
  `INTERVENTIONAL`推断候选药理学类型”的旁路，Codex源码复核拒绝并发起同会话第05轮。
  第05轮已彻底删除该旁路，旧测试改为正确的失败关闭预期，并新增“项目名称含注射液也不能
  证明候选干预类型”的反例。Codex独立复跑新旧分诊测试为110通过、零失败，三个文件
  `py_compile`通过；v4来源真值代码正式接受。因W2b-1仍在修改共享contracts，暂不在中间态
  重启后端；W2b-1验收后一次性重启，再用D017同一不可变快照启动新的产品
  `deepseek/deepseek-v4-pro`分诊run并逐项医学QC，旧v3仍保持未确认。
- W3只读Codex subAgent已完成并关闭，报告为
  `reviews/codex_subagent_w3_composite_adopt_design_20260724.md`。确认不得通过前端或
  service循环调用单字段采纳：必须先由无I/O规划器解析全部target path、override、证据门和
  派生冲突，再在journey SQLite单个`BEGIN IMMEDIATE`事务中只提交一次revision、package和
  审计事件。`pending_decision`未override路径保持不变；用户`path_overrides`即医学经理当次
  确认，成功后直接生效且不再出现“待医学批准”。搜索计划可同事务重建；独立存储中的正文、
  研究流程表和ProtocolAssemblyPlan只能原子失效后再刷新，不能宣称跨库原子重建。报告给出
  49项反例矩阵；W3继续等待W2b服务器证据分类、catalog漂移和binding复验规则冻结。
- W2b-1证据目录合同第二轮由执行成员完成后，Codex逐段复核合同和纯builder，另发现并修复
  一处未覆盖边界：`synopsis_import.status=confirmed`但缺失权威`source`时，旧实现仍可接纳
  任意span的`source_id`。现已改为无权威source或空source_id即整体失败关闭，并新增真实反例。
  最终项目最小事实按字段隔离支持范围，摘要span须与确认源严格一致，CT.gov候选先按NCT号
  稳定排序再截断；quote/hash、catalog hash和claim binding均使用严格64位十六进制合同，
  supported/partially_supported必须带目录ID、目录hash和至少一条binding，重复binding拒绝。
  Codex独立复跑证据目录、组合候选合同、确定性prefill及AI质量门共171项测试零失败，
  相关文件`py_compile`通过。W2b-1正式接受，W2b-2可开始接入正式产品DeepSeek和服务端回绑。
- 接受W2b-1后重载本地稳定运行时。普通`nohup`子进程会随当前命令会话被回收；`launchctl
  submit`又因Documents目录TCC边界无法打开脚本，故改用系统自带`screen`持久托管：
  `cms-mw-backend`和`cms-mw-frontend`两个detached session。当前后端PID 76816监听8911，
  前端PID 76836监听5174；`/api/runtime-readiness`返回ready，独立AI身份为
  `deepseek/deepseek-v4-pro`且`codex_runtime_dependency=false`，前端HTTP 200。
- 已以D017当前journey revision 5和同一不可变快照
  `wref_search_35f39994abfb89587948`启动竞品分诊v4真实产品AI运行：
  run=`ct_run_681a3edb8f7d10cfe256`，job=`mwjob_94caedeabb1a66a03e44d15a`，
  未复用旧run。证据目录为`runs/evidence/d017_competitor_triage_v4_20260724/`；已建立新版
  确定性QC脚本，补足v3脚本遗漏的official title、文档字段、结果完整性、直接竞品失败关闭、
  间接篮子“同适应症+显式药理学干预”及项目未知modality/route/target保护检查。当前job为
  running，产品AI身份正确，不做频繁轮询。
- 2026-07-24 21:40 CST（仍早于7月25日01:00切换点）完成W2b-2 prompt preflight并按允许的
  `Hermes/aishuo/cms-model`执行路由启动。任务只允许修改prefill AI、证据回绑小模块、
  正式API快照注入和聚焦测试；目标是一次bulk产品DeepSeek调用生成字段及四个PICOS组合候选，
  模型只回catalog entry ID，服务器重绑原文/source/locator/hash并计算证据状态。本轮未调用
  Qoder；进程在途时不发送状态催促。
- W3只读设计已转写为待执行合同
  `prompts/execution/mw_ai_first_candidate_packages_20260724/worker_w3_atomic_composite_adopt_01.md`，
  明确单`BEGIN IMMEDIATE`事务、双revision CAS、pending仅应用override、用户选择后直接确认、
  AI路径重新过W2b服务端证据门、逐路径回执和跨存储仅失效不伪称原子重建。待W2b-2验收后
  才派发，避免`main.py`写集冲突。
- 已启动只读Codex subAgent `019f945c-0a8d-7c82-b98a-aa8610f25893`，只梳理W4前端真实
  路由/组件/state/API、空表单与重复确认问题、AI候选/证据/组合采纳的最小改造面及桌面端
  验收矩阵；不得改文件、不得安全审计、不得调用产品AI。该侧任务与在途后端写集不重叠。
- W4只读subAgent已完成并关闭，结果已整理为
  `reviews/codex_subagent_w4_frontend_map_20260724.md`。关键结论：复用现有
  `AuthoringPrefillPackage -> StudyDefinition`主链；组合候选UI集中到新纯展示组件，
  竞品处理通过drawer复用WritingReferencePanel；删除前端循环单字段“批量采用”；pending
  必须局部override后一次调用W3；候选默认呈现原始证据、临床取舍和缺口，运行ID/hash只放
  溯源详情；建项页候选主区约70%，编辑器正文最小760px、AI栏380-420px，不重挂TipTap或
  改动现有表格全屏边界。报告列明现有路由/组件/API及9项P0验收和7个回归入口。W4待W2b/W3
  最终合同冻结后实施。
- D017竞品分诊v4真实产品AI run已完成：5/5 chunk、67/67唯一结果，provider/model和prompt
  均正确；分布52项间接参照、15项排除、0项直接竞品，项目未知modality/route/target保护
  零违规，Protocol/SAP布尔值零不一致，现有52项间接参照均能由快照验证为PNH相关且至少含
  一项显式药理学干预。但医学QC仍拒绝确认，报告为
  `reviews/d017_competitor_triage_v4_medical_qc_20260724.md`：服务端只复验模型原始direct，
  未复验原始indirect的篮子资格；reason用中英文原始字符串比较，几乎所有PNH研究都被写成
  “适应症不同”却又称“同适应症参照”；document role保留模型自由文本，使NCT03053102出现
  快照未提供的“口服补体抑制剂”。已按同一Hermes session发起第06轮定点返修，要求所有
  indirect统一复验、通用缩写/token适应症匹配、reason复用同一判定、document role完全
  服务端确定性生成。旧run保持review_ready且不确认，修复后必须新建run重测。
- 竞品分诊第06轮报告虽称119项测试通过，但Codex语义验收仍拒绝：缩写匹配分支把任意2-8位
  小写英文词都当作缩写，`severe/chronic/disease`等通用词可能制造适应症假阳性；且项目
  modality/route/target均已知时仍跳过原始indirect的统一复验，与“所有间接参照必须同时
  满足同适应症和显式药理学干预”的服务端不变量冲突。已在同一session发起第07轮定点返修，
  要求缩写必须由项目术语括号关系或候选显式大写缩写证明，且每一条indirect无条件执行统一
  资格复验。完成后先做源码语义审阅与聚焦回归，再合并重启并创建全新的D017 run；旧v4 run
  继续保持未确认。
- W2b2第一轮实现新增证据绑定模块并通过261项测试及48个subtest，但Codex语义验收拒绝：
  正式DeepSeek路径之后仍执行legacy fallback并可产生零绑定可选候选；请求仍携带
  `registered_source_ids/snapshot_hints`绕过有界catalog；catalog SHA缺失可放行；候选中
  部分binding无效时未整体拒绝；ClinicalTrials.gov未映射字段、非首个intervention索引、
  package目标路径、value pointer原子覆盖和候选scope均未满足W2b合同，且总提示词预算未覆盖
  snapshot hints。已在原session发起第02轮定点返修，要求正式路径彻底移除legacy/旁路输入，
  强制catalog id+SHA、任何无效binding整候选拒绝、RFC6901值指针原子覆盖、精确canonical
  target set、任意intervention索引映射、`design_package` scope及全payload有界。W2b2未
  验收前不启动依赖其合同的W3写入任务。
- 2026-07-24晚间重新读取全局`~/.codex/AGENTS.md`、Goal、任务记录及真实进程。依据用户最新
  路由决定，北京时间2026-07-25 01:00前不使用Qoder/qwen3.8-max-preview；当前两个已运行
  返修均保持原Hermes session自然完成，不做高频状态询问。01:00后仅对原本解析到
  Hermes/aishuo/cms-model的新任务、续跑或返修切换到既有QoderVIP会话；已完成pass不因跨越
  时间边界而中断。前后端仍由`screen`会话`cms-mw-backend`与`cms-mw-frontend`维持，
  8911/5174进程正常。
- 竞品分诊第07轮修正了普通英文词缩写假阳性和全部indirect复验旁路，但Codex新增真实
  医学反例发现剩余“60% token重叠”仍会把
  `Paroxysmal Nocturnal Dyspnea`误判为PNH。ClinicalTrials.gov官方数据结构确认
  `conditions`为结构化主要疾病/研究关注条件数组（
  `https://clinicaltrials.gov/data-api/about-api/study-data-structure`），因此同一session
  第08轮删除模糊相似度，
  改为分别比较项目中文适应症、英文ClinicalTrials.gov检索词的完整规范化token集合，或使用
  项目中可证明的括号缩写。Codex独立执行134项新旧triage测试与py_compile全绿，并直接复现
  PNH/近似呼吸困难=False、PNH词序变体=True、独立PNH=True、Severe Asthma=False。当前
  竞品分诊源码接受；待W2b2写入结束后统一重启服务并创建全新D017真实产品AI run，旧run
  `ct_run_681a3edb8f7d10cfe256`继续不确认。
- W2b2第02轮已删除正式legacy merge、裸source ID/snapshot hint，并补齐catalog身份、
  整候选失败关闭、任意intervention索引和`design_package`范围，但Codex源码验收仍拒绝：
  value pointer并非真正RFC6901递归解析，list/dict根会被误当作原子证据；覆盖检查没有遍历
  每个非空原子叶；组合包目标路径缺失时仍有硬编码fallback且只信任组内首候选；生产提示词
  仍残留已废弃registry hint语义。已在同一Hermes session
  `20260724_214054_feeb90`发起第03轮，要求严格RFC6901、逐原子叶完整覆盖、四个确定性包
  缺失/漂移时失败关闭且不调用产品AI，并清除正式提示词旧旁路。该pass当前正常在途，不发送
  无意义状态催促。
- 研究流程图/图像型附件只读审计已完成并落盘
  `reviews/codex_subagent_flowchart_image_docx_map_20260724.md`，现场聚焦80项测试无失败。
  流程图的语义编辑、已确认设计事实自动预填、确定性SVG+PNG fallback、Word嵌入、图编号、
  图目录和书签均已实现，暂不重做。两个真实发布阻断为：一是`appendix_image`虽进入后端
  工作副本和DOCX，前端只显示文件名/页数/DPI，医学撰写者不能逐页审阅；二是当前r7分页
  仅用合成9页在LibreOffice/OpenXML通过、Word原生只验收合成2页，旧真实9页IBDQ产物实页
  存在“第22页孤立标题、第23页图片”分离，不能继续当作通过证据。
- 已初始化独立受控任务`mw_real_ibdq_word_gate_20260724`，首轮只允许在
  `records/active_slices/medical_writing_real_scale_word_e5_20260724/`写验收证据，禁止
  修改生产源码。执行成员须用当前导出器和真实`MY009_IBDQ_scale.pdf`重新生成DOCX，在
  Microsoft Word for Mac完成更新域、保存、关闭、重开和Word原生PDF导出，再以至少200 DPI
  逐页证明9个源页连续、每页标题与图同页、无空白/溢出/缺页/重复，同时复核流程图SVG主图
  与PNG fallback。若失败只保存复现、根因和最小修复写集，待Codex验收后再授权改生产代码。
- W2b2第03轮执行报告称298项测试与48项subtest通过，Codex复跑计数一致且py_compile通过，
  但源码/函数探针拒绝验收：`/picos.x//0`、`/picos.x/`和`/`仍被RFC6901 parser接受，
  与明确的空segment失败关闭合同不符；`_extract_package_target_paths()`也只检查首候选
  scope，后续候选scope非法但target_paths相同仍可通过。已在同一session发起第04轮，只允许
  修复这两个边界并增加直接反例，不重开任务、不扩大写集。
- W2b2第04轮已关闭最后两个边界，Codex源码复核并直接探针确认`/`、尾随`/`及`//`
  空segment全部拒绝，合法深层pointer与`~0/~1`仍通过；服务器逐一检查组合包组内每个候选
  scope、非空target_paths及集合一致性。Codex独立复跑8个相关文件得到304项测试和48项
  subtest全绿，AI adapter、证据绑定与main.py编译通过。至此W2b正式接受：独立产品
  DeepSeek一次bulk只能使用服务端有界evidence catalog，所有模型binding由服务端回绑
  source/locator/quote hash，组合候选逐原子叶核验，任一binding无效整候选拒绝，四个
  确定性PICOS包缺失/漂移时不调用产品AI并返回可见partial failure。W3组合单事务采纳可按
  冻结后的证据合同开始执行。
- 后端重载后，以新idempotency key请求D017竞品分诊仍返回旧
  `ct_run_681a3edb8f7d10cfe256`/`mwjob_94caedeabb1a66a03e44d15a`且
  `reused=true`。根因是第08轮虽实质升级全部indirect复验、同适应症和确定性文档角色，
  `TRIAGE_PROMPT_VERSION`仍为v4并参与canonical run identity，导致旧结果绕过新后处理。
  旧run未被覆盖或确认。已在原triage session发起第09轮窄修复，只提升当前来源真值合同的
  run/prompt版本为v5并补版本身份回归，不改变已接受医学逻辑；修复后再重启并创建真正新run。
- 竞品分诊第09轮已将当前来源真值运行身份提升为
  `competitor_triage_deepseek_v5_source_truth`；该常量进入run canonical hash、run_id、
  durable business key、chunk envelope和provenance，provider/model仍严格为
  `deepseek/deepseek-v4-pro`。Codex独立复跑新旧triage共139项测试全绿并编译通过。
  旧v4 run和job保持原状。为避免W3正在改写main/journey时重启导入中间态，待W3执行结束后
  一次性重启后端，再以同一snapshot创建v5新run并以真实run_id/reused=false作为最终版本
  身份验收，不能只依据单元测试接受生产运行。
- D017 v5独立医学QC门由只读subAgent完成初稿后，Codex逐段复核实现、命令行合同和医学
  判定边界。新增
  `scripts/qc/d017_competitor_triage_v5_acceptance.py`及33项专门测试，与67项既有产品
  来源真值回归合计`100 passed`，py_compile通过。该门强制v5 provider/model/prompt、
  snapshot hash、5个成功chunk、67个唯一NCT、严格同适应症、显式药理学干预、
  project/candidate三维direct门、未知维度保护、确定性Protocol/SAP角色、来源locator和
  高风险事实锚定；输出JSON，接受/拒绝/输入致命错误退出码分别为0/1/2。Codex只读套跑
  旧v4证据得到`accepted=false`、退出码1、133项错误，精确包含67项文档角色不一致、
  48项间接参照理由不一致、12项适应症理由误判、3项不合格indirect和3项无来源高风险主张。
  该工具现已接受，但篮子仍未确认；下一步必须针对后端实际装载的v5新run执行同一门。
- Word真实量表原生验收期间，Microsoft Word弹出“文档包含的域可能引用其他文件，是否
  更新”的常规确认。依据用户已明确授权此类Word确认一路继续，Codex通过AppleScript点击
  “是”，未关闭或改写用户原本打开的MG-K10方案文档。真实9页IBDQ、流程图和Word PDF证据
  仍由在途Grok受控任务生成，待其完整退出后由Codex与视觉执行经理验收，不能以弹窗已处理
  代替发布通过。
- W3首轮执行报告称250项测试通过，但Codex源码级验收拒绝。真实API没有注入
  `evidence_verifier`，planner又只在`EXACT_FACT_PATHS`调用该可选接口，而这些路径全部不在
  composite可采用集合，导致W2b目录/binding重验在生产API中实际为死代码；测试还错误断言
  `competitor_option`可直接覆盖当前项目`framing.indication`。此外，派生叶冲突检测被删除，
  幂等事件缺失receipt时会伪造空回执，部分采用会supersede同组既有user-confirmed候选，
  package状态未采用正向allowlist，事件也缺逐路径origin。已在原session
  `20260724_223328_589e30`发起第02轮一次性返修，并扩展允许写集以把服务器实际使用的
  类型化EvidenceCatalog持久化到package；要求每个非override路径在事务双CAS后重验
  catalog ID/hash、binding、target/value pointer、原子叶覆盖和来源漂移，核心项目事实禁止
  competitor observation覆盖，同时补真实API篡改、派生冲突、精确回放和部分采用状态反例。
  W3未接受前不重启后端、不创建D017 v5 run，也不让W4接入未冻结合同。
- 真实Word验收包已由Codex逐页目检，并由Kimi/k3视觉执行经理独立复核全部13张200 DPI
  原图。分项结论冻结为：`IBDQ_PAGINATION_GATE=PASS`（第5-13页连续对应真实量表1/9-9/9，
  标题与源页同页、无缺页/重复/孤立标题/溢出）；`WORD_NATIVE_ROUNDTRIP_GATE=PASS`
  （Word 16.111.1往返后SVG part/relationship/svgBlip及9张量表PNG均保留，SVG hash不变；
  `updateFields`保存后清除是完成域更新的预期状态）；`FLOWCHART_VISUAL_GATE=FAIL`。流程图
  下分支条件应为“240 mg BID安全性不佳”，Word PDF实际只显示“ng BID安全性不佳”。
  第4页夹具元语言及第1-2页稀疏目录仅为窄验收夹具，不得当作整份生产方案版式通过证据。
- Codex进一步从当前生产生成器复现根因：受影响标签中心`x=1266`，源节点横跨
  `1060..1228`，目标节点横跨`1304..1472`，节点间仅76 px；标签宽度超过通道且先于节点
  绘制，随后节点遮住标签左前缀。已初始化受控任务
  `mw_flowchart_label_clip_20260724`并在7月25日01:00前按有效视觉执行路由派发
  Grok Build/grok-4.5；只允许通用边标签布局、几何回归及任务证据写入，禁止MY009/剂量文本/
  坐标特例。后续由Kimi经理复核，Codex最终视觉验收。
- D017 v5重跑准备时发现此前接受的独立QC工具存在身份常量错误：脚本和报告虽命名v5，
  `EXPECTED_PROMPT_VERSION`仍为v4，测试夹具又通过引用同一常量而掩盖了错误，因此先前
  `100 passed`只能证明规则扫描，不能证明v5运行身份。Codex已将门禁改为显式只接受
  `competitor_triage_deepseek_v5_source_truth`，新增“run及全部chunk均为v4时必须拒绝”
  的独立反例；新旧来源真值回归合计`101 passed`并通过py_compile。后续D017新run必须
  同时通过该修正门，旧v4结果不可能再被v5门接受。
- W4实现写集仍严格等待W3合同冻结，但已先并行启动Kimi Code/k3高推理只读执行经理规划。
  输入包含现有W4代码地图、真实W2/W3类型/API、建项页、WritingReferencePanel、App、
  CSS和现有前端QC；要求最多四个互斥切片，覆盖推荐/备选/pending组合卡、一次W3原子采用、
  第一步竞品抽屉、来源原文优先、working-copy现有`appendix_image`九页缩略图/放大审阅、
  三档桌面视口、回车/表格/全屏回归及Codex最终验收证据。本轮只读，不会在W3在途时改前端。
- W3第02轮报告虽称377项测试通过，Codex源码验收仍拒绝其证据门。新
  `ServerEvidenceVerifier`只比较package自带catalog中的字符串，未调用W2b正式
  RFC6901、CT.gov字段映射和逐原子叶覆盖逻辑；W3测试还给`module`组合候选统一使用空
  `value_pointer`，恰与W2b合同相悖。验证器也未从当前journey加精确不可变snapshot重建
  catalog，无法发现snapshot缺失/替换、project/revision漂移或自洽但过期的package目录；
  user-edited composite还会按每个非override路径重复复制整组evidence refs。已在原session
  发起第03轮定点修订：API使用惰性resolver，事务双CAS后才按package精确snapshot重建
  服务器catalog；直接复用W2b重绑公共接口并覆盖每个原子叶；补空/容器/越界/错target/
  漏叶、CT.gov不兼容字段、snapshot和project/revision漂移、真实API成功、纯override兼容及
  来源去重反例。W3继续保持未接受，后端不重启。
- W4只读执行经理Kimi Code/k3已完成实现级拆解并落盘
  `runs/execution/mw_w4_recommendation_frontend_20260724/kimi_manager_plan_01.md`。
  其确认working-copy已经返回完整`appendix_image`页，不需要新增后端；当前缺口是前端未逐页
  展示，以及竞品完整处理入口只在第三步出现。Codex修正了报告中“A/B/C写集互不重叠”的
  错误假设：竞品抽屉和量表预览都会修改
  `MedicalWritingAuthoringJourneySetup.jsx`，因此合并为一个串行前端执行包；W4组合候选
  一次采纳仍等待W3最终API/receipt合同冻结。
- 已按当前时间路由在独立Grok Build/grok-4.5会话派发W4-B/C执行包，只允许新增复用
  `WritingReferencePanel`的早期竞品抽屉、基于既有`appendix_image`的九页缩略图/放大审阅、
  聚焦QC与CSS；禁止改后端、TipTap、表格、AI提示词和未冻结的组合采纳。执行报告目标为
  `runs/execution/mw_w4_recommendation_frontend_20260724/grok_worker_bc_01.md`，runner
  会话标识`6672`；Codex待完成后做源码、测试和三档桌面视觉终验。
- 流程图第01轮修复后的源码审计发现两个不能接受的后备行为：
  `_edge_label_wrap_candidates()`仍可能按最大行数静默截断长标签，
  `_place_edge_label()`在没有清晰位置时仍会输出“最小重叠”候选。已在同一Grok session
  `00723d75-68c5-4dee-9187-9e1f81de030b`发起第02轮，要求完整字符保真、无任何节点重叠、
  出界禁止、必要时确定性扩展/重排或显式失败，并增加`data-edge-label-for`及近300字符、
  密集图、真实IBDQ、SVG/PNG反例。runner会话标识`31587`；未通过Codex源码、几何和
  200-DPI Word视觉复核前，`FLOWCHART_VISUAL_GATE`继续保持失败。
- 用户最新执行路由边界已记录：北京时间2026-07-25 01:00前不得使用
  Qoder/qwen3.8-max-preview；跨过边界后，仅把原本应落到Hermes/aishuo/cms-model的
  新任务、续跑或返修切换到既有QoderVIP `qodercli`会话。边界前已启动的Hermes pass不因
  跨时点中断，但跨时点后不得再向该Hermes session追加follow-up。
- W4-B/C执行包已完成源码写入并通过三项静态合同测试、9页附件预览聚焦测试和前端生产
  build；但Codex启动的真实量表交互QC因运行时两次503而未进入
  `.authoring-journey-shell`，因此继续保持“源码已实现、实机未验收”，不能按静态正则或
  build记绿。待接受源码重启稳定后端后，用隔离项目重跑三档桌面浏览器。
- 流程图第02轮已完成全文保真、禁用最小重叠兜底、`data-edge-label-for`及密集长文本
  回归；Codex独立复跑`test_medical_writing_study_schema.py`为30项通过。旧Word第3页
  仍是修复前产物，`FLOWCHART_VISUAL_GATE`必须等新后端加载后重新生成Word、更新域、
  保存重开、原生PDF和200 DPI逐页目检，当前仍不记通过。
- 只读subAgent完成W4后发布矩阵并已关闭，落盘
  `reviews/codex_subagent_post_w4_release_matrix_20260724.md`。采纳的顺序是W3/W4/
  流程图冻结后依次推进动态设计一致性、SoA/流程图/量表、产品AI文献绑定、最终DOCX整包；
  其任何“已实现”判断不替代Codex的浏览器、独立AI和Word真实验收。
- W3第03轮384项绿测仍缺合法AI多叶候选的真实API成功，以及snapshot删除、search-plan
  改绑、package修订漂移和完整catalog内容漂移反例。Codex按guard的高风险直接路由完成
  r04：生产API现在要求package、持久catalog、candidate及实时重建catalog在project、
  journey revision、search-plan snapshot、repository snapshot、catalog ID/hash及完整
  typed catalog上完全一致；即使复制旧ID/hash但篡改未进入旧hash的标题/provenance也会
  失败关闭。合法双路径AI候选经公共API成功，四类漂移均422且无部分写入；纯override兼容。
  聚焦62项+4 subtest、完整W3 389项+52 subtest、流程图30项、py_compile和前端build全绿。
  备份为
  `records/runtime_backups/20260724_before_w3_r04_live_evidence/source_snapshot.tar.gz`
  （SHA256 `ef83944d5c0db488b463303ed377366a8892e09b52805eaef008dfe7ee7e35ed`）。
  W3源码/API/测试门正式接受；下一步允许一次性重启稳定后端并执行D017 v5、W4浏览器和
  流程图Word真实验收。
- 稳定后端已重启并实际装载W3 r04，`/api/health`为200，schema 16、SQLite integrity
  `ok`、外键错误0、审计违规0；`/api/runtime-readiness`为200且
  `ready=true`，独立AI身份为`deepseek/deepseek-v4-pro`、OpenAI-compatible直连，
  `codex_runtime_dependency=false`。前端5174保持可访问，后端8911当前PID为45439。
- D017 v5通过真实产品API创建全新run
  `ct_run_1b32ff8ebd49a6abc0b3`/job
  `mwjob_bf5a627497c1c995e3798d89`，`reused=false`，基于冻结snapshot
  `wref_search_35f39994abfb89587948`的67个NCT拆成5块。首轮独立
  `deepseek-v4-pro`完成4/5块、53/67个结果；第1块仅漏末尾
  `NCT01529827`，其余项目事实保护和provider/prompt身份正常。正式“仅重跑失败块”接口
  第二次仍漏同一NCT，证明不是网络偶发，而是长JSON输出的可复现完整性缺口；未确认竞品篮子。
  证据保存在`runs/evidence/d017_competitor_triage_v5_20260724/`，重跑前SQLite一致性备份
  SHA256分别为`1fcbdfa29d41ad39cd140a945c39eae51bee4a6018774deba243387a36c5cd6e`
  和`14f033aca724b963d7e470f74da996a1859dc969347ec58760622083a4d91bd3`。
- 已按guard高风险直接Codex路由启动`mw-triage-missing-repair`，实现有界缺项补偿：
  首轮合法子集先通过既有语义/来源真值校验，仅把缺失NCT组成第二次小型产品AI调用；
  合并后仍按原始expected NCT exact-set和顺序严格校验。未知ID、重复ID、非法结构/分类
  不进入补偿，补偿仍失败则整块失败，调用上限固定为2，不存在第三次模型调用。现有103项
  竞品分诊与durable测试及py_compile已通过；独立subAgent正在只写测试文件补齐缺1项成功、
  补偿失败、未知/重复、单次合法和两次上限反例，待其完成后再重启后端并对原D017 run做第3次
  失败块恢复。
- W4-C隔离量表QC的两次503已定位为测试隔离后端未注入“已配置但不实际调用”的独立AI
  环境，生产就绪门因此按设计阻断；已在测试子进程加入placeholder配置且静态门通过。
  本次完整隔离QC同时观察到稳定runtime的durable WAL正在被D017后台任务更新，故整个目录
  字节不变断言产生并发误报；不通过放宽生产隔离合同掩盖，待D017终态后重跑完整浏览器QC。
- W4-A推荐优先组合采纳已按Kimi执行经理计划派发独立Grok Build/grok-4.5执行，runner
  session为35082，写集仅限新候选包组件、journey接线、CSS与聚焦前端测试；禁止后端、
  TipTap、表格、App和稳定服务。要求一次`adopt-composite`、pending逐路径override/skip、
  精确receipt、稳定幂等和409只重载不静默重提。Qoder在2026-07-25 01:00前保持禁用。
- 当前生产导出器已重新生成流程图第02轮修复后的真实9页IBDQ验收DOCX，SHA256
  `a2ba74d875192f3e9088bf8fea3abf7cc06642c15e2db29b22e1e9d80b8ebae6`。预Word
  OOXML门全绿：1个SVG主图+PNG fallback、9张唯一量表PNG、9个连续附件标题、
  `svgBlip`/relationship/content type、TOC及updateFields均存在。Microsoft Word原生
  往返因macOS当前锁屏而无法由Computer Use处理Word授权弹窗，等待进程已主动结束且未改
  用户文档；`FLOWCHART_VISUAL_GATE`仍保持未通过，桌面解锁后必须继续Word保存重开、原生
  PDF及200 DPI目检。
- D017 v5第3次失败块恢复在装载有界补偿后成功，5/5块覆盖67/67个唯一NCT；但独立医学
  验收没有因结构完整而放行，发现6个理由矛盾和2个无来源高风险表述。根因是canonical
  输入仅保留`conditions[:5]`，而完整ClinicalTrials.gov登记条件中的PNH命中有时位于第6项
  以后；官方Search Areas文档也确认`query.cond`会检索条件、标题、MeSH/祖先词及关键词，
  不能把检索命中直接等同为适应症完全一致。旧v5结果保留为缺陷证据且未确认篮子。
- 已启动`mw-d017-source-truth-v6`高风险直接Codex路由：不扩大模型负载，而由完整冻结条件
  列表生成`project_indication_match`、`matching_conditions`及`condition_count`；适应症、
  分期、设计维度文本、证据缺口和最终理由均由服务端显式来源确定性重建，模型不再能把
  “剂量递增”等未支持推断写回审阅结果。包含末尾PNH命中、恶性血液病长列表无命中、
  无来源叙述剔除和v6身份在内的后端/验收回归共241项通过，py_compile通过。
- 稳定后端已装载v6，build为`api-41aabbd87cc18859`；health、schema16、integrity、外键和
  审计链均正常，独立AI仍为直连`deepseek/deepseek-v4-pro`且不依赖Codex。基于同一冻结
  snapshot创建了全新真实运行`ct_run_0a629f725d89d560e459`/job
  `mwjob_1aa68bccadd8db016f7000c7`，`reused=false`；运行前两份SQLite备份SHA256为
  `c95fb5452c8a3c684d5476b8c119a89a326ed9e6a266d5bfe0e30820adad2df9`和
  `83b0014f4b000b9cd411fef328710783c4d28d667b20d7749a00d3b57d06eb04`。
- W4-A源码终审补上两处外部执行未覆盖的真实交互边界：建议包修订变化时清空本地候选/
  override/skip草稿，防止旧包草稿套用到新包；非pending候选不再展示后端无法表达的
  “跳过字段”控件，避免用户点了跳过实际仍采用AI值。一次组合请求、幂等、409只重载、
  receipt与旧batch移除的静态QC及前端生产build通过。
- W4-B/C量表隔离浏览器QC已在1920×1080和1440×900真实Chrome重跑通过：RUX与D001两项目
  均完成量表新增、填写、绑定、治理确认、保存、整页重载持久化、删除再重载及跨项目隔离；
  页面和量表区横向溢出均0，零尺寸/视口外控件均0。测试自身因高级微调默认折叠而失效的
  定位脚本已改为先显式展开；12条404控制台信息保留在报告中，未造成预期外HTTP失败。
- D017 v6真实独立AI运行`ct_run_0a629f725d89d560e459`已完成5/5块与67/67唯一NCT；
  `runs/evidence/d017_competitor_triage_v6_20260725/acceptance_report.json`对身份、快照、
  完整性、分类门禁、未知维度、文档角色、理由一致性、高风险事实和来源定位全部零问题。
  真正终止残留旧uvicorn并重启后，稳定后端build为`api-efc983b8932ef508`；旧v5运行现会
  自动标记`stale`，v6保持`review_ready`。相邻回归211项与py_compile通过。
- 结构化门通过并未替代临床科学性验收。独立临床复核
  `reviews/d017_v6_independent_clinical_review.md`覆盖67项后发现
  `NCT05731050`、`NCT06978699`、`NCT07212426`三项明确PNH II期药物/生物制品研究被误排。
  根因是严格适应症匹配未支持ClinicalTrials.gov常见的
  `PNH - Paroxysmal Nocturnal Hemoglobinuria`独立缩写-全称写法。当前v6只保留为预筛池
  审计证据，禁止确认篮子；已启动v7窄修复，要求独立分隔缩写与全称双重一致、假阳性反例、
  prompt/run身份升级和真实独立AI重跑。
- W4-A真实AI首轮浏览器链路实际完成RA/PNH两项目的建议包、英文检索词采用、ClinicalTrials
  检索、字段采用、重载持久化、设计候选采用、冲突重载和宽屏无溢出；唯一失败是测试把
  `status=partial`、6个可用字段且核心候选存在的真实建议包武断判为“少于10即缺失”。
  补丁已改为检查package ID、允许的ready/partial状态、至少一个可用字段和核心候选；
  组合候选同时改为未选项紧凑摘要、选中项保留来源原文，并把权衡/缺口/局限/受影响字段
  收入可展开详情。静态合同、附件预览和Vite生产build已通过，真实独立AI隔离浏览器复跑在途。
- Word原生往返已在Microsoft Word 16.111.1真实完成：仅打开任务自有DOCX，更新域、保存、
  关闭、重开、导出13页PDF，且用户原有MG-K10文档前后均保持打开。PDF 200 DPI逐页目检和
  独立视觉复核均通过：第3页流程图所有节点/箭头/条件标签完整，
  “240 mg BID安全性不佳”不再裁切；第5-13页IBDQ 1/9至9/9连续唯一、标题与量表同页、
  无空白/重复/裁切。Word后OOXML仍保留1个SVG、PNG fallback、9张量表、`svgBlip`和TOC；
  `updateFields`在Word已实际更新后被清除属于预期。自动200 DPI密度门已按真实表单留白校准
  后全绿。该门只证明流程图/量表嵌入和Word往返，不代表生产全文方案已通过。
- 2026-07-25 00:52重新完整读取全局`/Users/smkzw/.codex/AGENTS.md`并按用户最新时间边界
  校正执行路由：北京时间2026-07-25 01:00前不得使用Qoder/qwen3.8-max-preview；01:00后
  仅把原本应落到Hermes/aishuo/cms-model的新任务、续跑或返修切换到既有QoderVIP
  `qodercli`会话。已确认现有进程由`/Users/smkzw/Downloads/QoderVIP/start.command`
  派生，未创建替代Qoder进程，边界前也未发送任何Qoder任务。
- 只读subAgent完成下一发布批次梳理并关闭，报告为
  `reviews/medical_writing_next_release_priorities_20260725.md`，SHA256
  `60d30e6cb1a5d298edd28efe9805956c270988b3cc5354ec8c4598708104293c`。报告仅列10项
  未闭环发布包，明确不重开D017 v6、W4-A/B/C、动态设计投影和流程图/真实量表Word窄门。
  发布依赖顺序固定为竞品原文准备与翻译、语料准入路由、双路径AI前置设计、文献/量表、
  逐章/整表、编辑器、完整方案DOCX、十二场景发布门。
- D017 v7真实独立AI任务`mwjob_ae5b0a1cd82c70f309e7bc43`继续由稳定后端
  `api-9a66182ec0a076ae`执行；00:57到达第4/5块、80%，未使用Codex或执行模型代替产品
  `deepseek/deepseek-v4-pro`。终态后必须保存完整run、运行v7确定性验收，并逐项复核
  `NCT05731050`、`NCT06978699`、`NCT07212426`，不得仅凭结构完整确认竞品篮子。
- 已建立`mw-literature-word-link-release`及三写集执行包
  `mw-literature-word-link-release-exec`。源码复核确认当前生产导出器已经具备
  GB/T 7714-2015顺序编码、上标引文、参考文献书签和内部超链接；53项引用/重索引聚焦回归
  通过，RUX与PNH既有真实DOCX中的所有内部引用anchor均可解析到书签。故本轮不重建文献库
  或OOXML链，只修复：(1)草稿导出可带简洁可处置提示；(2)`approved_final`在
  source-reference状态为blocked时失败关闭；(3)前端读取状态但不常驻底层日志；
  (4)任务自有DOCX在Microsoft Word中更新域、保存重开、原生跳转和重排保持的真实证据。
  三份Qoder worker prompt已完成来源、写集、功能边界和验收预检；01:00前不会派发。
- D017 v7确定性验收文件已冻结：
  `runs/evidence/d017_competitor_triage_v7_20260725/run_response_final.json`
  SHA256 `d61f1db7bf26bbed57776dce53ba2ef7fce803e2b452fcb4fca3d04b98f7650d`，
  `acceptance_report.json` SHA256
  `4463121f5e94739a153247a3732ae2087a5ce681224a1edd6604e3bb0140fa8d`。
  v7身份、5块/67项完整性、快照、来源、理由和未知项目维度保护全部通过；
  `NCT05731050`、`NCT06978699`、`NCT07212426`均已从误排修正为
  `indirect_reference`。旧v6在当前后端读取时按prompt版本变化自动变为stale。
- 独立临床逐项复核`reviews/d017_v7_independent_clinical_review_20260725.md`
  仍拒绝按50/17原样确认：`NCT02591862`因`Haemoglobinuria/Hemoglobinuria`
  英美拼写差异误排，`NCT03439839`因疾病全称后追加`With Signs of Active
  Hemolysis`亚群限定误排。修正后最大待医学经理审阅篮子应为52候选/15排除，
  其中`NCT00004464`、`NCT01642979`、`NCT01760096`仅为历史/支持治疗背景，
  仍需用户指定用途或排除；当前0个direct是D017技术类型、途径、靶点均未知所致。
  v7保持review_ready且confirmation_id为空。已启动v8窄修复，限定医学正字法等价和
  已完整病名后的受控亚群限定，继续拒绝模糊子集、并列病种和PNH-related假阳性。
- 对历史“完整方案”产物重新量化后确认它们不能作为发布证据：
  D017 PNH Word虽然有106个Heading和28页，但非空正文总计仅2627个字符、2张表、0个图；
  RUX AD greenfield仅1038个非空字符、99个Heading、2张表、0个图，主体仍是动态章节
  空骨架。流程图+IBDQ文档则只有370字符且本来就是窄门。后续“完整方案DOCX”必须由
  产品独立AI逐章候选、整表、流程图、量表和文献链形成实质正文，不能复用这些骨架或
  以页数/标题数代替内容完成度。
- 用户于2026-07-25进一步更新临时路由：北京时间08:30前，所有原本落到
  `Hermes/aishuo/cms-model`的新任务、续跑和返修均使用现有QoderVIP
  `qodercli/qwen3.8-max-preview`；08:30后恢复`Hermes/aishuo/cms-model`。
  已启动的完整pass不因跨时点强制中断。该边界替代本记录中先前“01:00后持续切换Qoder”
  的开放式终点，但不改变其他角色路由。
- D017 v8窄修复已落盘并由Codex独立复跑通过：prompt version为
  `competitor_triage_deepseek_v8_condition_equivalence`；仅在condition匹配层支持
  `haem-/hem-`正字法等价，并只允许完整疾病全称（可带已证明括号缩写）后以
  `with/without`开头的受控亚群限定。并列/或关系、`PNH-related`、共享缩写、三段alias、
  错误全称继续失败关闭；模型明确excluded仍不被服务端模糊提升。指定3个测试文件
  `265 passed, 8 warnings`且py_compile通过，稳定服务尚未重启，真实v8 run尚未创建。
- 2026-07-25 01:24再次完整读取全局`/Users/smkzw/.codex/AGENTS.md`并应用用户最新临时
  路由：北京时间08:30前，所有原本解析到`Hermes/aishuo/cms-model`的新任务、续跑和返修
  使用既有QoderVIP `qodercli/qwen3.8-max-preview`；08:30后恢复
  `Hermes/aishuo/cms-model`。已确认既有`qodercli`进程仍在且没有启动替代进程；完整pass
  不因跨越08:30被强制中断。首个文献重索引worker的第02轮返修已在原Qoder会话一次性下发，
  不发送模型侧“进度/继续”轮询。
- 真实参考原文首批候选只读盘点完成：
  `reviews/writing_reference_real_batch_candidates_20260725.md`选择CRSwNP
  `NCT02898454` 125页原生文本Protocol与UC `NCT02819635` 224页混合Protocol；后者12个
  整页图像页必须200 DPI、`GLM-OCR-bf16`、最多8路并发。Codex验收记录为
  `reviews/writing_reference_real_batch_candidates_codex_acceptance_20260725.md`。
  技术身份、OCR范围、Hy-MT2/Flash/Pro职责及快照前置条件被接受；报告提出的额外
  sponsor/rights审批硬门因与用户既定“权威来源/公司内文件直接可用，仅做基本信息和内容
  校验且允许医学经理override”相冲突而不采纳。真正发布缺口仍为UC快照/分诊、OCR页PNG/hash
  持久证据和Flash→Pro上层升级lineage，不增加“待医学批准”。
- OCR证据与Flash→Pro只读技术设计已完成：
  `reviews/ocr_evidence_and_flash_pro_escalation_design_20260725.md`，SHA256
  `94ce531ad6748cb16f531075fc0367fe0085eaaff478b3b4b25106b5aa9f21e7`。
  Codex验收与产品修正记录为
  `reviews/ocr_evidence_and_flash_pro_escalation_codex_acceptance_20260725.md`：
  接受不可变200 DPI PNG sidecar、空OCR页证据、旧记录兼容、阶段级provider/model/hash/
  parent lineage、route-specific integration fingerprint及Hy-MT2正文唯一性；拒绝新增逐页
  人工确认和医学经理手动点击Pro升级。Flash经有界纠正后达到确定性可升级条件时由系统自动
  创建一次Pro上层子运行并展示过程，用户只处置最终异常；`corpus_selection_support`在真实
  模型调用和lineage实现前必须诚实标为`not_implemented`。
- 文献重索引worker_01在Qoder三轮后触发no-progress breaker：R01状态矩阵错误，R02旧
  无效测试未删除且新测试走错greenfield路径，R03仍把RUX/API必做修改留作pending并新增
  错误模块导入，却输出完成标记。Codex停止继续返修，按完全定位的根因做最小修正并独立
  验收；记录为`reviews/mw_literature_word_link_worker01_codex_acceptance_20260725.md`。
  当前确定性合同为`applied/preserved/not_applicable`允许正式终稿，只有`blocked`阻断；
  RUX草稿保持原文/字段但提供Word临时副本刷新或重新绑定后重新导入的短提示，RUX正式终稿
  在处理前失败关闭；greenfield真实200导出返回三个稳定header。引用/导出聚焦
  `44 passed, 8 warnings`，重索引真实项目`28 passed`，py_compile通过。稳定服务尚未
  重启，需在前端worker接受后统一装载。
- 2026-07-25 01:53按用户最新要求再次完整读取全局
  `/Users/smkzw/.codex/AGENTS.md`，并确认临时路由边界：北京时间2026-07-25 08:30前，
  原本解析到`Hermes/aishuo/cms-model`的新任务、续跑和返修均使用既有QoderVIP
  `qodercli/qwen3.8-max-preview`；08:30后恢复Hermes route；已启动的完整pass不因跨界
  中断。既有QoderVIP进程仍在工作，未创建替代Qoder进程，也未向运行中的worker发送
  “进度/继续”类模型消息。
- OCR与上层AI additive合同已由Codex逐项验收，记录为
  `reviews/ocr_upper_layer_contracts_codex_acceptance_20260725.md`。合同明确：
  legacy OCR只标记`legacy_metadata_only`，新页证据支持200 DPI PNG/hash/尺寸/relpath/
  `empty_text`；Flash/Pro仅用于文档规划、Hy-MT2后整合/QC及未来语料选择，上层Pro必须
  具有Flash父运行和服务器自动升级lineage，客户端不得选择provider/model；Hy-MT2仍是
  正文翻译唯一模型；`corpus_selection_support`在真实实现前为`not_implemented`。
  `py_compile`及OCR/上层合同、chapter pipeline、writing reference组合回归
  `104 passed`。原合同worker已关闭。
- 在共享合同冻结后，启动三个互不重叠的Codex subAgent实现切片：
  (1) OCR 200 DPI PNG sidecar与新写强校验；
  (2) Flash→Pro上层运行持久化、幂等及恢复；
  (3) translation pipeline/batch的Hy-MT2 target-map保持与上层阶段编排。
  三者均禁止修改`main.py`、前端、稳定服务配置或伪造真实模型成功；真实OCR/模型/API/
  浏览器仍需Codex后续独立验收。
- 文献导出前端worker_02已完成，但Codex拒绝原样接受其“提示可见”结论：worker只写入
  `workingCopyMessage`，页面原条件仅渲染含失败/错误词的消息，故blocked草稿提示实际
  不可见。已修正为后端warning和fallback均统一加`草稿已生成；`前缀，并只在现有轻量
  信息栏显示该前缀；错误消息保持danger样式。验收记录：
  `reviews/mw_literature_word_link_worker02_codex_acceptance_20260725.md`；
  聚焦`9/9`、前端合同`20 passed`、Vite生产构建通过。旧citation isolated QC因RUX/PNH
  历史引用项目均无版本化StudyDefinition而失败，稳定库同样无这两个authoring journey，
  记为旧夹具/项目迁移缺口，不伪装成本次导出提示回归或新的端到端编辑证据。
- OCR evidence core已由Codex审阅并修正：原实现会把恢复页追加到native spans末尾，
  混合文档可能出现物理页逆序；现按物理页、块序、locator和span id稳定排序，并新增
  空白首页OCR+第二页native text回归。验收记录：
  `reviews/ocr_evidence_core_codex_acceptance_20260725.md`；组合回归`121 passed`。
- 两个真实参考项目当前产品状态经稳定API只读核对：CRSwNP
  `proj_user_4ef4aa3da246`已有快照`wref_search_f695ab9e5565293eb9e7`、12项候选，但
  `corpus_triage`仍pending且无artifact；UC `proj_my009_uc`仍在framing阶段，无search
  plan、snapshot、triage或artifact。后续必须分别从CRSwNP分诊和UC最小框架/检索开始，
  不能直接把本地PDF跳接到OCR/翻译后半程。
- 真实本地oMLX OCR单页窄门通过：
  `runs/evidence/ocr_real_smoke_uc_nct02819635_20260725/`。UC公开Protocol物理页143原生
  文本为0，200 DPI PNG `1700×2200`，`GLM-OCR-bf16`约5.06秒输出1229字符；正文、AE收集
  时窗和主要图中文字可读，但二维时间轴被线性化且左右标签关系不完整。Codex视觉/文本
  复核为`reviews/ocr_real_smoke_uc_nct02819635_codex_review_20260725.md`：真实adapter
  可用，但图表页必须保留PNG并进入视觉结构核对，OCR纯文本不能单独代表完整图义或直接
  语料准入。12页完整批次、repository重启保持、翻译和语料准入仍未验收。
- Qoder worker_03已在既有QoderVIP进程中通过`/new`建立干净会话，并用AppleScript直接
  投递Word原生引用窄门；未启动替代qodercli，未触碰用户已打开文档。
- 2026-07-25 02:16机器实时时钟核验为北京时间，尚未到08:30。故当前所有原本解析到
  `Hermes/aishuo/cms-model`的新任务、续跑和返修仍切换到既有QoderVIP
  `qodercli/qwen3.8-max-preview`；08:30后才恢复Hermes route。此前基于日志时间作出的
  “已过08:30”口头判断已立即纠正，未据此错误分派任务。
- 上层AI持久化和翻译编排两条subAgent实现已由Codex逐段审阅并组合复跑：
  `279 passed, 1 deselected, 13 warnings`。验收记录分别为
  `reviews/upper_layer_execution_codex_acceptance_20260725.md`与
  `reviews/translation_upper_layer_orchestration_codex_acceptance_20260725.md`。
  接受服务器固定Flash→确定性Pro升级、schema v5持久lineage、Hy-MT2正文唯一性、完整
  target-map冻结与逐字正文不变门；仅使用fake adapter，`main.py`真实DeepSeek接线、
  真实模型、稳定服务和双Protocol批次均未通过，不能宣称上线。
- Qoder worker_03报告已完成但未通过Codex验收：它只复制任务自有DOCX、统计2个TOC域、
  8个SEQ域和27个书签并打开Word，随后把更新域、原生跳转、保存重开、重排检查改成手工
  清单。拒绝记录为
  `reviews/mw_literature_word_link_worker03_codex_rejection_20260725.md`。Codex首次用
  Computer Use接管时检测到Mac锁屏，故真实Word门保持pending，不要求用户代做，也不把
  OOXML静态证据冒充原生验收。
- 已新建独立Codex subAgent切片，限定修改`main.py`、可选专用adapter模块、聚焦测试与
  review，负责把`WritingReferenceUpperLayerExecutionService`和
  `PersistedUpperLayerStageExecutorAdapter`接入direct/batch共用pipeline，固定
  `deepseek-v4-flash`/`deepseek-v4-pro`、验证exact response model、未配置时失败关闭、
  启动恢复到期escalation；不得重启稳定服务或伪造真实模型通过。Codex继续负责真实模型、
  API、浏览器和文档最终验收。
- 重新读取稳定API后，CRSwNP真实项目`proj_user_4ef4aa3da246`为journey revision 17，
  framing/PICOS均完成，快照`wref_search_f695ab9e5565293eb9e7`含12项候选，合法下一步为
  产品AI批量分诊。已通过稳定API创建真实独立AI任务：run
  `ct_run_7d9db4c3d935b989b0b4`、durable job
  `mwjob_7ea2b26b64727cb882bf1b9e`，请求与响应保存在
  `runs/evidence/crswnp_competitor_triage_real_20260725/`。该任务由系统配置的
  `deepseek-v4-pro`执行，Codex不代替模型分诊，也不高频轮询。
- UC真实项目`proj_my009_uc`仍在framing，已有药物MY009、适应症溃疡性结肠炎和II期，
  但旧逻辑仍把ClinicalTrials condition term、靶点、总体设计、人群意图、内在研究目的
  作为启动检索的硬门。这与用户明确的“药物+适应症+分期即可启动竞品调研，后续字段由
  AI/证据预填供用户改”相冲突。未为跑通测试虚构上述字段；已启动独立subAgent修复
  “最小三事实检索门”，保持完整PICOS/方案生成阶段的严格确认不变。
- 文献引用执行包的Grok Build/grok-4.5执行经理已按全局路由启动，读取三份worker报告并
  做一次完整复核。未发送状态追问；Codex已先行明确worker_03不能以OOXML静态检查替代
  Word原生验收。
- CRSwNP真实独立AI分诊run `ct_run_7d9db4c3d935b989b0b4`已进入
  `review_ready`，供应商/响应模型为`deepseek/deepseek-v4-pro`，1个chunk成功、12个
  候选全部被推荐排除。Codex未确认该结果。逐条审阅发现其科学结论不可接受：模型把
  `Chronic Rhinosinusitis With Nasal Polyps`、`Chronic Rhinosinusitis Phenotype
  With Nasal Polyps (CRSwNP)`等与“慢性鼻窦炎伴鼻息肉”判为不同适应症，并把项目
  技术类型/给药途径/靶点未知当成排除理由。正确边界应是：未知事实阻断
  `direct_competitor`并降低置信度，但同适应症、药理性且对方案设计有用的研究至少应
  保留为`indirect_reference`；不能以信息缺失替代医学排除。失败证据保存在
  `runs/evidence/crswnp_competitor_triage_real_20260725/run_snapshot_01.json`。
- 同一CRSwNP快照`wref_search_f695ab9e5565293eb9e7`创建于2026-07-18，候选虽有标题、
  condition、phase和公开Protocol/SAP，但`interventions`、摘要、设计、入组数等字段
  为空。2026-07-25直接调用ClinicalTrials.gov官方v2接口读取NCT02898454，并用当前
  `candidate_from_study`解析，已得到Dupilumab/安慰剂/MFNS、随机平行四盲、448例及
  完整摘要，证明当前解析器能读取这些字段；当前更可能是旧不可变快照在字段丰富化前
  已冻结，而非现行API必然缺字段。因此修复别名/判定逻辑后必须通过新的检索计划和新
  幂等键生成全新富化快照，再用真实独立AI重跑；旧快照和旧分诊不得复用或确认。
- CRSwNP journey只读核对还发现两个项目状态污染/无效事实：
  `picos.assessment_instruments`残留UC的IBDQ（此前量表图片附件链路验收注入），
  `framing.target_mechanism`为无医学含义的“全部”。这两项不得进入CRSwNP候选生成、
  方案正文或语料选择。统一集成后需通过正式journey影响预览/提交链路清理，并增加
  跨项目隔离回归；不得直接改库掩盖问题。
- 已将CRSwNP分诊科学性修复分派给独立subAgent，写范围限定为
  `medical_writing_competitor_triage.py`及聚焦测试，要求覆盖中英文同义词、CRSwNP
  缩写、受控多condition组合和反例，保持无模糊泛化；不得修改authoring journey、
  `main.py`、稳定服务或数据库。Codex后续仍须做真实新快照、真实DeepSeek分诊及医学
  终审。
- 文献引用执行经理Grok Build/grok-4.5已完成单次完整复核并正常退出，无fallback。
  经理独立复跑后端导出相关`44 passed`、重索引`28 passed`、前端聚焦`9/9`及前端
  合同`20 passed`，同意Codex对worker_01/02的源码级接受；同时明确worker_03仍未完成
  Word原生引用跳转、更新域和保存-关闭-重开回环，静态OOXML不能代替。其报告为
  `runs/execution/mw-literature-word-link-release-exec/manager.md`。
- Codex再次按Computer Use技能尝试读取Microsoft Word，系统仍返回“Mac is locked and
  automatic unlock could not unlock it”。未触碰任何用户文档，也未要求用户代做；
  该门继续保持pending，待机器解锁后只操作任务自有disposable DOCX。
- 对“用户作为医学经理选择候选即为项目确认，不再设置第二层待医学批准”要求做了
  源码级功能复核。新authoring/prefill主路径已有部分正确语义和回归，但旧
  Evidence/PICOS工作面、审批中心、translation准入、结构化表格提示及若干后端状态机
  仍残留`待医学批准`、`accepted_pending_medical_approval`和再次提交审批逻辑。
  这不是只改标签即可完成：需在当前三个互斥实现分支集成后，单独梳理
  “AI候选→作者选择/确认→写入工作副本”和“翻译事实忠实度→作者确认→语料准入”的
  状态迁移，保留来源/质量门但取消重复医学批准；同时对历史记录做兼容显示，不能破坏
  已保存审计。该项列为写作子系统正式上线前阻断项。
- Flash→Pro生产接线子Agent切片已由Codex验收，记录：
  `reviews/upper_layer_production_wiring_codex_acceptance_20260725.md`。
  Codex逐段检查组合根、adapter和测试，并以项目既有Python复跑
  `172 passed, 1 deselected, 15 warnings`；Homebrew Python 3.12因缺少`pymupdf`
  的collection失败未被当作产品失败或通过证据。该subAgent已关闭释放额度。真实
  DeepSeek、稳定服务和重启恢复门仍pending。
- 已对当前运行中的全部`runtime/*.sqlite3`执行SQLite在线`.backup`，备份目录：
  `records/active_slices/medical_writing_production_rebaseline_20260722/runtime_backups/pre_unified_restart_20260725_023818/`。
  `SHA256SUMS.txt`已排除自身并从项目根验证，12个SQLite备份全部`OK`。这是统一重启前
  恢复点，不代表之后可以跳过源码/运行态验收。
- 2026-07-25 02:42再次完整读取全局`/Users/smkzw/.codex/AGENTS.md`并核对机器时间。
  当前仍早于用户指定的2026-07-25 08:30 Asia/Shanghai边界；在此之前，所有新建且
  原本解析到`Hermes/aishuo/cms-model`的角色继续改走既有QoderVIP
  `qodercli/qwen3.8-max-preview`，到点后恢复Hermes。没有启动替代Qoder进程。
- “最小三事实检索门”主会场独立复跑：authoring/synopsis/greenfield后端
  `154 passed`，Vite生产构建通过。前端合同`98 passed, 1 failed`，唯一失败为既有
  `LOW_RISK_BATCH_PREFILL_FIELDS`安全批量预填合同缺失；已定向退回原subAgent处理，
  未以“与本次无关”为由弱化测试。
- CRSwNP分诊科学性修复已完成定向慢性边界返修并由Codex独立验收：
  聚焦与科学边界`236 passed`，D017/持久化/恢复相邻回归`86 passed`。受控规则现在
  区分慢性鼻窦炎组合、泛化Sinusitis需标题佐证及急性反例；未知项目事实仅降低置信度、
  阻断直接竞品，不再作为排除依据。验收记录：
  `reviews/crswnp_competitor_triage_scientific_fix_codex_acceptance_20260725.md`。
  真实新快照、真实DeepSeek重跑与项目污染清理仍为后续运行态门。
- “最小三事实检索门”经定向复核确认唯一前端失败来自过期测试合同：旧测试要求恢复
  `LOW_RISK_BATCH_PREFILL_FIELDS`和逐字段循环调用，但当前已采用W4原子
  `prefill-package/adopt-composite`，恢复旧实现会重新引入部分成功和重复提交风险。
  测试已改为验证一次原子请求、package revision、409只刷新不自动重放、项目隔离、
  三事实检索及适应症回退。Codex复跑前端合同`99 passed`、composite相邻组合
  `123 passed`、Vite生产构建通过；验收记录：
  `reviews/minimal_three_fact_search_gate_codex_acceptance_20260725.md`。
- 已建立统一重启后的真实验收合同
  `POST_RESTART_REAL_ACCEPTANCE_20260725.md`，固定UC三事实从零开始、CRSwNP正式污染清理
  与新富化快照、D017跨适应症复验的先后顺序。当前稳定运行态实测：主语义AI为
  `deepseek-v4-pro`，翻译上层为`deepseek-v4-flash`，正文为本地
  `dawncr0w--Hy-MT2-30B-A3B-oQ8-MLX`，OCR为本地`GLM-OCR-bf16`；均声明
  `codex_runtime_dependency=false`。前后端build仍不一致，必须等待当前状态机分支验收后
  做一次统一重启，不提前用旧运行态冒充新功能验收。
- 2026-07-25 03:51再次完整读取全局`/Users/smkzw/.codex/AGENTS.md`并核对机器实时时钟。
  用户最新路由边界覆盖此前临时窗口：2026-07-25 08:30 Asia/Shanghai前，所有新建且
  原本解析到`Hermes/aishuo/cms-model`的角色改走既有QoderVIP
  `qodercli/qwen3.8-max-preview`；08:30后恢复Hermes。既有QoderVIP由
  `/Users/smkzw/Downloads/QoderVIP/start.command`启动，进程名与会话链路仍在；本轮未
  启动替代Qoder，也未向外部模型发送无意义进度追问。
- 医学作者选择即确认的独立审阅已完成，报告：
  `reviews/mw_author_selection_confirmation_independent_review_20260725.md`。报告发现
  0项P0、6项P1、2项P2；其中运行态build不一致是统一重启前已知状态，其余阻断包括：
  PICOS选择后仍二次/三次确认、历史PICOS迁移UI不可达、handoff仅按客户端key幂等、
  历史approved译文无当前准入出口、来源失效后仍计当前确认、旧translation revision
  退回/拒绝假成功，以及跨项目同业务ID测试不足。现有206项测试虽通过，但部分断言固化
  了错误交互，不能作为放行依据。
- 已新增验收矩阵
  `reviews/mw_author_selection_confirmation_acceptance_matrix_20260725.md`，固定单次
  作者确认、历史迁移、业务级交接幂等、译文失效投影和双项目同ID隔离的必须通过语义。
  两条Codex subAgent修复线已并行启动且写范围互斥：PICOS/handoff一线、翻译历史迁移/
  失效/项目隔离一线。两线均不得重启5174/8911或写运行态SQLite；Codex负责复现、组合
  回归、真实浏览器与真实项目最终验收。
- 作者选择即确认两条修复线已由Codex完成源码复核和组合验收。PICOS选择/保存修订即
  域级作者确认；快照+handoff为单一技术动作；历史`in_medical_review`和
  `returned_for_revision`可迁移；handoff按业务身份幂等。翻译历史
  `approved + not_admitted`可一次确认并原子准入；失效来源/解析/hash/revision只保留
  历史确认，不计当前确认；非当前revision处置明确stale；同业务ID双项目完全隔离。
  组合15模块`233 tests`全部通过，Codex验收：
  `reviews/mw_author_selection_confirmation_codex_acceptance_20260725.md`。
- 首次全仓复跑`2728 tests`暴露12 failures + 4 errors。分组复现后确认：结构化设计/
  I期Parts/期中分析/动态章节共10项为旧测试把`pending_decision`待决定卡误当可采用事实；
  测试已按具体候选和`confidence=none + manual_only`当前合同修正，相邻`495 passed`。
  前端冻结按钮和恢复helper两项为合同定位漂移，修复后9项通过；AI虚构provider测试显式
  test-only隔离、OCR新证据增加`ocr_reconciled + native_channel`强校验、项目API测试
  接受内置项目有序前缀和动态用户项目，相关相邻69项通过。报告：
  `reviews/mw_full_suite_structured_design_repair_20260725.md`、
  `reviews/mw_full_suite_frontend_contract_repair_20260725.md`、
  `reviews/mw_full_suite_isolation_ocr_repair_20260725.md`。
- 第二次全仓复跑`2728 tests`只剩2项失败：医学写作durable job路由测试与后台sweeper
  竞态、RUX医学监查真实风险受试者集合变更。durable job测试已改为临时绑定独立SQLite
  store，保持真实API但隔绝worker，模块18项通过；医学写作发布核心组合356项通过，
  Vite 1888 modules生产构建通过。RUX失败属于第二优先级医学监查夹具，不阻断本次写作
  端口更新，但必须在写作完成后进入医学监查LOOP。
- 统一重启前当前已验收源码归档：
  `source_backups/pre_release_restart_20260725_043841/source_scope.tar.gz`，校验和已由
  `shasum -a 256 -c`验证`OK`。此前运行态12个SQLite在线备份仍位于
  `runtime_backups/pre_unified_restart_20260725_023818/`。
- 2026-07-25 04:43-05:10 CST，统一重启后的真实桌面验收继续到富文本持久化层。
  `test01`项目已通过真实UI完成StudyDefinition影响预览、理由、双确认和正式重绑定；
  随后在“疾病背景及治疗现状”工作副本中复现到P0编辑语义缺陷：在标题来源块边界
  `Enter`后输入正文，保存并读取工作副本时新正文被并入heading来源块，标题文本被污染；
  一次加粗操作也未形成可确认的持久mark。测试文字已通过版本化工作副本API恢复，revision
  前进至2；工作台“重新加载”后正文仅为“疾病背景及治疗现状 / 慢性鼻窦炎伴鼻息肉”，
  没有遗留验收标记。
- 已建立受控任务上下文
  `context/mw_editor_block_mapping_migration_20260725_context.md`，把标题只保留标题、
  新正文绑定合法body block、mark/段落/表图身份持久化、旧导入方案正式StudyDefinition
  bootstrap列为硬门。两条Codex subAgent写范围互斥：前端TipTap块映射及回归一线，
  legacy import后端迁移/API/测试一线；均不得重启服务或写运行态数据库，Codex负责最终
  源码、API和真实浏览器验收。
- 2026-07-25当前机器时间早于用户指定的08:30 Asia/Shanghai切换点；本轮所有新建且原本
  解析到`Hermes/aishuo/cms-model`的角色继续改走既有
  `/Users/smkzw/Downloads/QoderVIP/start.command`维护的`qodercli`进程、
  `qwen3.8-max-preview`模型；08:30后新角色恢复Hermes。未启动替代Qoder进程，未发送
  无意义进度询问。
- 富文本标题边界修复已完成首轮Codex源码复核。`editorSourceMapping.js`现在把heading
  来源块中由`Enter`产生的正文overflow只绑定到其后紧邻、类型为paragraph的来源块，
  heading本身仍只含heading节点；找不到合法正文来源块时fail closed，不再污染标题。
  新增正文的bold等marks通过`leadingNodes`保留。相邻Node映射测试9个场景全部通过，
  前端合同`100 passed`。
- 同revision“重新加载”不刷新TipTap DOM的根因已修复：工作副本章节与正文两个GET均
  成功且请求仍为最新时，推进服务器水合世代；编辑器key同时纳入revision、内容hash和
  水合世代，强制从服务器正文重建。成功重载清除dirty/结构错误；失败请求保留内存草稿。
  行为验收已覆盖标题末尾`Enter`后产生未保存文本、丢弃并重新加载、服务器revision/hash
  未变、非法文本消失、持久正文恢复，以及表格/单元格身份不变。Codex独立复跑Vite生产
  构建，1888 modules通过；chunk-size仅为既有非阻断警告。
- 真实浏览器最终验收尚未执行，必须等legacy import迁移状态机完成、Qoder执行经理复核
  和统一受控重启后，使用可恢复工作副本验证`Enter + bold + 保存 + API读取 + 重载`，
  随后通过正式版本API恢复原文并再次核对无验收标记残留。
- 旧导入protocol/synopsis后端bootstrap最小状态机已落盘：
  `eligible -> extracting -> review_pending -> confirmed_ready_for_binding -> bound`。
  新增GET状态、POST prepare、POST confirm三条窄API；确认前不创建authoring journey，
  原始DOCX保持只读并做document/hash CAS；确认在单一SQLite事务内创建journey和
  StudyDefinition，完整方案来源标为`full_protocol_import`，保留来源hash、提取证据和
  审计事件；确认后现有一致性服务返回`binding_required`，不伪装已绑定。Codex复跑
  legacy迁移5项及作者旅程/摘要导入/一致性/前端合同组合，共`168 passed`。自动识别
  protocol或synopsis当前仍含“章节数>3”的启发式，必须在前端显示角色并允许医学经理
  override；不能作为后台静默定论。
- Qoder执行经理提示词已补齐新增contracts、legacy migration service、交互QC和聚焦
  测试，guard preflight通过（0 warnings / 0 errors）。第一次仅用GUI粘贴因macOS当前
  屏幕会话未实际提交，已通过同一既有Terminal/QoderVIP标签页的AppleScript
  `do script`重新提交短入口指令；Qoder transcript于2026-07-25 06:04:43记录
  `input.prompt.submitted`，模型请求为`qmodel_preview`，没有启动替代进程。后续只观察
  指定报告和终止标记，不发送进度询问。
- 标题边界与格式持久化真实桌面门已在稳定`5174/8911`运行态通过。受控脚本实际从标题
  末尾按Enter，先验证未保存内容“丢弃并重新加载”不会写入服务器，再插入正文并加粗，
  经UI保存、工作副本API读取和同revision重新加载后，heading来源块仍仅为
  “疾病背景及治疗现状”，新正文位于其后paragraph来源块，bold mark仍存在。脚本最后
  通过正式版本API恢复基线至revision 4，并再次核对无`[QC-`标记残留。证据：
  `records/active_slices/medical_writing_production_rebaseline_20260722/evidence/editor_heading_boundary_20260725/heading_boundary_persistence_qc.json`
  及`saved_heading_body_bold_roundtrip.png`。回归：映射9场景、前端合同100项、Vite
  1888 modules全部通过。该P0编辑器循环已关闭，下一步转入旧导入方案bootstrap前端入口
  和文档角色医学override的真实验收。
